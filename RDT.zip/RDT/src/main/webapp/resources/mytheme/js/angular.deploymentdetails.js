/***
 * Module: Deployment Details
 * Developer: YS
 * Technology: Angular JS
 */
var deploymentDetailsControllerEle = document.querySelector('[data-ng-controller=deploymentDetailsController]');
rdtApp.controller("deploymentDetailsController", function($scope,$http) {  
	  $scope.showDeploymentDetails={};
	  $scope.showDeploymentDetails.title='Deployment Details';
	  $scope.updateDeployment={};
	  $scope.updateDeployment.title='Update Deployment Details';
	  
	  var username = $.trim($('#person').val());
	  $scope.updateDeployment.loggedInUser=username;
	  
	  DeploymentDetails.populateDeploymentDetailsScreen($scope);
	  
	  $scope.edit = function() {    
		  DeploymentDetails.showUpdateDeploymentDetailsScreen($scope);
      }; 
      $scope.update = function(){    
    	  DeploymentDetails.updateDeploymentDetails($scope);
      };
      $scope.reset = function(){   
    	  $scope.updateDeployment.serverName1='';
		  $scope.updateDeployment.url1='';
	      $scope.updateDeployment.db1='';
	      $scope.updateDeployment.serverName2='';
		  $scope.updateDeployment.url2='';
	      $scope.updateDeployment.db2='';
	      $scope.updateDeployment.serverName3='';
		  $scope.updateDeployment.url3='';
	      $scope.updateDeployment.db3='';
	      $scope.updateDeployment.serverName4='';
		  $scope.updateDeployment.url4='';
	      $scope.updateDeployment.db4='';
      };
}); 

var DeploymentDetails={
		getDeploymentDetailsControllerEleScopeEle:function(){
			if(null==deploymentDetailsControllerEle || undefined==deploymentDetailsControllerEle) {
				deploymentDetailsControllerEle = document.querySelector('[data-ng-controller=deploymentDetailsController]');
			}
			return angular.element(deploymentDetailsControllerEle).scope();
		},
		showUpdateDeploymentDetailsScreen:function($scope){
			if(!isValidAccess('CAN_UPDATE_DEPLOYMENT')) {
				return false;
			}
			var isApplyRequired=false;
			if(undefined == $scope) {
				$scope = DeploymentDetails.getDeploymentDetailsControllerEleScopeEle();
				isApplyRequired=true;
			}
			showUpdateDeploymentDetailsScreen($scope);
			if(isApplyRequired) {
				$scope.$apply();
			}
		},
		getDeploymentDetails:function(){
			return getDeploymentDetails();
		},
		updateDeploymentDetails:function($scope){
			updateDeploymentDetails($scope);
		},
		populateDeploymentDetailsScreen:function($scope) {
			  DeploymentDetails.populateDeploymentData($scope,DeploymentDetails.getDeploymentDetails());
		},
		populateDeploymentData:function($scope,deploymentDetails){
			$scope.showDeploymentDetails.deploymentDetails=deploymentDetails;
			if($scope.showDeploymentDetails.deploymentDetails && $scope.showDeploymentDetails.deploymentDetails.length>0) {
				  $scope.showDeploymentDetails.lastDeploymentTime=$scope.showDeploymentDetails.deploymentDetails[0].deploymentTime;
				  TopBar.updateLastDeployementTime($scope.showDeploymentDetails.lastDeploymentTime);
			  }
		},
		updateDeploymentDetailsOnBroadcast:function(deploymentDetails) {
			playAudioFile('NEW_DEPLOYMENT.mp3');
			var $scope=DeploymentDetails.getDeploymentDetailsControllerEleScopeEle();
			DeploymentDetails.populateDeploymentData($scope,deploymentDetails);
			$scope.$apply();
		}
};

function getDeploymentDetails() {
	var deployments=null;
	$.ajax({
		type : "GET",
		url : "getDeploymentDetails",
		cache : false,
		async : false,
		success : function(data) {
			deployments=data;
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
	return deployments;
}
function showUpdateDeploymentDetailsScreen($scope) {
	var deployments=getDeploymentDetails();
	if(null!=deployments){
		for(var index=0;index<deployments.length;index++){
			var deployment = deployments[index];
			if(index==0) {
				$scope.updateDeployment.serverName1=deployment.serverName;
				$scope.updateDeployment.url1=deployment.url;
				$scope.updateDeployment.db1=deployment.database;
				$scope.updateDeployment.id1=deployment.id;
			}else if(index==1) {
				$scope.updateDeployment.serverName2=deployment.serverName;
				$scope.updateDeployment.url2=deployment.url;
				$scope.updateDeployment.db2=deployment.database;
				$scope.updateDeployment.id2=deployment.id;
			}else if(index==2) {
				$scope.updateDeployment.serverName3=deployment.serverName;
				$scope.updateDeployment.url3=deployment.url;
				$scope.updateDeployment.db3=deployment.database;
				$scope.updateDeployment.id3=deployment.id;
			}else if(index==3) {
				$scope.updateDeployment.serverName4=deployment.serverName;
				$scope.updateDeployment.url4=deployment.url;
				$scope.updateDeployment.db4=deployment.database;
				$scope.updateDeployment.id4=deployment.id;
			}
		}	
	}
	showDeploymentScreen();
}

function updateDeploymentDetails($scope) {
	
	var deploymentDetailsList=[];
	var deploymentDetails1={
			"serverName": $scope.updateDeployment.serverName1,
			"url": $scope.updateDeployment.url1,
			"db": $scope.updateDeployment.db1,
			"id": $scope.updateDeployment.id1,
			"loggedInUser": $scope.updateDeployment.loggedInUser
	};
	deploymentDetailsList.push(deploymentDetails1);
	
	var deploymentDetails2={
			"serverName": $scope.updateDeployment.serverName2,
			"url": $scope.updateDeployment.url2,
			"db": $scope.updateDeployment.db2,
			"id": $scope.updateDeployment.id2,
			"loggedInUser": $scope.updateDeployment.loggedInUser
	};
	deploymentDetailsList.push(deploymentDetails2);
		
	var deploymentDetails3={
			"serverName": $scope.updateDeployment.serverName3,
			"url": $scope.updateDeployment.url3,
			"db": $scope.updateDeployment.db3,
			"id": $scope.updateDeployment.id3,
			"loggedInUser": $scope.updateDeployment.loggedInUser
	};
	deploymentDetailsList.push(deploymentDetails3);
	
	var deploymentDetails4={
			"serverName": $scope.updateDeployment.serverName4,
			"url": $scope.updateDeployment.url4,
			"db": $scope.updateDeployment.db4,
			"id": $scope.updateDeployment.id4,
			"loggedInUser": $scope.updateDeployment.loggedInUser
	};
	deploymentDetailsList.push(deploymentDetails4);
	
	var json=JSON.stringify(deploymentDetailsList);
	$.ajax({
		type : "GET",
		url : "submitDeployment",
		cache : false,
		data :{
			json:json
		},
		success : function(data) {
			var messages=data.split('#');
			if(messages[0]=='ERROR') {
				alertFailureMessage(messages[1],false);
			}else{
				playAudioFile('alert.mp3');
				alertSucessMessage(data,false);
				closeScreenOnSubmit('element_to_pop_up1');
			}
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}

