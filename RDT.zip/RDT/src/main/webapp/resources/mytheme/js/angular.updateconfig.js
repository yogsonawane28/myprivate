/***
 * Module: Deployment Details
 * Developer: YS
 * Technology: Angular JS
 */
var updateConfigControllerEle = document.querySelector('[data-ng-controller=updateConfigController]');
rdtApp.controller("updateConfigController", function($scope,$http) {  
	  $scope.updateConfig={};
	  $scope.updateConfig.title='Update Configurations';
	  $scope.updateConfig.configurations=UpdateConfig.getConfigurationDetails();
      $scope.update = function(){    
    	  UpdateConfig.updateConfigurationDetails($scope.updateConfig.configurations);
      };
}); 

var UpdateConfig={
		getUpdateConfigControllerScopeEle:function(){
			if(null==updateConfigControllerEle || undefined==updateConfigControllerEle) {
				updateConfigControllerEle = document.querySelector('[data-ng-controller=updateConfigController]');
			}
			return angular.element(updateConfigControllerEle).scope();
		},
		getConfigurationDetails:function(){
			return getConfigurationDetails();
		},
		updateConfigurationDetails:function(configurations){
			updateConfigurationDetails(configurations);
		}
};

function getConfigurationDetails() {
	var configurations=null;
	$.ajax({
		type : "GET",
		url : "getConfigurationDetails",
		cache : false,
		async : false,
		success : function(data) {
			configurations=data;
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
	return configurations;
}

function updateConfigurationDetails(configurations) {
	var json=JSON.stringify(configurations);
	$.ajax({
		type : "GET",
		url : "updateConfigurationDetails",
		cache : false,
		data :{
			json:json
		},
		success : function(data) {
			var messages=data.split('#');
			if(messages[0]=='ERROR') {
				alertFailureMessage(messages[1],false);
			}else{
				playAudioFile('alert.mp3');
				alertSucessMessage(data,false);
				closeScreenOnSubmit('element_to_pop_up11');
			}
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}

