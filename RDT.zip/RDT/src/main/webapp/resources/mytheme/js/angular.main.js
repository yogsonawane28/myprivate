/***
 * Module: Main Page
 * Developer: YS
 * Technology: Angular JS
 */
var rdtApp = angular.module('rdtApp', []);  
var rdtControllerEle = document.querySelector('[data-ng-controller=rdtController]');
rdtApp.controller("rdtController", function($scope,$http) {  
	var username = $.trim($('#person').val());
	if (username == null || username == '') {
		$scope.showMainPageContent=false;
	}else {
		$scope.showMainPageContent=true;
	}
}); 

var MainPage={
		getRdtControllerScopeEle:function(){
			if(null==rdtControllerEle || undefined==rdtControllerEle) {
				rdtControllerEle = document.querySelector('[data-ng-controller=rdtController]');
			}
			return angular.element(rdtControllerEle).scope();
		}
};