/***
 * Module: Auto Login Executor
 * Developer: YS
 * Technology: Angular JS
 */
var autoLoginExeControllerEle = document.querySelector('[data-ng-controller=autoLoginExeController]');
rdtApp.controller("autoLoginExeController", function($scope,$http) {  
	$scope.autoLoginExe={};
	$scope.autoLoginExe.title='Auto Login Executor';
	$scope.autoLoginExe.messageClassName='missing-details';
	$scope.autoLoginExe.message="Sorry, We are unable to find your details in the system. Let's try to fix this.";
	$scope.autoLoginExe.userName='';
	$scope.autoLoginExe.ip='';
	$scope.autoLoginExe.showErrorMessage=false;
	$scope.update = function(){  
		$scope.autoLoginExe.showErrorMessage=true;
		AutoLoginExe.getUserDetails($scope);
    };
    $scope.onNameBlur = function(){    
    	$scope.autoLoginExe.userName=$.trim($('.autologin-username').val()).capitalizeFirstLetter();      	
    };
  
}); 

var AutoLoginExe={
		getUserDetails:function($scope) {
			getUserDetails($scope);
		}
};

function getUserDetails($scope) {	
	if(!$scope.autoLoginExe.userName){
		return false;
	}
	
	$.ajax({
		type : "GET",
		url : "getUserDetails",
		cache : false,
		data : {
			userName : $scope.autoLoginExe.userName
		},
		success : function(outputdata) {
			if(outputdata!='' && outputdata!=undefined && outputdata!=null){ 
				var userArr=outputdata.split("!,,!");
				if(userArr.length>1) {
					$scope.autoLoginExe.userName=userArr[0];
					$scope.autoLoginExe.ip=userArr[1];
					$scope.autoLoginExe.messageClassName='details-found';
					$scope.autoLoginExe.hideSubmitButton=true;
					$scope.autoLoginExe.message="Great, User name is found in the system. Give us some time to update the authentication.";
					var timeout=null;
					timeout=setTimeout(function() {
						submitUserDetails($scope);
						clearTimeout(timeout);
					}, 2000);
					
				}
			}else {
				$scope.autoLoginExe.ip='';
				$scope.autoLoginExe.messageClassName='missing-details';
				$scope.autoLoginExe.message="Oops.., User name does not exist. Please contact to our Administrator.";
			}
			$scope.$apply();
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}


function submitUserDetails($scope) {		
	if(!$scope.autoLoginExe.userName){
		AutoLoginExe.showErrorMessages();
		return false;
	}
	var hostName='';
	var jsonString=$scope.autoLoginExe.userName+'!,,!'+hostName+'!,,!'+$scope.autoLoginExe.ip;
	$.ajax({
		type : "GET",
		url : "submitUserDetails",
		cache : false,
		data :{
			jsonString:jsonString
		},
		success : function(data) {
			playAudioFile('alert.mp3');
			alertSucessMessage(data,true);
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}
