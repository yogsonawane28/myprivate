/***
 * Module: Change Log
 * Developer: YS
 * Technology: Angular JS
 */
var changeLogAppElement = document.querySelector('[data-ng-controller=changeLogController]');
rdtApp.controller("changeLogController", function($scope,$http) {  
	  $scope.changeLog={};
	  $scope.changeLog.title='Change Log';
	  $scope.changeLog.fromDate=$.datepicker.formatDate('dd M y', new Date());
	  $scope.changeLog.toDate=$.datepicker.formatDate('dd M y', new Date());
	  ChangeLog.show($scope);
	  
      $scope.show = function(){    
    	  ChangeLog.show($scope);
      }; 
      $scope.showInputKeyup = function($event){  
    	  if($event.which==13) { //Enter Key Press
    		 ChangeLog.show($scope);
    	  }
      };
      
      $scope.reset = function(){    
    	  ChangeLog.reset($scope);
    	  ChangeLog.show($scope);
      };
      
      $scope.showDefectDetails = function($this){ 
    	  showSearchDefect($this.log.defectId);
      };
}); 


var ChangeLog={
		getChangeLogScopeEle:function(){
			if(null==changeLogAppElement || undefined==changeLogAppElement) {
				changeLogAppElement = document.querySelector('[data-ng-controller=changeLogController]');
			}
			return angular.element(changeLogAppElement).scope();
		},
		getChangeLogs:function($scope){
			return getChangeLogs($scope);
		},
		pushToChangeLog:function(changeLog){
			var $scope=ChangeLog.getChangeLogScopeEle();
			if($scope.changeLog.lastestMessageId==0 || $scope.changeLog.lastestMessageId<changeLog.changeLogId) {
				$scope.changeLogs.unshift(changeLog);
				$scope.changeLog.lastestMessageId=changeLog.changeLogId;
				$scope.$apply();
			}
		},
		reset:function($scope){
			$scope.changeLog.defectId='';
			$scope.changeLog.actingUser='';
			$scope.changeLog.eventType='';
			$scope.changeLog.fromDate=$.datepicker.formatDate('dd M y', new Date());
			$scope.changeLog.toDate=$.datepicker.formatDate('dd M y', new Date());
		},
		show:function($scope){
			 $scope.changeLogs=ChangeLog.getChangeLogs($scope);
			 ChangeLog.updateLastChangeLogId($scope);
		},
		updateLastChangeLogId: function($scope) {
	    	  if(!jQuery.isEmptyObject($scope.changeLogs)) {
	              $scope.changeLog.lastestMessageId=$scope.changeLogs[0].changeLogId;
	          }else {
	        	  $scope.changeLog.lastestMessageId=0;
	          }
	      }
};

function getChangeLogs($scope) {
	var changeLogs=null;
	var jsonObj={
			"defectId":$scope.changeLog.defectId,
			"actingUser":$scope.changeLog.actingUser,
			"eventType":$scope.changeLog.eventType,
			"fromDate":$scope.changeLog.fromDate,
			"toDate":$scope.changeLog.toDate
	};

	var json=JSON.stringify(jsonObj);
	$.ajax({
		type : "GET",
		url : "getChangeLogs",
		cache : false,
		async: false,
		data :{
			json:json
		},
		success : function(data) {	
			changeLogs = data;
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
	return changeLogs;
}

