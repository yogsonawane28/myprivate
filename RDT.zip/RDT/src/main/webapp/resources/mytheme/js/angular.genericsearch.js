/***
 * Module: Generic Search
 * Developer: YS
 * Technology: Angular JS
 */
var genericSearchAppElement = document.querySelector('[data-ng-controller=genericSearchInputsController]');
rdtApp.controller("genericSearchInputsController", function($scope,$http) {  
	  $scope.genericSearch={};
	  $scope.genericSearch.title='Search';
      $scope.search = function(){    
    	  GenericSearch.search($scope);
      }; 
      $scope.reset = function(){    
    	  GenericSearch.reset($scope);
    	  GenericSearch.enableDisableInputs($scope);
      };
      $scope.searchInputKeyup = function($event){  
    	  if($event.which==13) { //Enter Key Press
    		  GenericSearch.search($scope);
    	  }
      };
      $scope.wildInputKeyup = function(){    
    	  GenericSearch.enableDisableInputs($scope);
      };
   
}); 

var GenericSearch={
		getGenericSearchScopeEle:function(){
			if(null==genericSearchAppElement || undefined==genericSearchAppElement) {
				genericSearchAppElement = document.querySelector('[data-ng-controller=genericSearchInputsController]');
			}
			return angular.element(genericSearchAppElement).scope();
		},
		enableDisableInputs: function($scope) {
	        if($scope.genericSearch.wildInput==''){
	    		  $scope.genericSearch.nonWildInputDisabled=false;
	    		  $scope.genericSearch.disabledClass='';  		
	  		}else{
	  			GenericSearch.reset($scope,true);
	  			$scope.genericSearch.nonWildInputDisabled=true;
	  			$scope.genericSearch.disabledClass='disabled-background';
	  		}
	    },
		getGenericSearchResultScopeEle:function(){
			if(null==genericSearchResultAppElement || undefined==genericSearchResultAppElement) {
				genericSearchResultAppElement = document.querySelector('[data-ng-controller=genericSearchResultController]');
			}
			return angular.element(genericSearchResultAppElement).scope();
		},
		reset:function($scope,isSkipWildInput){
			$scope.genericSearch.nonWildInputDisabled=false;
			$scope.genericSearch.select=''; 
			$scope.genericSearch.defectId='';
			$scope.genericSearch.moduleName='';
			$scope.genericSearch.defectDesc='';
			$scope.genericSearch.reportedBy='';
			$scope.genericSearch.assignedTo='';
			$scope.genericSearch.priority='';
			$scope.genericSearch.severity='';
			$scope.genericSearch.status='';
			$scope.genericSearch.isClientDefect='';
			if(!isSkipWildInput) { 
				$scope.genericSearch.wildInput='';
			}
		},
		search:function($scope){
			if(!$scope.genericSearch.defectId && !$scope.genericSearch.moduleName && !$scope.genericSearch.defectDesc &&
					!$scope.genericSearch.reportedBy && !$scope.genericSearch.assignedTo && !$scope.genericSearch.priority &&
					!$scope.genericSearch.severity && !$scope.genericSearch.status && !$scope.genericSearch.wildInput) {
				sweetAlert("",'Defect list may be long. Please enter your search criteria.', "error");
				return false;
			}else if($scope.genericSearch.defectId && isNaN($scope.genericSearch.defectId)) {
				sweetAlert("",'Only numbers are allowed for Defect id', "error");
				return false;
			}
			getGenericSearch($scope);
		},
		showDefectDetails:function(defect) {
			var $scope=GenericSearch.getGenericSearchResultScopeEle();
			$scope.searchDefect.status=defect.status;
			$scope.genericSearchResult.title='Defect Details: '+defect.defectId;
			$scope.searchDefect.defectId=defect.defectId;
			$scope.searchDefect.isClientDefect=defect.isClientDefect;
			$scope.searchDefect.moduleName=defect.moduleName;
			
			if(defect.isClientDefect=='YES') {
				$scope.searchDefect.clientDefectClassName='sirDescBackgrount';
			}else {
				$scope.searchDefect.clientDefectClassName='';
			}
			$scope.searchDefect.defectDesc=defect.desc;
			if(defect.priority=='HIGH') {
				$scope.searchDefect.priorityClassName='highprioritydefect';
			}else if(defect.priority=='BLOCKER'){
				$scope.searchDefect.priorityClassName='blockerdefect';
			}else{
				$scope.searchDefect.priorityClassName='';
			}
			$scope.searchDefect.priority=defect.priority;
			if(defect.severity=='CRITICAL') {
				$scope.searchDefect.severityClassName='criticalseveritydefect';
			}else{
				$scope.searchDefect.severityClassName='';
			}
			$scope.searchDefect.severity=defect.severity;
			$scope.searchDefect.linkedId=defect.linkedDefectId;
			$scope.searchDefect.linkedDefectCount=defect.linkedDefectCount;
			if($scope.searchDefect.linkedDefectCount) {
				$scope.searchDefect.linkedDefectCountClassName='linkeddefectcount';
			}else {
				$scope.searchDefect.linkedDefectCountClassName='';
				$scope.searchDefect.linkedDefectCount=0;
			}
			$scope.searchDefect.reportedBy=getValue(defect.reportedby);
			$scope.searchDefect.assignedTo=getValue(defect.assignedto);
			$scope.searchDefect.reviewer=getValue(defect.reviewer);
			$scope.searchDefect.reopenCount=getValue(defect.reopenCount);
			if(defect.status=='CLOSED') {
				$scope.searchDefect.statusClassName='closedstatusdefect';
			}else{
				$scope.searchDefect.statusClassName='';
			}
			$scope.searchDefect.status=defect.status;
			$scope.searchDefect.isOnHold=defect.isOnHold;
			if(defect.isOnHold=='YES') {
				$scope.searchDefect.isOnHoldClassName='onhold';
			}else{
				$scope.searchDefect.isOnHoldClassName='';
			}
			$scope.searchDefect.comment=getValue(defect.comment);
			$scope.searchDefect.attachment=getValue(defect.location);
			$scope.searchDefect.testLogs=getValue(defect.rcaLocation);
			$scope.searchDefect.rca=getValue(defect.analysis);	
			$scope.searchDefect.reportedTime=getValue(defect.reporttime);
			$scope.searchDefect.lastUpdatedBy=defect.lastupdatedby;
			$scope.searchDefect.pded=defect.pded;
			$scope.searchDefect.aded=defect.aded;
			$scope.searchDefect.pted=defect.pted;
			$scope.searchDefect.ated=defect.ated;
			$scope.$apply();
		}
};

function getGenericSearch($scope) {
	var jsonObj={
			"defectId":$scope.genericSearch.defectId,
			"moduleName":$scope.genericSearch.moduleName,
			"defectDesc":$scope.genericSearch.defectDesc,
			"reportedBy":$scope.genericSearch.reportedBy,
			"assignedTo":$scope.genericSearch.assignedTo,
			"priority":$scope.genericSearch.priority,
			"severity":$scope.genericSearch.severity,
			"status":$scope.genericSearch.status,
			"isClientDefect":$scope.genericSearch.isClientDefect,
			"wildInput":$scope.genericSearch.wildInput
	};

	var json=JSON.stringify(jsonObj);
	$.ajax({
		type : "GET",
		url : "getGenericSearch",
		cache : false,
		data :{
			json:json
		},
		success : function(outputdata) {
			if(outputdata=='') {
				sweetAlert("",'No defects are available for given inputs. Please refine your search criteria.', "error");
				return false;
			}else {
				showDefectSearchScreen();
				$('.defectSearchTable tbody').html(outputdata);
			}
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}

var genericSearchResultAppElement = document.querySelector('[data-ng-controller=genericSearchResultController]');
rdtApp.controller("genericSearchResultController", function($scope,$http) {  
	  $scope.genericSearchResult={};
	  $scope.genericSearchResult.title='Defect Details';
	  $scope.searchDefect={};
	  $scope.downloadAttachment = function() {
		  downloadattached($scope.searchDefect.attachment);
	  };
	  $scope.downloadTestLogs = function() {
		  downloadattached($scope.searchDefect.testLogs);
	  };
}); 

function showSearchDefect(id){
	$.ajax({
		type : "GET",
		url : "getEditDefectDetails",
		cache : false,
		data : {
			defectId : id
		},
		success : function(defect) {
			if(null ==defect) {
				sweetAlert("Oops...",'Defect details are not found', "error");
				return
			}
			GenericSearch.showDefectDetails(defect);
			showSelectedDefectSearchScreen();
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}

