/***
 * Module: Top bar
 * Developer: YS
 * Technology: Angular JS
 */
var topBarControllerEle = document.querySelector('[data-ng-controller=topBarController]');
rdtApp.controller("topBarController", function($scope,$http) {  
	  $scope.refresh = function() {
		  updateUserView(true);  
	  };
	  $scope.showDeploymentDetails = function() {
		  TopBar.showDeploymentDetailsScreen();
	  };
}); 

var TopBar={
		getTopBarControllerEleScopeEle:function() {
			if(null==topBarControllerEle || undefined==topBarControllerEle) {
				topBarControllerEle = document.querySelector('[data-ng-controller=topBarController]');
			}
			return angular.element(topBarControllerEle).scope();
		},
		showDeploymentDetailsScreen:function () {
			showDeploymentDetailsScreen();
		},
		updateLastDeployementTime:function(lastDeploymentTime) {
			var $scope=TopBar.getTopBarControllerEleScopeEle();
			$scope.lastDeploymentTime=lastDeploymentTime;
			//$scope.$apply();
		}
};