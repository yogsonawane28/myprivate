var errorMessage='Looks like something went wrong on our end. Please contact administrator.';

function getRandomNumber(limit){
		return Math.floor(Math.random() * limit);
}

function alertFailureMessage(message,reloadOnOk) {
	sweetAlert({
		  title: "Oops!",
		  text: message,
		  type: "warning",
		  showCancelButton: false,
		  confirmButtonColor: "#DD6B55",
		  confirmButtonText: "Ok",
		  closeOnConfirm: true
		},
		function(){
			if(reloadOnOk){
				window.location.reload(true);
			}
		});
}

playAudioFile = function(audioname) {
	var delay=2000; //2 seconds
	setTimeout(function(){
		var src = 'resources/js/'+audioname;
		$('#play-audio').attr('src', src);
		var thisSound = document.getElementById('play-audio');
		try {
			thisSound.play();
		} catch (e) {
			sweetAlert("It's Not You, It's Us...","Error occured durring playing a file", "error");
			return;
		}
	}, delay); 
};

function confirmBox(message,$function,confirmButtonText) {
	if(undefined==confirmButtonText){
		confirmButtonText="Yes, do it!";
	}
	sweetAlert({
		  title: "Are you sure?",
		  text: message,
		  type: "info",
		  showCancelButton: true,
		  confirmButtonColor: "#DD6B55",
		  confirmButtonText: confirmButtonText,
		  closeOnConfirm: false
		},
		$function);
}

function alertSucessMessage(message,reloadOnOk) {
	sweetAlert({
		  title: "Great!",
		  text: message,
		  type: "success",
		  showCancelButton: false,
		  confirmButtonColor: "#DD6B55",
		  confirmButtonText: "Ok",
		  closeOnConfirm: true
		},
		function(){
			if(reloadOnOk){
				window.location.reload(true);
			}
		});
}

function showBroadcastNotification(){
	$('.broadcastmsg').trigger('click');
}

function showErrorScreen(){
	$('.failuremsg').trigger('click');
}

function closeScreenOnSubmit(id) {
	$('#'+id).find('.b-close').trigger('click');
}

function tog(v){return v?'addClass':'removeClass';} 
$(document).on('input', '.clearable', function(){
    $(this)[tog(this.value)]('x');
}).on('mousemove', '.x', function( e ){
    $(this)[tog(this.offsetWidth-18 < e.clientX-this.getBoundingClientRect().left)]('onX');
}).on('touchstart click', '.onX', function( ev ){
    ev.preventDefault();
    $(this).removeClass('x onX').val('').change();
    $(this).keyup();
});