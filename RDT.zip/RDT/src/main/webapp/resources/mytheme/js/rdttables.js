/***
 * Module: RDT Tables
 * Developer: YS
 * Technology: JavaScript, DataTable Plugin
 */
$(document ).ready(function() {
	var $tab=$("li."+DataTable.getStoredTabName()+" a");
	if($tab.length<1) {
		$tab=$("li.OPEN a");
	}
	$tab.trigger('click');
	DataTable.initDataTable(true);
	DisplayDefects.getDefectsCounts();
	bindTabClick();
	DataTable.bindViewDetailsClick();
});

bindTabClick=function() {
	$('.nav-tabs li a').on('click', function(e) {
		if($(this).parents('li').hasClass('active')) {
			return false;
		}
		if($(this).hasClass('expand-defect-details')) {
			if($('.dataTables_scrollBody').height()>255) {
				$('.dataTables_scrollBody').height(255);
			}else{
				$('.dataTables_scrollBody').height('auto');
			}
		}else if(!$(this).hasClass('export')){
			$('#selectedId').val('');
			DataTable.storeTabName($(this).parents('li').attr('data-tab-name'));
			clearStore();
			DisplayDefects.updateDefectDetails(undefined,undefined,false);
		}
	});
};
var DataTable= {
		dataTable:null,
		footerFilters:{},
		clearDataTable:function() {
			dataTable.clear();
		},
		drawDataTable:function() {
			dataTable.draw();
		},
		destroyDataTable:function() {
			dataTable.destroy();
		},
		initialize:function(isOnLoad) {
			var table= $(".datatable").DataTable( {
	            "order": [[ 0, "desc" ]],
				 stateSave: true,
				 "stateLoadParams": function (settings, data) {
					 if(isOnLoad) {
						 var filters=DataTable.getStoredFooterFilters();
						 if(filters){
						 	$.each(filters, function(key, val) {
						           $('.datatable tfoot input[placeholder="'+key+'"]').val(val);
						      });
						 } 
					 }
				 },
				 "autoWidth": false,
				 "lengthMenu": [[10,20,30,50,-1], [10,20,30,50,"All"]],
				 "scrollY": 255,
			     "scrollX": true
	        });
	       dataTable=table;
	       return table;
		},
		getInfoText:function() {
			var html='<div> <span class="linkeddefectcount">LDC: Linked Defect Count (No. of defects found)</span> <span class="rcount">RC: Reopen Count</span></div>';
			return html;
		},
		convertFooterToInputs:function() {
			if($('.datatable tfoot th input').length<1) {
				$('.datatable tfoot th').each( function () {
					var index=$(this).index();
		            var title = $('.datatable thead th').eq(index).text();
		            var headerWidth=$('.datatable thead th').eq(index).width();
		            var clearable='clearable';
		            if(index==0) {
		            	clearable='';
		            }else {
		            	headerWidth=headerWidth<63?63:headerWidth;
		            }
		           $(this).html('<input type="text" class="footer-search '+clearable+'" style="width:'+headerWidth+'px" placeholder="'+title+'"/>' );
		        });
			}
		},
		bindPopupOverview:function() {
			 $("[data-toggle=popover]").popover();
	         $(".popover-dismiss").popover({trigger: 'focus'});
	        
		},
		initDataTable:function(isOnLoad){
			if($(".datatable").length > 0){ 
				DataTable.convertFooterToInputs();
		    	var table=DataTable.initialize(isOnLoad);
		    	DataTable.bindFooterSearch(table);
		    	DataTable.addClearableClass();
		    	addClearableButton($('.scrolldiv'));
		    }  
		},
		bindViewDetailsClick:function() {
			$(document).on('click', '.expand-column', function(event){
				if($(this).css('white-space')!='normal') {
					$(this).css('white-space','normal');
				}else{
					$(this).css('white-space','nowrap');
				}
			});
	        
		},
		bindFooterSearch:function(table) {
			 // Apply the search
		   table.columns().every( function () {
		          var that = this;
		          $( 'input', this.footer() ).on( 'keyup change', function () {
		        	  DataTable.storeFooterFilters($(this).attr('placeholder'), this.value);
		              if ( that.search() !== this.value ) {
		                  that.search( this.value ) .draw();
		              }
		           });
		    });
		},
		addClearableClass:function() {
			$('.scrolldiv').find('input[type=search]').addClass('clearable');
			$('.scrolldiv').find('input[type=search]').addClass('common-search');
		},
        storeTabName:function(tabName) {
        	localStorage['selectedTabName'] = tabName;
        },
        getStoredTabName:function() {
        	var tabName=localStorage['selectedTabName'];
        	if(!tabName) {
        		tabName='OPEN';
        	}
        	return tabName;
        },
        storeFooterFilters:function(column,value) {
        	DataTable.footerFilters[column] = value;
        	localStorage['footerFilters'] = JSON.stringify(DataTable.footerFilters);
        },
        getStoredFooterFilters:function() {
        	if(localStorage['footerFilters']) {
        		return JSON.parse(localStorage['footerFilters']);
        	}else {
        		return null;
        	}
        },
};

function throttle(func, milliseconds) {
    var lastCall = 0;
    return function () {
        var now = Date.now();
        if (lastCall + milliseconds < now) {
            lastCall = now;
            return func.apply(this, arguments);
        }else {
        	 console.info('rejecting search');
        }
    };
}