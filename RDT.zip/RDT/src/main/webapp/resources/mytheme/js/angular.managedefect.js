/***
 * Module: Enter Defect
 * Developer: YS
 * Technology: Angular JS
 */
var enterDefectAppElement = document.querySelector('[data-ng-controller=EnterDefectController]');

//Controller
rdtApp.controller("EnterDefectController", function($scope, EnterDefectService) {  
        $scope.enterDefect = {};  
        $scope.enterDefect.title = "Register Defect"; 
        $scope.enterDefect.moduleNames = SELECT_LIST.MODULE_NAMES;
        $scope.enterDefect.showErrorMessage=false;
        $scope.submit = function(){   
        	$scope.enterDefect.showErrorMessage=true;
        	EnterDefectService.submit($scope);
        }; 
        $scope.reset = function(){
        	EnterDefectService.reset($scope);
        };
        $scope.onNameBlur = function(){    
        	EnterDefectService.capitalizeFirstLetter($scope);      	
        };
       
});  

//Service
rdtApp.service("EnterDefectService", function(EnterDefectFactory) {
	this.submit = function($scope) {
		EnterDefectFactory.submit($scope);
	};
	this.reset = function($scope) {
		EnterDefectFactory.reset($scope);
	};
	this.capitalizeFirstLetter = function($scope) {
		EnterDefectFactory.capitalizeFirstLetter($scope);
	};
});

//Factory
rdtApp.factory("EnterDefectFactory", function() {
	var factory = {};
	factory.submit = function($scope) {
		if(!$scope.enterDefect.shortDesc || !$scope.enterDefect.isClientDefect || !$scope.enterDefect.moduleName ||
				!$scope.enterDefect.descSteps || !$scope.enterDefect.actualResult ||  !$scope.enterDefect.expectedResult ||
				!$scope.enterDefect.severity || !$scope.enterDefect.priority || !$scope.enterDefect.reportedBy || 
				!$scope.enterDefect.tobeFixedIn) {
			return false;
		}else if($scope.enterDefect.linkedDefectId && isNaN($scope.enterDefect.linkedDefectId)) {
			sweetAlert("",'Only numbers are allowed for Linked defect id', "error");
			return false;
		}
		var json=factory.getJson($scope);
		EnterDefect.send(json);
	
	};
	factory.getJson =function($scope) {
		var desc=$scope.enterDefect.shortDesc+' | '+
		 'Steps: '+$scope.enterDefect.descSteps+' | '+
		 'Actual Result: '+$scope.enterDefect.actualResult+' | '+
		 'Expected Result: '+$scope.enterDefect.expectedResult;
		var isDeliverableNow='';
		var isDeliverableInFuture='';
		var isDeliverableFirst='';
		var isDeliverableSecond='';
		if($scope.enterDefect.tobeFixedIn=='NOW') {
			 isDeliverableNow='YES';
		}else if($scope.enterDefect.tobeFixedIn=='NEXT'){
			 isDeliverableInFuture='YES';
		}else if($scope.enterDefect.tobeFixedIn=='FIRST'){
			 isDeliverableFirst='YES';
		}else if($scope.enterDefect.tobeFixedIn=='SECOND'){
			 isDeliverableSecond='YES';
		}
		var json={
				"moduleName":$scope.enterDefect.moduleName,
				"priority":$scope.enterDefect.priority,
				"desc":desc,
				"reportedby":$scope.enterDefect.reportedBy,
				"comment":$scope.enterDefect.comment,
				"status":$scope.enterDefect.status,
				"analysis":'',
				"location":$scope.enterDefect.fileName,
				"rcaLocation":'',
				"lastupdatedby":$scope.enterDefect.loggedInUser,
				"severity":$scope.enterDefect.severity,
				"isDeliverableNow":isDeliverableNow,
				"isDeliverableInFuture":isDeliverableInFuture,
				"isDeliverableForFirst":isDeliverableFirst,
				"isDeliverableForSecond":isDeliverableSecond,
				"reopenCount":0,
				"isClientDefect":$scope.enterDefect.isClientDefect,
				"linkedDefectId":$scope.enterDefect.linkedDefectId,
				"requesttype":"add"
		};
		return json;
	};
	factory.reset = function($scope) {
		EnterDefect.showSubmitButton($scope);
		$scope.enterDefect.showErrorMessage=false;
		$scope.enterDefect.shortDesc='';
		$scope.enterDefect.isClientDefect='';
		$scope.enterDefect.moduleName='';
		$scope.enterDefect.descSteps='';
		$scope.enterDefect.actualResult='';
		$scope.enterDefect.expectedResult='';
		$scope.enterDefect.severity='';
		$scope.enterDefect.priority='';
		$scope.enterDefect.reportedBy=$scope.enterDefect.loggedInUser;
		$scope.enterDefect.fileName='';
		$('input[type=file]').val('');
		$scope.enterDefect.tobeFixedIn='';
		$scope.enterDefect.status='UNASSIGNED';
		$scope.enterDefect.comment='';
		ManageDefect.removeFileUploadMessage();
		$('.focus-it').focus();
	};
	factory.capitalizeFirstLetter = function($scope) {
		$scope.enterDefect.reportedBy=$.trim($('.reported-by').val()).capitalizeFirstLetter();
	};
	return factory;
});

var ManageDefect={
		isEnterDefectOpened:function(){
			return $('.enter-defect-title').is(':visible');
		},
		isUpdateDefectOpened:function(){
			return $('.update-defect-title').is(':visible');
		},
		removeFileUploadMessage:function(){
			$(".file-upload-message").html('');
		}
};

var EnterDefect={
		getEnterDefectScopeEle:function(){
			if(null==enterDefectAppElement || undefined==enterDefectAppElement) {
				enterDefectAppElement = document.querySelector('[data-ng-controller=EnterDefectController]');
			}
			return angular.element(enterDefectAppElement).scope();
		},
		setAttachmentName:function(fileName) {
			var $scope = EnterDefect.getEnterDefectScopeEle();
			$scope.enterDefect.fileName = fileName;
			$scope.$apply();
		},
		resetOnScreenOpen:function(username) {
			var $scope = EnterDefect.getEnterDefectScopeEle();
			$scope.enterDefect.loggedInUser=username;
			$scope.reset($scope);
			$scope.$apply();
		},
		hideSubmitButton:function($scope) {
			$scope.enterDefect.hideSubmitButton=true;
		},
		showSubmitButton:function($scope) {
			$scope.enterDefect.hideSubmitButton=false;
		},
		send:function(jsonObject) {
			var jsonString=JSON.stringify(jsonObject);
			$.ajax({
				type : "GET",
				url : "submitDefect.html",
				cache : false,
				data :{
					jsonString:jsonString
				},
				success : function(data) {
					var messages=data.split('#');
					if(messages[0]=='ERROR') {
						alertFailureMessage(messages[1],false);
					}else{
						playAudioFile('alert.mp3');
						alertSucessMessage(messages[1],false);
						closeScreenOnSubmit('element_to_pop_up3');
					}
				},
				complete : function() {
				},
				error : function(error) {
					sweetAlert("It's Not You, It's Us...",errorMessage, "error");
				}
			});
		}
};


/***
 * Module: Update Defect
 * Developer: YS
 * Technology: Angular JS
 */
var updateDefectAppElement = document.querySelector('[data-ng-controller=UpdateDefectController]');
rdtApp.controller("UpdateDefectController", function($scope,UpdateDefectService) {  
        $scope.updateDefect = {};  
        $scope.updateDefect.title = "Update Defect"; 
        $scope.updateDefect.moduleNames = SELECT_LIST.MODULE_NAMES;
        $scope.updateDefect.defectStates = SELECT_LIST.DEFECT_STATES;
        $scope.updateDefect.showErrorMessage=false;
        $scope.submit = function(){    
        	$scope.updateDefect.showErrorMessage=true;
        	UpdateDefectService.submit($scope);
        };
        $scope.reset = function(){    
        	UpdateDefectService.reset($scope);
        };
        $scope.onStatusChange= function() {
        	UpdateDefectService.statusChange($scope);
        };
        $scope.onNameBlur = function(){    
        	UpdateDefectService.capitalizeFirstLetter($scope);
        };
});  

//Service
rdtApp.service("UpdateDefectService", function(UpdateDefectFactory) {
	this.submit = function($scope) {
		UpdateDefectFactory.submit($scope);
	};
	this.reset = function($scope) {
		UpdateDefectFactory.reset($scope);
	};
	this.capitalizeFirstLetter = function($scope) {
		UpdateDefectFactory.capitalizeFirstLetter($scope);
	};
	this.statusChange = function($scope) {
		UpdateDefectFactory.statusChange($scope);
	};
});

//Factory
rdtApp.factory("UpdateDefectFactory", function() {
	var factory = {};
	factory.submit = function($scope) {
		if(!$scope.updateDefect.defectDesc || !$scope.updateDefect.isClientDefect || !$scope.updateDefect.moduleName ||
				!$scope.updateDefect.status || !$scope.updateDefect.severity || !$scope.updateDefect.priority ||
				!$scope.updateDefect.reportedBy) {
			return false;
		}else if(($scope.updateDefect.status =='FIXED' || $scope.updateDefect.status =='RTT') && !$scope.updateDefect.rca) {
			$scope.updateDefect.rcaError=true;
			return false;
		}else if(OPTION_ACCESS.indexOf('CAN_CLOSE')<0 && $scope.updateDefect.status=='CLOSED'){
			sweetAlert("It's Not Us, It's You...",'Something seriously went wrong, You are not suppose to do this!', "error");
			return false;
		}else if($scope.updateDefect.linkedDefectId && isNaN($scope.updateDefect.linkedDefectId)) {
			sweetAlert("",'Only numbers are allowed for Linked defect id', "error");
			return false;
		}
		var json=factory.getJson($scope);
		var $function=function(){
			UpdateDefect.send(json);
		};

		if($scope.updateDefect.oldStatus!='DEFERRED' && $scope.updateDefect.status=='DEFERRED'){
			confirmBox("Have you discussed with Tester? Also please mention deferred reason in the comment!",$function,'Yes, Roger that!');
		}else if($scope.updateDefect.oldStatus!='REJECTED' && $scope.updateDefect.status=='REJECTED'){
			confirmBox("Have you discussed with Tester? Also please mention rejected reason in the comment!",$function,'Yes, Roger that!');
		}else if($scope.updateDefect.oldStatus!='REOPENED' && $scope.updateDefect.status=='REOPENED'){
			confirmBox("Have you discussed with Developer? Also please mention reopen reason in the comment!",$function,'Yes, Roger that!');
		}else {
			UpdateDefect.send(json);
		}
	
	};
	factory.getJson =function($scope) {
		var json= {
			"defectId":$scope.updateDefect.defectId,
			"moduleName":$scope.updateDefect.moduleName,
			"priority":$scope.updateDefect.priority,
			"desc":$scope.updateDefect.defectDesc,
			"reportedby":$scope.updateDefect.reportedBy,
			"assignedto":$scope.updateDefect.assignedTo,
			"reporttime":$scope.updateDefect.reportedTime,
			"comment":$scope.updateDefect.comment,
			"status":$scope.updateDefect.status,
			"analysis":$scope.updateDefect.rca,
			"rcaLocation" :$scope.updateDefect.testLogs,
			"location":$scope.updateDefect.fileName,
			"lastupdatedby":$scope.updateDefect.loggedInUser,
			"isDeliverableNow":$scope.updateDefect.isDeliNow,
			"isDeliverableInFuture":$scope.updateDefect.isDeliFuture,
			"isDeliverableForFirst":$scope.updateDefect.isDeliFirst,
			"isDeliverableForSecond":$scope.updateDefect.isDeliSecond,
			"severity":$scope.updateDefect.severity,
			"reopenCount":(''!=$scope.updateDefect.oldReopenCount)?parseInt($scope.updateDefect.oldReopenCount):0,
			"requesttype":"update",
			"pded":$scope.updateDefect.ded,
			"pted":$scope.updateDefect.ted,
			"isClientDefect":$scope.updateDefect.isClientDefect,
			"linkedDefectId":$scope.updateDefect.linkedDefectId,
			"oldLinkedDefectId":$scope.updateDefect.oldLinkedDefectId,
			"reviewer":$scope.updateDefect.reviewer
		};
		return json;
	};
	factory.reset =function($scope) {
		$scope.updateDefect.showErrorMessage=false;
		UpdateDefect.showSubmitButton($scope);
		UpdateDefect.populateOnScreenOpen($scope.updateDefect.defectObj,$scope.updateDefect.loggedInUser,false);
		addClearableButton($('#element_to_pop_up4'));
		$('.focus-edit-it').focus();
	};
	factory.capitalizeFirstLetter =function($scope) {
		$scope.updateDefect.reportedBy=$.trim($('.reported-by-edit').val()).capitalizeFirstLetter();  
    	$scope.updateDefect.assignedTo=$.trim($('.assigned-to-edit').val()).capitalizeFirstLetter();
    	$scope.updateDefect.reviewer=$.trim($('.reviewer').val()).capitalizeFirstLetter();
	};
	factory.statusChange =function($scope) {
		if($scope.updateDefect.status == 'FIXED' || $scope.updateDefect.status == 'RTT') {
			$scope.updateDefect.rcaMandatory=true;
			$scope.updateDefect.rcaError=true;
		} else {
			$scope.updateDefect.rcaMandatory=false;
			$scope.updateDefect.rcaError=false;
		}
	};
	return factory;
});

var UpdateDefect={
		getUpdateDefectScopeEle:function(){
			if(null==updateDefectAppElement || undefined==updateDefectAppElement) {
				updateDefectAppElement = document.querySelector('[data-ng-controller=UpdateDefectController]');
			}
			return angular.element(updateDefectAppElement).scope();
		},
		setAttachmentName:function(fileName) {
			var $scope = UpdateDefect.getUpdateDefectScopeEle();
			$scope.updateDefect.testLogs = fileName;
			$scope.$apply();
		},
		hideSubmitButton:function($scope) {
			$scope.updateDefect.hideSubmitButton=true;
		},
		showSubmitButton:function($scope) {
			$scope.updateDefect.hideSubmitButton=false;
		},
		populateOnScreenOpen:function(defect,username,doApply) {
			var $scope = UpdateDefect.getUpdateDefectScopeEle();
			$scope.updateDefect.showErrorMessage=false;
			ManageDefect.removeFileUploadMessage();
			UpdateDefect.showSubmitButton($scope);
			$scope.updateDefect.status=defect.status;
			if($scope.updateDefect.status == 'FIXED' || $scope.updateDefect.status == 'RTT') {
				$scope.updateDefect.rcaMandatory=true;
			} else {
				$scope.updateDefect.rcaMandatory=false;
			}
			$scope.updateDefect.status=defect.status;
			$scope.updateDefect.testLogs=getValue(defect.rcaLocation);
			$scope.updateDefect.title='Update a Defect: '+defect.defectId;
			$scope.updateDefect.moduleName=defect.moduleName;
			$scope.updateDefect.priority=defect.priority;
			$scope.updateDefect.defectDesc=defect.desc;
			$scope.updateDefect.reportedBy=getValue(defect.reportedby);
			$scope.updateDefect.assignedTo=getValue(defect.assignedto);
			$scope.updateDefect.comment=getValue(defect.comment);			
			$scope.updateDefect.rca=getValue(defect.analysis);
			$scope.updateDefect.oldStatus=defect.status;
			$scope.updateDefect.fileName=getValue(defect.location);
			$scope.updateDefect.defectId=defect.defectId+'--'+defect.versionNumber;
			$scope.updateDefect.reportedTime=getValue(defect.reporttime);
			$scope.updateDefect.isDeliNow=getValue(defect.isDeliverableNow);
			$scope.updateDefect.isDeliFuture=getValue(defect.isDeliverableInFuture);
			$scope.updateDefect.isDeliFirst=getValue(defect.isDeliverableForFirst);
			$scope.updateDefect.isDeliSecond=getValue(defect.isDeliverableForSecond);			
			$scope.updateDefect.severity=defect.severity;
			$scope.updateDefect.ded=getValue(defect.pded);
			$scope.updateDefect.ted=getValue(defect.pted);
			$scope.updateDefect.oldReopenCount=getValue(defect.reopenCount);
			$scope.updateDefect.reviewer=getValue(defect.reviewer);
			$scope.updateDefect.isClientDefect=defect.isClientDefect;
			$scope.updateDefect.linkedDefectId=defect.linkedDefectId;
			$scope.updateDefect.oldLinkedDefectId=defect.linkedDefectId;
			$scope.updateDefect.loggedInUser=username;
			$scope.updateDefect.defectObj=defect;
			if(doApply){
				$scope.$apply();
			}
		},
		send:function(json) {
			var jsonString=JSON.stringify(json);
			$.ajax({
				type : "GET",
				url : "submitDefect.html",
				cache : false,
				data :{
					jsonString:jsonString
				},
				success : function(data) {
					if(data=='obsolete') {
						alertFailureMessage('The content has been modified by another user. Click OK to reload the page.', true);
					}else {
						var messages=data.split('#');
						if(messages[0]=='ERROR') {
							alertFailureMessage(messages[1],false);
						}else{
							playAudioFile('alert.mp3');
							alertSucessMessage(messages[1],false);
							closeScreenOnSubmit('element_to_pop_up4');
						}
					}
				},
				complete : function() {
				},
				error : function(error) {
					sweetAlert("It's Not You, It's Us...",errorMessage, "error");
				}
			});
		}
};

function editDefect(defectId) {
	var username = $.trim($('#person').val());

	if(null==username || ''==username){
		sweetAlert("Oops...","Hello, You are requested to Sign In", "error");
		return false;
	}
	$.ajax({
		type : "GET",
		url : "getEditDefectDetails",
		cache : false,
		data : {
			defectId : defectId
		},
		success : function(defect) {	
			if(null==defect) {
				sweetAlert("Oops...",'Defect details are not found in the system', "error");
			}
			showEditDefectScreen();
			UpdateDefect.populateOnScreenOpen(defect,username,true);
			addClearableButton($('#element_to_pop_up4'));
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}
