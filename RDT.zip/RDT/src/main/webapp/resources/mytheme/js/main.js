var fadeintime=1600;
var fadeouttime=700;
var postponMessageInterval=5000;
var broadcastinterval=parseInt($('#broadcastinterval').val());
var broadcastintervalRem=broadcastinterval/1000;
var notificationinterval=parseInt($('#notificationInterval').val());
var autoscreencloseinterval=22;
var rttThreshold=parseInt($('#rttThreshold').val());
var fixedThreshold=parseInt($('#fixedThreshold').val());
var unassignedThreshold=parseInt($('#unassignedThreshold').val());
var timeout=null;
var timeinterval=null;
var postponCount=0;
var magicFactor=2.75;
var cntrlIsPressed=false;
var successMessageCloseDelay=1000;
var idArray=new Array();
//var effectArr=['slideIn','slideDown','slideBack','slideUp','fadeIn','fadeOut','slideIn','slideDown','slideBack','slideUp','fadeIn','fadeOut'];
var effectArr=['fadeIn'];
//var colorArr=['OrangeRed','blue','greenYellow','yellow','green','black','brown','orange','cyan','maroon','Aqua','blueViolet','chocolate','gold','navy','Aquamarine','BurlyWood','chartreuse','DarkMagenta'];
var colorArr=['black'];
var contextMenuItems={};


function escapeRegex(value) {
	return value.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
}

$(function() {
	$('.pagebody').removeClass('body-loader');
	var role=$.trim($('#role').val());
	bindEvents();
	var isValidUser=checkUserStatus();
	if(isValidUser){
		showMessageOnLogin();
		populateContextMenuOption(role);
	}
	//startIntelligentUpdateMachine(); startIntelligentUpdateMachine is turned off. This is used to auto refresh the gui.
});

function checkUserStatus() {
	var username = $.trim($('#person').val());
	if (username == null || username == '') {
		playAudioFile('NO_DETAILS.mp3');
		showUpdateUserScreen();
		return false;
	}else {
		return true;
	}
} 
function startIntelligentUpdateMachine(){
	reallocateBroadcastInterval();
	broadcastintervalRem=parseInt(broadcastinterval/1000);
	if(null!=timeout){
		clearTimeout(timeout);
	}
	if(null!=timeinterval){
		clearInterval(timeinterval);
	}
	timeinterval=setInterval(function(){ sendUpdateRequest(); }, broadcastinterval);
}

reallocateBroadcastInterval=function(){
	if(postponCount>-1 && broadcastinterval<=(999*1000)){
		broadcastinterval+=parseInt(postponCount*magicFactor*1000);
	}
};

sendUpdateRequest=function(){
	if(isValidRefresh()){
		$.ajax({
			type : "GET",
			url : "getUpdateStatus.html",
			cache : false,
			success : function(isUpdateRequired) {
				if(isUpdateRequired=='true'){
					updateUserView(false);
				}else{
					postponCount++;
					postponUpdateRequest('noupdate');
				}
			},
			complete : function() {
			},
			error : function(error) {
				sweetAlert("It's Not You, It's Us...", "Sit back and relax while we put the pieces back together.", "error");
			}
		});	
	}else{
		postponUpdateRequest('operationprogress');
	}
};

updateUserView=function(ignoreConfirmation){
	if(ignoreConfirmation) {
		window.location.reload(true);
		return;
	}else if(!$('#autorefresh').is(":checked")){
		return;
	}else{
		var isRefreshPostponed=false;
		sweetAlert({
			  title: "Auto Synchronization..",
			  text: "Your screen is going to be refreshed now!",
			  type: "info",
			  confirmButtonColor: "#DD6B55",
			  confirmButtonText: "Click me to cancel the Refresh",
	   },
	   function(){
		   isRefreshPostponed=true;
	   });
		setTimeout(function() {
			if(!isRefreshPostponed) {
				window.location.reload(true);
			}
		}, 8000);
	}
};

postponUpdateRequest=function(reason){
	if(null!=timeout){
		clearTimeout(timeout);
	}
	setTimeout(function() {
		startIntelligentUpdateMachine();
	}, postponMessageInterval);
};

isValidRefresh=function(){
	var isValid=false;
	if(!($('.enterdefect').is(':visible')) && !($('.urldetailsmain').is(':visible')) && !($('.editDeployment').is(':visible')) && 
			!($('.defectReportTable').is(':visible')) && !($('.defectSearchTable').is(':visible')) && !($('.updateuser').is(':visible'))){
		isValid=true;
	}
	return isValid;
};

function  resetRefresh(){
	postponCount=0;
	broadcastinterval=parseInt($('#broadcastinterval').val());
	startIntelligentUpdateMachine();
}

function doBroadcast(){

	/*************Following threshold check is disabled*********************/
	
	var totalrtt=$.trim($('#totalrtt').val());
	if(null != totalrtt && '' != totalrtt){
		if(parseInt(totalrtt)>rttThreshold){
			playAudioFile('TESTER_MANYRTT.mp3');
		}
	}

	var totalunassigned=$.trim($('#totalunassigned').val());
	if(null != totalunassigned && '' != totalunassigned){
		if(parseInt(totalunassigned)>unassignedThreshold){
			playAudioFile('SUPERVISOR_UNASSIGNED.mp3');
		}
	}

	var totalfixed=$.trim($('#totalfixed').val());
	if(null != totalfixed && '' != totalfixed){
		if(parseInt(totalfixed)>fixedThreshold){
			playAudioFile('SUPERVISOR_DEPLOYMENT.mp3');
		}
	}
	/**********************************/
}

function putIdInStore(id){
	var index = idArray.indexOf(id);
	if (index < 0) {
		idArray.push(id);
	}
}

function removeIdFromStore(id){
	var index = idArray.indexOf(id);
	if (index > -1) {
		idArray.splice(index, 1);
	}
}

function clearStore(){
	idArray=new Array();
}
function bindEvents(){

	$(document).keydown(function(event){
		if(event.ctrlKey){
			cntrlIsPressed = true;
		}  
	});

	$(document).keyup(function(){
		cntrlIsPressed = false;
	});



	$(".reported-by").autocomplete({
		source: users.allusers,
	});
	$(".assigned-to-edit").autocomplete({
		source: users.allusers
	});
	$(".reported-by-edit").autocomplete({
		source: users.allusers,
	});
	$(".reviewer").autocomplete({
		source: users.allusers
	});
	$(".autologin-username").autocomplete({
		source: users.allusers
	});

	var typeAheadObj={
			minLength: 1,
			order: "asc",
			hint: true,
			highlight: true,
			selector: {
				filter: "input-group-btn",
				filterButton: "btn btn-default",
				dropdown: "dropdown-menu dropdown-menu-right",
				list: "dropdown-menu",
				hint: "form-control"
			},
			source: {
				devloper: {
					data: users.allusers
				}
			},
			debug: true
	};
	$('.reported-by').typeahead(typeAheadObj);
	$('.reported-by-edit').typeahead(typeAheadObj);
	$('.assigned-to-edit').typeahead(typeAheadObj);
	$('.reviewer').typeahead(typeAheadObj);
	$('.autologin-username').typeahead(typeAheadObj);
	
	String.prototype.capitalizeFirstLetter = function() {
		return this.charAt(0).toUpperCase() + this.slice(1);
	};
	$('#changeLogFromDatepicker').datetimepicker({
		format: "d M y",
		pickTime: false,
		closeOnDateSelect:true,
		onGenerate:function( ct ){
			$('.xdsoft_timepicker').hide();
		},
	});
	$('#changeLogToDatepicker').datetimepicker({
		format: "d M y",
		pickTime: false,
		closeOnDateSelect:true,
		onGenerate:function( ct ){
			$('.xdsoft_timepicker').hide();
		},
	});
	
	if(OPTION_ACCESS.indexOf('CAN_CHANGE_DED_TED')>-1){
		$('#teddatepicker').datetimepicker({
			onGenerate:function( ct ){
				$('.xdsoft_timepicker').show();
				$(this).find('.xdsoft_date.xdsoft_weekend')
				.addClass('xdsoft_disabled');
			},
			formatTime: 'g:i A',
			format:'d M g:i A',
			minDate: 0,
			closeOnDateSelect:true,

		});
		$('#deddatepicker').datetimepicker({
			onGenerate:function( ct ){
				$('.xdsoft_timepicker').show();
				$(this).find('.xdsoft_date.xdsoft_weekend')
				.addClass('xdsoft_disabled');

			},
			formatTime: 'g:i A',
			format:'d M g:i A',
			minDate: 0,
			closeOnDateSelect:true,
		});
	}else{
		$('#teddatepicker').datetimepicker({
			beforeShowDay: function (date) {
				return [false, ''];
			},
			timepicker:false,
			formatTime: 'g:i A',
			format:'d M g:i A',
			minDate: 0,
			closeOnDateSelect:true,

		});
		$('#deddatepicker').datetimepicker({
			beforeShowDay: function (date) {
				return [false, ''];
			},
			timepicker:false,
			formatTime: 'g:i A',
			format:'d M g:i A',
			minDate: 0,
			closeOnDateSelect:true,
		});
	}

	$('input[type="file"]').ajaxfileupload({
		'action' : 'uploadFile',
		'onComplete' : function(response) {
			$('#upload').hide();
			$(".fileuploadpop").show();
			var statusVal = JSON.stringify(response.status);
			if(statusVal==undefined){
				if(ManageDefect.isEnterDefectOpened()) {
					EnterDefect.setAttachmentName(response);
				}else if(ManageDefect.isUpdateDefectOpened()) {
					UpdateDefect.setAttachmentName(response);
				}
				$(".file-upload-message").html("<font color='green'>Image uploaded successfully</font>");   
				$(".fileuploadpop").trigger('click');
			}else if(statusVal == "false"){
				$(".file-upload-message").html("<font color='red'>"+JSON.stringify(response.message)+"</font>");   
			}else if(statusVal == "true"){
				$(".file-upload-message").html("<font color='green'>"+JSON.stringify(response.message)+"</font>");   
			}   
		},
		'onStart' : function() {
			$('#upload').show();
			$(".fileuploadpop").hide();
		}
	});
	
	$( "#element_to_pop_up7" ).draggable({opacity: 0.1, containment: "document"});

}



function showEnterDefectScreen(){
	if(!isValidAccess('CAN_ENTER')) {
		return false;
	}
	
	var username = $.trim($('#person').val());
	EnterDefect.resetOnScreenOpen(username);
	
	$('#element_to_pop_up3').bPopup({
		speed: 500,
		opacity: 0.5,
		modalClose:false ,
		transition: effectArr[getRandomNumber(effectArr.length)],
		transitionClose: effectArr[getRandomNumber(effectArr.length)],
		modalColor: colorArr[getRandomNumber(colorArr.length)],
	});
	$('.focus-it').focus();
}

function showEditDefectScreen(){
	$('#element_to_pop_up4').bPopup({
		speed: 500,
		opacity: 0.5,
		modalClose:false ,
		transition: effectArr[getRandomNumber(effectArr.length)],
		transitionClose: effectArr[getRandomNumber(effectArr.length)],
		modalColor: colorArr[getRandomNumber(colorArr.length)],
	});
	$('.focus-edit-it').focus();
}

function showSelectedDefectSearchScreen(){
	$('#element_to_pop_up8').bPopup({
		speed: 500,
		opacity: 0.5,
		modalClose:false ,
		transition: effectArr[getRandomNumber(effectArr.length)],
		transitionClose: effectArr[getRandomNumber(effectArr.length)],
		modalColor: colorArr[getRandomNumber(colorArr.length)],
	});
}

function showDefectSearchScreen(){
	$('#element_to_pop_up7').bPopup({
		speed: 500,
		opacity: 0.5,
		modalClose:false ,
		transition: effectArr[getRandomNumber(effectArr.length)],
		transitionClose: effectArr[getRandomNumber(effectArr.length)],
		modalColor: colorArr[getRandomNumber(colorArr.length)],
	});
}

function showDefectReportScreen(){
	$('#element_to_pop_up9').bPopup({
		speed: 500,
		opacity: 0.5,
		modalClose:false ,
		transition: effectArr[getRandomNumber(effectArr.length)],
		transitionClose: effectArr[getRandomNumber(effectArr.length)],
		modalColor: colorArr[getRandomNumber(colorArr.length)],
	});
}


function showUpdateUserScreen(){
	$('#element_to_pop_up10').bPopup({
		speed: 500,
		opacity: 0.5,
		modalClose:false ,
		transition: effectArr[getRandomNumber(effectArr.length)],
		transitionClose: effectArr[getRandomNumber(effectArr.length)],
		modalColor: colorArr[getRandomNumber(colorArr.length)],
	});
	$('.autologin-username').focus();
}
function showUpdateConfigScreen(){
	if(!isValidAccess('ADMINISTRATION')) {
		return false;
	}
	$('#element_to_pop_up11').bPopup({
		speed: 500,
		opacity: 0.5,
		modalClose:false ,
		transition: effectArr[getRandomNumber(effectArr.length)],
		transitionClose: effectArr[getRandomNumber(effectArr.length)],
		modalColor: colorArr[getRandomNumber(colorArr.length)],
	});
	$('.autologin-username').focus();
}

function showDeploymentScreen(){

	$('#element_to_pop_up5').bPopup({
		speed: 500,
		opacity: 0.5,
		modalClose:false ,
		transition: effectArr[getRandomNumber(effectArr.length)],
		transitionClose: effectArr[getRandomNumber(effectArr.length)],
		modalColor: colorArr[getRandomNumber(colorArr.length)],
	});
	$('#servername1').focus();
	var timeout=null;
	timeout=setTimeout(function() {
		addClearableButton($('#element_to_pop_up5'));
		clearTimeout(timeout);
	}, 1000);
	
}

function showDeploymentDetailsScreen(){
	$('#element_to_pop_up1').bPopup({
		speed: 500,
		opacity: 0.5,
		modalClose:false ,
		transition: effectArr[getRandomNumber(effectArr.length)],
		transitionClose: effectArr[getRandomNumber(effectArr.length)],
		modalColor: colorArr[getRandomNumber(colorArr.length)],
	});
}

function showQuickLinksScreen(){

	$('#element_to_pop_up2').bPopup({
		speed: 500,
		opacity: 0.5,
		modalClose:false ,
		transition: effectArr[getRandomNumber(effectArr.length)],
		transitionClose: effectArr[getRandomNumber(effectArr.length)],
		modalColor: colorArr[getRandomNumber(colorArr.length)],
	});


}

function archiveDefects(){
	if(!isValidAccess('ADMINISTRATION')) {
		return false;
	}
	var $function=function(){
		moveDefectsToArchive();
	};
	confirmBox('Do you want to archive CLOSED and REJECTED defects?',$function);
}

function moveDefectsToArchive(){
	var username = $.trim($('#person').val());
	$.ajax({
		type : "GET",
		url : "moveDefectsToArchive",
		cache : false,
		data :{
			userName:username
		},
		success : function(data) {
			var messages=data.split('#');
			if(messages[0]=='ERROR') {
				alertFailureMessage(messages[1],false);
			}else{
				playAudioFile('alert.mp3');
				alertSucessMessage(data,false);
			}
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}

function restartRDT(){
	if(!isValidAccess('ADMINISTRATION')) {
		return false;
	}
	var username = $.trim($('#person').val());
	$.ajax({
		type : "GET",
		url : "restartRDT",
		cache : false,
		data :{
			userName:username
		},
		success : function(data) {
			var messages=data.split('#');
			if(messages[0]=='ERROR') {
				alertFailureMessage(messages[1],false);
			}else{
				playAudioFile('alert.mp3');
				alertSucessMessage(data,false);
			}
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}

function generateReport() {
	var defectStatus=$('.nav-tabs li.active').attr("data-defect-status");
	if(undefined==defectStatus) {
		sweetAlert("Oops...",'This feature is not available for selected tab', "error");
		return false;
	}
	var noOfTds=$('.maintable:visible').find('tbody tr:visible').eq(0).find('td').length;
	if(noOfTds<2) {
		sweetAlert("Oops...",'No defects are present in the current tab', "error");
		return false;
	}
	$('.defectReportTable thead').html('');
	$('.defectReportTable tbody').html('');
	var assignedToDefectReportMap={};
	var reportedByDefectReportMap={};
	$('.maintable:visible').find('tbody tr:visible').each(function() {
		var assignedTo=$.trim($(this).find('td:nth-child(9)').text());
		var reportedBy=$.trim($(this).find('td:nth-child(8)').text());
		var reopenCountIndex=assignedTo.indexOf('RC');
		if(reopenCountIndex>-1){
			assignedTo=assignedTo.substring(0,reopenCountIndex);
		}
		if(assignedTo=='') {
			if(assignedToDefectReportMap['UNASSIGNED']!=undefined) {
				var defectCount=assignedToDefectReportMap['UNASSIGNED'];
				assignedToDefectReportMap['UNASSIGNED']=++defectCount;
			}else {
				assignedToDefectReportMap['UNASSIGNED']=1;
			}
		}else if(assignedToDefectReportMap[assignedTo]!=undefined) {
			var defectCount=assignedToDefectReportMap[assignedTo];
			assignedToDefectReportMap[assignedTo]=++defectCount;
		}else {
			assignedToDefectReportMap[assignedTo]=1;
		}
		if(reportedByDefectReportMap[reportedBy]!=undefined) {
			var defectCount=reportedByDefectReportMap[reportedBy];
			reportedByDefectReportMap[reportedBy]=++defectCount;
		}else {
			reportedByDefectReportMap[reportedBy]=1;
		}
	});
	var toFix='',toTest='';
	if(defectStatus=='OPEN') {
		toFix='No. of defects to be fixed',toTest='No. of defects to be tested';
	}else if(defectStatus=='FIXED' || defectStatus=='RTT') {
		toFix='No. of defects fixed',toTest='No. of defects to be tested';
	}else if(defectStatus=='CLOSED') {
		toFix='No. of defects fixed',toTest='No. of defects tested';
	}else if(defectStatus=='REJECTED') {
		toFix='No. of defects rejected',toTest='No. of rejected defects raised';
	}
	var thead='<tr><th>Name</th><th>'+toFix+'</th><th>'+toTest+'</th>';
	var tbody='';
	$.each(assignedToDefectReportMap, function(key, value){
		tbody+='<tr><td class="defect-report-name">'+key+'</td><td class="defect-report-name">'+value+'</td><td class="defect-report-name">-</td>';
	});
	$.each(reportedByDefectReportMap, function(key, value){
		tbody+='<tr><td class="defect-report-name">'+key+'</td><td class="defect-report-name">-</td><td class="defect-report-name">'+value+'</td>';
	});
	$('.defectReportTable thead').html(thead);
	$('.defectReportTable tbody').html(tbody);
	showDefectReportScreen();
}
function  exportSelectedData(){
	var url="export";
	var requestType=''; 
	if(undefined!=$('.datatable:visible').find('tbody tr:visible') && 
			$('.datatable:visible').find('tbody tr:visible').eq(0).find('td').length<2) {
		sweetAlert("Oops...",'No defects are avaliable to export', "error");
		return false;
	}
	$('.datatable:visible').find('tbody tr:visible').each(function(){
		var defectId=$.trim($(this).find('td').first().text());
		if(requestType=='' && defectId!=''){
			requestType="'"+defectId+"'";
		}else if(defectId!=''){
			requestType+=','+"'"+defectId+"'";
		}
		});
		if(requestType=='' || requestType=="'No matching records found'"){
			sweetAlert("Oops...",'No defects are avaliable to export', "error");
			return false;
		}
		url=url + '?requestType=' + requestType;
		$('#exportTab').attr('href', url);
		sweetAlert("","All visible defects in current tab are exported, Please refine filter/search to export required data", "warning");
}
function  exportAll(){
	var url="export";
	var requestType='ALL';
	url=url + '?requestType=' + requestType;
	$('#exportAll').attr('href', url);
}

function  downloadattached(fileName){
	if(fileName==null || fileName==''){
		sweetAlert("Oops...",'No attachment is avaliable to download', "error");
		return false;
	}
	$('.attachment').attr('href', "");
	var url="downloadattachement";
	url=url + '?fileName=' + fileName;
	$('.attachment').attr('target', '_blank');
	$('.attachment').attr('href', url);
}

function populateContextMenuOption(role){
	var currDel=$.trim($('#currentdel').val());
	var futureDel=$.trim($('#futuredel').val());
	var firstDel=$.trim($('#firstdel').val());
	var secondDel=$.trim($('#seconddel').val());
	var markFixedObj=null;
	var markRttObj=null;
	var markCloseObj=null;
	var moveToCurrentObj=null;
	var moveToFutureObj=null;
	var moveToFirstObj=null;
	var moveToSecondObj=null;
	var deleteObj=null;
	var holdObj=null;
	var unholdObj=null;
	var markArchive=null;
	if(OPTION_ACCESS.indexOf('CAN_FIX')>-1){
		markFixedObj={
				name: "Mark Fixed", icon: "fa-check", disabled: false,
				callback: function(key, options) { 
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'FIXED');
					};
					confirmBox("Do you want to mark "+idsize+" defect/s to FIXED state?",$function);
				}
		};
	}else{
		markFixedObj={
				name: "Mark Fixed", icon: "fa-check", disabled: true
		};
	}

	if(OPTION_ACCESS.indexOf('CAN_RTT')>-1){
		markRttObj={
				name: "Mark RTT", icon: "fa-check", disabled: false,
				callback: function(key, options) {   
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'RTT');
					};
					confirmBox("Do you want to mark "+idsize+" defect/s to RTT state?",$function);
				}
		};
	}else{
		markRttObj={
				name: "Mark RTT", icon: "fa-check", disabled: true
		};
	}

	if(OPTION_ACCESS.indexOf('CAN_CLOSE')>-1){
		markCloseObj={
				name: "Mark Closed", icon: "fa-thumbs-up", disabled: false,
				callback: function(key, options) {  
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'CLOSED');
					};
					confirmBox("Do you want to mark "+idsize+" defect/s to CLOSED state?",$function);			
				}
		};
	}else{
		markCloseObj={
				name: "Mark Closed", icon: "fa-thumbs-up", disabled: true
		};
	}

	if(OPTION_ACCESS.indexOf('CAN_DELETE')>-1){
		deleteObj={
				name: "Delete Defect", icon: "delete", disabled: false,
				callback: function(key, options) {  
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'DELETE');
					};
					confirmBox("Do you want to delete "+idsize+" defect/s completely from the system?",$function);
				}
		};
	}else{
		deleteObj={
				name: "Delete Defect", icon: "delete", disabled: true
		};
	}
	
	if(OPTION_ACCESS.indexOf('CAN_HOLD_UNHOLD')>-1){
		holdObj={
				name: "Hold Defect", icon: "fa-hand-o-down", disabled: false,
				callback: function(key, options) {  
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'HOLD');
					};
					confirmBox("Do you want to keep "+idsize+" defect/s on hold?",$function);
				}
		};
	}else{
		holdObj={
				name: "Hold Defect", icon: "fa-hand-o-down", disabled: true
		};
	}
	if(OPTION_ACCESS.indexOf('CAN_HOLD_UNHOLD')>-1){
		unholdObj={
				name: "Unhold Defect", icon: "fa-hand-o-up", disabled: false,
				callback: function(key, options) {  
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'UNHOLD');
					};
					confirmBox("Do you want to unhold "+idsize+" defect/s?",$function);
				}
		};
	}else{
		unholdObj={
				name: "Unhold Defect", icon: "fa-hand-o-up", disabled: true
		};
	}

	if(OPTION_ACCESS.indexOf('CAN_MOVE_TO_DELIVERY')>-1){
		moveToCurrentObj={
				name: "Move To "+currDel, icon: "paste", disabled: false,
				callback: function(key, options) { 
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'MOVETODELIVERY');
					};
					confirmBox("Do you want to move "+idsize+" defect/s for "+currDel+" tab?",$function);
				}
		};

		moveToFutureObj={
				name: "Move To "+futureDel, icon: "paste", disabled: false,
				callback: function(key, options) { 
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'MOVETOFUTUREDELIVERY');
					};
					confirmBox("Do you want to move "+idsize+" defect/s in "+futureDel+" tab?",$function);
				}
		};
		moveToFirstObj={
				name: "Move To "+firstDel, icon: "paste", disabled: false,
				callback: function(key, options) { 
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'MOVETOFIRSTDELIVERY');
					};
					confirmBox("Do you want to move "+idsize+" defect/s in "+firstDel+" tab?",$function);
				}
		};

		moveToSecondObj={
				name: "Move To "+secondDel, icon: "paste", disabled: false,
				callback: function(key, options) { 
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'MOVETOSECONDDELIVERY');
					};
					confirmBox("Do you want to move "+idsize+" defect/s in "+secondDel+" tab?",$function);
				}
		};

	}else{
		moveToCurrentObj={
				name: "Move To "+currDel, icon: "paste", disabled: true,
		};
		moveToFutureObj={
				name: "Move To "+futureDel, icon: "paste", disabled: true,
		};
		moveToFirstObj={
				name: "Move To "+firstDel, icon: "paste", disabled: true,
		};

		moveToSecondObj={
				name: "Move To "+secondDel, icon: "paste", disabled: true,
		};
	}

	if(OPTION_ACCESS.indexOf('CAN_REMOVE_FROM_DELIVERY')>-1){
		moveToOpen={
				name: "Move To OPEN", icon: "paste", disabled: false,
				callback: function(key, options) { 
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'MOVETOOPEN');
					};
					confirmBox("Do you want to move "+idsize+" defect/s in OPEN tab?",$function);
				}
		};
	}else{
		moveToOpen={
				name: "Move To OPEN", icon: "paste", disabled: true,
		};
	}
	if(OPTION_ACCESS.indexOf('ADMINISTRATION')>-1){
		markArchive={
				name: "Archive", icon: "fa-archive", disabled: false,
				callback: function(key, options) { 
					var selectedId=$('#selectedId').val();
					var idsize=idArray.length;
					var $function=function(){
						contextMenuAction(selectedId,'ARCHIVE');
					};
					confirmBox("Do you want to archive "+idsize+" defect/s?",$function);
				}
		};
	}else{
		markArchive={
				name: "Archive", icon: "fa-archive", disabled: true
		};
	}
	contextMenuItems={
			"markfixed": markFixedObj,
			"markrtt": markRttObj,
			"markclosed": markCloseObj,

			"edit": { name: "Edit Info.", icon: "fa-pencil-square-o", disabled: false,
				callback: function(key, options) {   
					var selectedId=$('#selectedId').val();
					editDefect(selectedId);
				}
			},
			"currentdelivery": moveToCurrentObj,
			"futuredelivery": moveToFutureObj,
			"firstdelivery": moveToFirstObj,
			"seconddelivery": moveToSecondObj,
			"movetoopen": moveToOpen,
			"hold": holdObj,
			"unhold": unholdObj,
			"archive": markArchive,
			"delete": deleteObj

	};

	$.contextMenu({
		selector: '.context-menu-one', 
		callback: function(key, options) {
			sweetAlert("It's Not Us, It's You...",'Boss, You are looking for something you should not see! Better luck next time :)', "error");
		},
		items: contextMenuItems
	});
}


function contextMenuAction(defectId,action) {

	var selectedTab=DataTable.getStoredTabName();
	if(undefined!=selectedTab && null!=selectedTab && ''!=selectedTab){
		if (selectedTab=='CLOSED' && action=='CLOSED'){
			sweetAlert("",'Defect is already in CLOSED state', "error");
			return false;
		}else if(selectedTab=='RTT' && action=='RTT'){
			sweetAlert("",'Defect is already in RTT state', "error");
			return false;
		}else if(selectedTab=='FIXED' && action=='FIXED'){
			sweetAlert("",'Defect is already in FIXED state', "error");
			return false;
		}
	}
	var user=$.trim($('#person').val());
	var idsize=idArray.length;
	if(idsize<1){
		sweetAlert("Oops...",'No defects are selected to perfrom the action', "error");
		return false;
	}
	var jsonString=idArray+'!,,!'+action+'!,,!'+user;

	$.ajax({
		type : "GET",
		url : "contextMenuAction.html",
		cache : false,
		data :{
			jsonString:jsonString
		},
		success : function(data) {
			var messages=data.split('#');
			if(messages[0]=='ERROR') {
				alertFailureMessage(messages[1],false);
			}else{
				if(data=='obsolete') {
					alertFailureMessage('The content of selected record has been modified by another user. Click OK to reload the page.', true);
				}else {
					playAudioFile('alert.mp3');
					clearStore();
					alertSucessMessage('Selected action is performed successfully. No. of Defects updated: '+idsize,false);
				}
			}
			
			
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}

function getValue(value) {
	if(value==null || value==undefined){
		return '';
	}else {
		return value;
	}
}

addClearableButton=function($parent) {
	$parent.find('input.clearable,textarea.clearable').each(function() {
		 $(this)[tog($(this).val())]('x');
	});
};

function isValidAccess(accessName) {
	var isValidAccess = false;
	if(OPTION_ACCESS.indexOf(accessName)>-1) {
		isValidAccess = true;
	}else {
		alertFailureMessage('You do not have access for this functionality. Please contact to our administrator.',false);
	}
	return isValidAccess;
}

runClock=function(){
	displayWatch();
	setInterval(function() {
		displayWatch();
	}, 1000);
};
var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"];
function displayWatch() {
	var date = new Date();
	var time = date.toLocaleString('en-US', {hour:'numeric',minute:'numeric',second:'numeric',hour12: true});
	$('.currenttime').text('Current Time: '+time);
}

runClock();

function openNewPage(url) {
	var jForm = $('<form></form>');
	jForm.attr('action', url);
	jForm.attr('target', '_blank');
	jForm.attr('method', 'post');
	$('#postrequest').html('');
	jForm.appendTo('#postrequest').submit();
}
