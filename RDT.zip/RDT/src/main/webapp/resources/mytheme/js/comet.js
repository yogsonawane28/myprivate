var pollinterval=10000;
if($('#pollInterval').val()!='') {
	pollinterval=parseInt($('#pollInterval').val());
}

var alertArr=['success','info','error','dark'];
$(function() {
	if($('#isbroadcastenabled').val()=='true'){
		setInterval(function(){ poll(); }, pollinterval);
	} else{
		console.log('Polling engine is off!');
	}
});
	
function poll() {
		$.ajax({
				type : "GET",
				url : "poll",
				cache : false,
				success : function(event) {
					DataUpdate.processEvent(event);
				},
				complete : function() {
					
				},
				error : function(error) {
					console.error('Error occured in Polling engine function!!');
				}
		});
}

var DataUpdate={
			deploymentUpdate:'DEPLOYMENT_UPDATE',announcementAdd:'ANNOUNCEMENT_ADD',defectAdd:'DEFECT_ENTER',defectUpdate:'DEFECT_UPDATE',calendar:'CALENDAR',refresh:'REFRESH',
			processEvent:function(event) {
				if(null!=event && undefined!=event && ''!=event){
					DataUpdate.pushMessageToChangeLog(event);
					DataUpdate.showNotificationMessage(event);
					DataUpdate.updateData(event);
				}
			},
			pushMessageToChangeLog:function(event) {
				event.classNames='unread-log';
				ChangeLog.pushToChangeLog(event);
			},
			showNotificationMessage:function(event) {
				showMessage(event.eventType,event.activity);
			},
			updateData:function(event) {
				if(DataUpdate.deploymentUpdate==event.dataUpdateType) {
					DataUpdate.updateDeploymentDetails(event.deploymentDetails);
				}else if(DataUpdate.announcementAdd==event.dataUpdateType) {
					DataUpdate.addToAnnouncements(event.messages);
				}else if(DataUpdate.defectAdd==event.dataUpdateType) {
					DataUpdate.addToDefects(event.defectDetails);
				}else if(DataUpdate.defectUpdate==event.dataUpdateType) {
					DataUpdate.updateDefectsDetails(event.defectDetails,event.oldDefectStatus);
				}else if(DataUpdate.refresh==event.dataUpdateType) {
					DataUpdate.sendRefreshCommand();
				}
			},
			updateDeploymentDetails:function(deploymentDetails) {
				DeploymentDetails.updateDeploymentDetailsOnBroadcast(deploymentDetails);
			},
			addToAnnouncements:function(message) {
				Announcements.addAnnouncementOnBroadcast(message);
			},
			addToDefects:function(defect) {
				DisplayDefects.updateDefectsOnNewEnterDefectBroadcast(defect);
			},
			updateDefectsDetails:function(defect,oldStatus) {
				DisplayDefects.updateDefectsOnNewUpdateDefectBroadcast(defect,oldStatus);
			},
			sendRefreshCommand:function() {
				alertSucessMessage('The system configurations are updated by Administrator. Click OK to reload the page.', true);
			}
};

function showMessage(title,message){
	new PNotify({
        title: title,
        text: message,
        type: alertArr[getRandomNumber(alertArr.length)],
    });
	playAudioFile('alert.mp3');
}

function showMessageOnLogin(){ 
	var name=$.trim($('#person').val());
	new PNotify({
		title: "Welcome back "+name,
		type: "dark",
		text: "You are successfully connected to the system :)",
	});
}

function getRandomNumber(limit){
	 return Math.floor(Math.random() * limit);
}