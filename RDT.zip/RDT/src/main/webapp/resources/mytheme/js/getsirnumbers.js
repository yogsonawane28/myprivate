function getSIRNumbers() {
	var SIRArr=[];
	var IssueArr=[];
	$('.dataTables_scrollBody table:visible').find('tr').each(function(index) {
		var SIRText = $(this).find('td.sirDescBackgrount').text().split("SIRD_");
		if(SIRText.length>1 && SIRText[0]!='' && SIRText[1]!='' && SIRText[1]!=undefined) {
			var SIRNumber=SIRText[1].slice(0,6);
			SIRArr.push(SIRNumber);
		}else {
			var IssueText = $(this).find('td.sirDescBackgrount').text().split("SIRI_");
			if(IssueText.length>1 && IssueText[0]!='' && IssueText[1]!='' && IssueText[1]!=undefined) {
				var SIRNumber=IssueText[1].slice(0,6);
				IssueArr.push(SIRNumber);
			}
		}
	});
	console.info('Total Number of SIRs: '+SIRArr.length);
	console.info('SIR numbers : '+SIRArr.join(','));
	console.info('Total Number of Issues: '+IssueArr.length);
	console.info('Issue Numbers : '+IssueArr.join(','));
	return "Please copy the SIR numbers & Issue numbers and paste the same in SIR container."
}