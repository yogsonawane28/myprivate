/***
 * Module: Display Defects
 * Developer: YS
 * Technology: Angular JS
 */
var defectViewControllerEle = document.querySelector('[data-ng-controller=defectViewController]');
rdtApp.controller("defectViewController", function($scope,$http) {  
	$scope.table={};
	$scope.table.selectedTabName=DataTable.getStoredTabName();
	DisplayDefects.showDefects($scope);
	$scope.downloadAttachment = function() {
		  downloadattached(this.defect.screenLocation);
	  };
    $scope.downloadTestLogs = function() {
		  downloadattached(this.defect.rcaLocation);
	}; 
	$scope.getRowClassName = function() {
		  var className='';
		  if(this.defect.isOnHold=='YES'){
			  className='onhold';
			  this.defect.status='ON HOLD';
		  }else  if(this.defect.priority=='BLOCKER') {
			  className='blockerdefect';
		  }
		  this.defect.group = 'OPEN';
		  this.defect.groupClassName = 'deliveryname-color-no-color';
		  if(this.defect.isDeliverableNow!=null) {
			  this.defect.group = $.trim($('#currentdel').val());
			  this.defect.groupClassName = 'deliveryname-color1';
		  }else if(this.defect.isDeliverableInFuture!=null) {
			  this.defect.group = $.trim($('#futuredel').val());
			  this.defect.groupClassName = 'deliveryname-color2';
		  }else if(this.defect.isDeliverableForFirst!=null) {
			  this.defect.group = $.trim($('#firstdel').val());
			  this.defect.groupClassName = 'deliveryname-color3';
		  }else if(this.defect.isDeliverableForSecond!=null){
			  this.defect.group = $.trim($('#seconddel').val());
			  this.defect.groupClassName = 'deliveryname-color4';
		  }
		  return className;
	};
	$scope.showLinkedDefectDetails = function(){ 
  	  showSearchDefect(this.defect.linkedDefectId);
    };
    $scope.showDefectDetails = function(){ 
    	  showSearchDefect(this.defect.defectId);
      };
	$scope.rowClick = function(event) {
		if(undefined==this.defect.defectId) {
			return;
		}
		$thisRow=$(event.currentTarget);
		if ($thisRow.hasClass('selected')) {
			$thisRow.removeClass('selected');
			var id= this.defect.defectId+'--'+this.defect.versionNumber;
			$('#selectedId').val('');
			removeIdFromStore(id);
		}
		else {
			if(!cntrlIsPressed){
				$('tr.selected').removeClass('selected');
				clearStore();
			}
			$thisRow.addClass('selected');
			var id= this.defect.defectId+'--'+this.defect.versionNumber;
			if(id==null || id==undefined || id=='') {
				sweetAlert("",'Something went wrong, Plase connect to Administrator.', "error");
				return false;
			}
			$('#selectedId').val(id);
			putIdInStore(id);
		}
	};
	$scope.rowDoubleClick = function(event) {
		if(undefined==this.defect.defectId || (this.defect.isOnHold=='YES' && OPTION_ACCESS.indexOf('CAN_HOLD_UNHOLD')<0)) {
			return;
		}
		$thisRow=$(event.currentTarget);
		$thisRow.addClass('selected');
		var id= this.defect.defectId+'--'+this.defect.versionNumber;
		if(id==null || id==undefined || id=='') {
			sweetAlert("",'Something went wrong, Plase connect to Administrator.', "error");
			return false;
		}
		$('#selectedId').val(id);
		putIdInStore(id);
		editDefect(id);
	};
	$scope.exportVisibleDefects = function() {
		exportSelectedData();
	};
	$scope.exportAllActiveDefects = function() {
		exportAll();
	};
	$scope.viewReport = function() {
		generateReport();
	};
}); 

var DisplayDefects={
		cachedDefectRecords : {},
		getDefectViewControllerScopeEle:function(){
			if(null==defectViewControllerEle || undefined==defectViewControllerEle) {
				defectViewControllerEle = document.querySelector('[data-ng-controller=defectViewController]');
			}
			return angular.element(defectViewControllerEle).scope();
		},
		isDefectCacheEmpty: function(selectedTabName) {
			return (DisplayDefects.cachedDefectRecords[selectedTabName]==undefined);
		},
		clearDefectCache: function(selectedTabName) {
			if(undefined!=selectedTabName) {
				DisplayDefects.cachedDefectRecords[selectedTabName]=undefined;
			}else {
				DisplayDefects.cachedDefectRecords = {};
			}
		},
		showDefects:function($scope) {
			if(DisplayDefects.isDefectCacheEmpty($scope.table.selectedTabName)) {
				console.info('Records are fetched from the database');
				DisplayDefects.cachedDefectRecords[$scope.table.selectedTabName]=getDefectDetails($scope.table.selectedTabName);
			}else {
				console.info('Records are fetched from the cache');
			}
			$scope.table.defects= DisplayDefects.cachedDefectRecords[$scope.table.selectedTabName];
		},
		addBlankRows:function($scope) {
			if($scope.table.defects.length<10) {
				var blankRecords=DisplayDefects.getBlankDefectRecord(10-$scope.table.defects.length);
				Array.prototype.push.apply($scope.table.defects,blankRecords);
			}
		},
		getBlankDefectRecord:function(number) {
			var defects=[];
			for(var index=0;index<number;index++) {
				defects.push({'reopenCount':0,'linkedDefectCount':null});
			}
			return defects; 
		},
		reloadDefects:function($scope) {
			DisplayDefects.showDefects($scope);
			var data={};
			data[$scope.table.selectedTabName]=$scope.table.defects.length;
			DisplayDefects.updateCount($scope,data);
			$scope.$apply();
			
		},
		setHighlightedRows:function(defects,selectedIds) {
			if(undefined==selectedIds) {
				return;
			}
			var result = defects.filter(function(defect) {
				  return selectedIds.indexOf(defect.defectId)>-1;
			});
			for(var index=0;index<result.length;index++) {
				result[index].selectedRowClass='selected';
			}
			
		},
		getCurrentSetup:function() {
			return {
						'scrollTop':$('.dataTables_scrollBody').scrollTop(),
						'scrollLeft':$('.dataTables_scrollBody').scrollLeft(),
						'currentPage':$('.paging_simple_numbers').find('.current').attr('data-dt-idx')
				   };
		},
		setCurrentSetup:function(setup) {
			var $page=$('.paging_simple_numbers').find('a[data-dt-idx="'+setup.currentPage+'"]');
			if($page.length>0) {
				$page.trigger('click');
			}
			$('.dataTables_scrollBody').scrollTop(setup.scrollTop);
			$('.dataTables_scrollBody').scrollLeft(setup.scrollLeft);
		},
		updateDefectDetails:function($prevScope,selectedIds,isPreservePageNumber) {
			var $scope=$prevScope;
			if(undefined==$scope) {
				$scope=DisplayDefects.getDefectViewControllerScopeEle();
			}
			var setup=null;
			if(isPreservePageNumber) {
				setup=DisplayDefects.getCurrentSetup();
			}
			$('.scrolldiv').addClass('body-loader');
			DataTable.clearDataTable();
			DataTable.drawDataTable();
			DataTable.destroyDataTable();
			$scope.table.selectedTabName=DataTable.getStoredTabName();
			DisplayDefects.reloadDefects($scope);
			$('.scrolldiv').removeClass('body-loader');
			DataTable.initDataTable();
			if(isPreservePageNumber) {
				DisplayDefects.setCurrentSetup(setup);
				DisplayDefects.setHighlightedRows($scope.table.defects,selectedIds);
			}
		},
		getSelectedRecords:function() {
			var selectedIds=[];
			$('.scrolldiv').find('tr.selected input.id-version-number').each(function() {
				var id=parseInt($(this).val().split('--')[0]);
				selectedIds.push(id);
			});
			return selectedIds;
		},
		updateDefectsOnNewEnterDefectBroadcast:function(defect) {
			playAudioFile('DEV_OPEN.mp3');
			var $scope=DisplayDefects.getDefectViewControllerScopeEle();
			var selectedTab=DataTable.getStoredTabName();
			DisplayDefects.clearDefectCache('UNASSIGNED');
			if(selectedTab=='UNASSIGNED') {		
				DisplayDefects.updateDefectDetails($scope,DisplayDefects.getSelectedRecords(),true);
			}else {
				$scope.table.unassignedCount=+$scope.table.unassignedCount + 1;
				$scope.$apply();
			}
		},
		getMaxVersionNumber:function($scope) {
			return Math.max.apply(Math,$scope.table.defects.map(function(o){return o.versionNumber;}));
		},
		updateDefectsOnNewUpdateDefectBroadcast:function(defect,oldStatus) {
			if(oldStatus!='CLOSED' && defect.status=='CLOSED') {
				playAudioFile('CLOSED.mp3');
			}else if(oldStatus!='RTT' && defect.status=='RTT') {
				playAudioFile('TESTER_RTT.mp3');
			}
			DisplayDefects.clearDefectCache();
			var $scope=DisplayDefects.getDefectViewControllerScopeEle();
			DisplayDefects.updateDefectDetails($scope,DisplayDefects.getSelectedRecords(),true);
			getAllDefectCounts($scope);
		},
		getDefectsCounts:function() {
			var $scope=DisplayDefects.getDefectViewControllerScopeEle();
			getAllDefectCounts($scope);
		},
		updateCount:function($scope,data) {
			if(data['DELIVERY_NOW']) {
				$scope.table.deliveryNowCount=data['DELIVERY_NOW'];
			}
			if(data['DELIVERY_NEXT']) {
				$scope.table.deliveryNextCount=data['DELIVERY_NEXT'];
			}
			if(data['DELIVERY_FIRST']) {
				$scope.table.deliveryFirstCount=data['DELIVERY_FIRST'];
			}
			if(data['DELIVERY_SECOND']) {
				$scope.table.deliverySecondCount=data['DELIVERY_SECOND'];
			}
			if(data['OPEN']) {
				$scope.table.openCount=data['OPEN'];
			}
			if(data['REOPENED']) {
				$scope.table.reopenedCount=data['REOPENED'];
			}
			if(data['FIXED']) {
				$scope.table.fixedCount=data['FIXED'];
			}
			if(data['RTT']) {
				$scope.table.rttCount=data['RTT'];
			}
			if(data['CLOSED']) {
				$scope.table.closedCount=data['CLOSED'];
			}
			if(data['REJECTED']) {
				$scope.table.rejectedCount=data['REJECTED'];
			}
			if(data['DEFERRED']) {
				$scope.table.deferredCount=data['DEFERRED'];
			}
			if(data['UNASSIGNED']) {
				$scope.table.unassignedCount=data['UNASSIGNED'];
			}
		}
};

function getDefectDetails(viewName) {
	var defects=null;
	$.ajax({
		type : "GET",
		url : "getDefectDetails",
		cache : false,
		async : false,
		data : {
			viewName : viewName
		},
		success : function(data) {
			defects=data;
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
	return defects;
}

function getAllDefectCounts($scope) {
	$.ajax({
		type : "GET",
		url : "getAllDefectCounts",
		cache : false,
		async : false,
		success : function(data) {
			DisplayDefects.updateCount($scope,data);
			$scope.$apply();
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}