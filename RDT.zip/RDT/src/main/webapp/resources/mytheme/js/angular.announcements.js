/***
 * Module: Announcements
 * Developer: YS
 * Technology: Angular JS
 */
var announcementsAppElement = document.querySelector('[data-ng-controller=AnnouncementsController]');

rdtApp.controller("AnnouncementsController", ['$scope','AnnouncementsService',function($scope,AnnouncementsService) {  
	  $scope.announcements={};
	  
	  $scope.announcements.title=AnnouncementsService.getTitle();
	  $scope.announcements.loggedInUser=AnnouncementsService.getLoggedInUserName();
	  
	  AnnouncementsService.refresh($scope);
      
      $scope.send = function() {    
    	  AnnouncementsService.send($scope);
      }; 
      
      $scope.refresh = function() {    
    	  AnnouncementsService.refresh($scope);
      };
}]); 

rdtApp.service("AnnouncementsService", ['AnnouncementsFactory', function(AnnouncementsFactory){
	
	this.getTitle= function() {
		return 'Announcements';
	};
	
	this.getLoggedInUserName= function(){
		return $.trim($('#person').val());
	};
	
	this.send = function($scope) {
		AnnouncementsFactory.send($scope);
	};
	
	this.refresh = function($scope) {
		AnnouncementsFactory.refresh($scope);
	};
	
}]);

rdtApp.factory("AnnouncementsFactory", function(){
	var factory={};
	 
	factory.send = function($scope) {
		if($scope.announcements.message) {
	  		  Announcements.send($scope);
	  		  $scope.announcements.message='';
	  		  factory.refresh($scope);
	  	}
	};
	factory.refresh = function($scope) {
		  $scope.announcements.messages=Announcements.getAnnouncements();
		  factory.updateLastMessageId($scope);
	};
	factory.updateLastMessageId = function($scope) {
		  if(!jQuery.isEmptyObject($scope.announcements.messages)) {
      	  var length=$scope.announcements.messages.length;
            $scope.announcements.lastestMessageId=$scope.announcements.messages[length-1].id;
        }else {
      	    $scope.announcements.lastestMessageId=0;
        }
	};
	return factory;
});

var Announcements={
		getAnnouncementsAppElementScopeEle:function() { 
			if(null==announcementsAppElement || undefined==announcementsAppElement) {
				announcementsAppElement = document.querySelector('[data-ng-controller=AnnouncementsController]');
			}
			return angular.element(announcementsAppElement).scope();
		},
		getAnnouncements:function() {
			return getAnnouncements();
		},
		send:function($scope) {
			sendAnnouncement($scope);
		},
		addAnnouncementOnBroadcast:function(message) {
			var $scope=Announcements.getAnnouncementsAppElementScopeEle();
			Announcements.pushToAnnouncements($scope,message);
		},
		pushToAnnouncements:function($scope,message) {
			if($scope.announcements.lastestMessageId==0 || $scope.announcements.lastestMessageId<message.id) {
				$scope.announcements.lastestMessageId=message.id;
				$scope.announcements.messages.push(message);
				$scope.$apply();
				scrollChatToEnd();
			}
		},
};

function getAnnouncements() {
	var historyMessages=null;
	$.ajax({
		type : "GET",
		url : "getMessages",
		cache : false,
		async: false,
		success : function(messages) {
			historyMessages=messages;
			scrollChatToEnd();
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
	return historyMessages;
}

function sendAnnouncement($scope){
	if(!$scope.announcements.message){
		return false;
	}
	var jsonObj={
		"loggedInUser":$scope.announcements.loggedInUser,
		"message":$scope.announcements.message
	};

	var json=JSON.stringify(jsonObj);
	$.ajax({
		type : "GET",
		url : "submitChat",
		cache : false,
		async: false,
		data :{
			json:json
		},
		success : function(data) {
			playAudioFile('alert.mp3');
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...","Chat system is down", "error");
		}
	});
}

function scrollChatToEnd(){
	var timeout=null;
	timeout=setTimeout(function() {
		var scroll = $('.scrollchat');
		var height = scroll[0].scrollHeight;
		scroll.scrollTop(height);
		clearTimeout(timeout);
	}, 500);

}
