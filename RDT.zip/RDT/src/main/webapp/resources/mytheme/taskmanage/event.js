 $(document).ready(function() {
	$('.pagebody').removeClass('body-loader');
	var storedEvents=getEventDetails();
	var events = populateEventDetails(storedEvents);
    initThemeChooser({
      init: function(themeSystem) {
        $('#calendar').fullCalendar({
          firstDay:1,
          themeSystem: themeSystem,
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,basicWeek,basicDay,listMonth'
          },
          businessHours: {
        	    start: '08:00',
        	    end: '20:00',
        	},
          weekNumbers: true,
          navLinks: true, // can click day/week names to navigate views
          editable: false,
          eventLimit: true, // allow "more" link when too many events
          events:events,
          eventColor: '#378006',
          eventRender: function(event, element) {
        	  element.find(".fc-title").attr('id',event.id);
          }
        });
      },
     
      change: function(themeSystem) {
        $('#calendar').fullCalendar('option', 'themeSystem', themeSystem);
      }
    });
 
    $('#eventStartDate').datetimepicker({
    	format: "Y-m-d",
		closeOnDateSelect:true,
		onGenerate:function( ct ){
			$('.xdsoft_timepicker').hide();
		},
    });
    $('#eventEndDate').datetimepicker({
    	format: "Y-m-d",
		closeOnDateSelect:true,
		onGenerate:function( ct ){
			$('.xdsoft_timepicker').hide();
		},
    });
    $('#eventEndDate').datetimepicker({
    	format: "Y-m-d",
		closeOnDateSelect:true,
		onGenerate:function( ct ){
			$('.xdsoft_timepicker').hide();
		},
    });
    $(document).on('click', '.fc-title', function(e){
    	var id=$.trim($(this).attr('id'));
    	if(id) {
    		showAddEventScreen(id);
    	}
	});
    $('#event').on('change', function(e){
    	var event=$(this).val();
    	$('.event-end-date').show();
    	$('.event-name').show();
    	if(event=='') {
    		$('.enable-disable').attr('disabled',true);
    	}else {
    		$('.enable-disable').attr('disabled',false);
    	}
    	if(event=='Leave') {
    		$('.event-name-label').text("Who's on leave?");
    		$('.event-start-date-label').text("Leave start date");
    		$('.event-end-date-label').text("Joining back on");
    	}else if(event=='Trading Holiday' || event=='On-site Holiday' || event=='Off-shore Holiday'){
    		$('.event-name').hide();
    		$('.event-start-date-label').text("Holiday date");
    		$('.event-end-date').hide();
    		$('#eventEndDate').val('');
    	}else if(event=='Birthday'){
    		$('.event-name-label').text("Who's birthday?");
    		$('.event-start-date-label').text("Birth date");
    		$('.event-end-date').hide();
    		$('#eventEndDate').val('');
    	}else if(event=='Delivery') {
    		$('.event-name-label').text("Delivery version");
    		$('.event-start-date-label').text("Delivery date");
    		$('.event-end-date').hide();
    		$('#eventEndDate').val('');
    	}else {
    		$('.event-name-label').text("Event name");
    		$('.event-start-date-label').text("Event start date");
    		$('.event-end-date-label').text("Event end date");
    	}
	});

 });
 
 function filterEvent() {
	 var result = events.filter(function(a) {return a.className==16;});
 }
 
 var effectArr=['fadeIn'];
 var colorArr=['black'];
 
function showAddEventScreen(id){
	$('#element_to_pop_up1').bPopup({
		speed: 100,
		opacity: 0.5,
		modalClose:false ,
		transition: effectArr[getRandomNumber(effectArr.length)],
		transitionClose: effectArr[getRandomNumber(effectArr.length)],
		modalColor: colorArr[getRandomNumber(colorArr.length)],
	});
	resetEventWindow();
	if(undefined!=id) {
		populateEventDetailsOnScreen(id);
	}else {
		$('.enable-disable').attr('disabled',true);
	}
	$('#event').focus();
	$('#event').trigger('change');
}

function populateEventDetailsOnScreen(id){
	var events=getEventDetails(id);
	var event=events[0];
	$('.panel-title-text').text('Update an Event: '+event.eventId);
	$('.edit-event-input').show();
	$('.submit-event-input').hide();
	$('#eventId').val(event.eventId);
	$('#event').val(event.event);
	$('#event').attr('disabled',true);
	$('#eventName').val(event.eventName);
	$('#eventStartDate').val(event.eventStartDate);
	$('#eventEndDate').val(event.eventEndDate);
	$('#eventComment').val(event.eventComment);
	$('#eventCreator').val(event.eventCreator);
	$('#eventCreationDateTime').val(event.creationDateTime);
	$('#eventLastUpdatedBy').val(event.lastUpdatedBy);
	if(event.eventType=="Public") {
		$('#publicEventType').prop("checked",true);
	}else {
		$('#privateEventType').prop("checked",true);
	}
	 $('#event').trigger('change');
}
function resetEventWindow() {
	
	$('.panel-title-text').text('Add an Event');
	$('.edit-event-input').hide();
	$('.submit-event-input').show();
	$('#eventId').val('');
	$('#event').attr('disabled',false);
	$('#eventName').val('');
	$('#eventStartDate').val('');
	$('#eventEndDate').val('');
	$('#eventComment').val('');
	$('#eventCreator').val('');
	$('#eventCreationDateTime').val('');
	$('#eventLastUpdatedBy').val('');
	$('#publicEventType').prop("checked",true);
}

function populateEventDetails(storedEvents){
	var events=[];
	if(null!=storedEvents){
		for(var index=0;index<storedEvents.length;index++){
			var record = storedEvents[index]; 
			var color='blue';
			if(record.event=='Trading Holiday' || record.event=='On-site Holiday' || record.event=='Off-shore Holiday') {
				color='red';
			}else if(record.event=='Birthday') {
				color='#e60099';
			}else if(record.event=='Delivery') {
				color='green';
			}else if(record.event=='Leave') {
				color='#c441f4';
			}
			var title=record.event;
			if(title=='Delivery'){
				title='D';
			}
			if(record.eventName) {
				 title+=':'+record.eventName;
			}
			var event= {
					title: title,
		            start: record.eventStartDate,
		            end: record.eventEndDate,
		            allDay:true,
		            className:record.eventId,
		            id:record.eventId,
		            color:color
			}
			events.push(event);
		}
	}
	return events;
}
function setEventsToCalendar(events){
	 $('#calendar').fullCalendar('option', 'events', events);
}

function eventAction(action) {
	if(action=='ADD' || action=='UPDATE') {
		updateEvent(action);
	}else if(action=='DELETE') {
		var $function=function(){
			updateEvent(action);
		};
		confirmBox('Do you want to delete selected event?',$function);
	}
}

function updateEvent(action) {
	var eventType="Public";
	if($('#privateEventType').prop("checked")) {
		eventType="Private";
	}
	var event = {
			'eventId':$.trim($('#eventId').val()),
			'event':$.trim($('#event').val()),
			'eventName':$.trim($('#eventName').val()),
			'eventStartDate':$.trim($('#eventStartDate').val()),
			'eventEndDate':$.trim($('#eventEndDate').val()),
			'eventType':eventType,
			'eventComment':$.trim($('#eventComment').val()),
			'eventCreator':$.trim($('#person').val()),
			'action':action
	}
	if(!event.event) {
		sweetAlert("Oops...",'Please select an event', "error");
		return false;
	}else if((!event.eventName && event.event.indexOf('Holiday')<0) || !event.eventStartDate) {
		sweetAlert("Oops...",'Please enter mandetory inputs', "error");
		return false;
	}
	var jsonString=JSON.stringify(event);
	$.ajax({
		type : "GET",
		url : "submitEvent.html",
		cache : false,
		data :{
			jsonString:jsonString
		},
		success : function(data) {
			var messages=data.split('#');
			if(messages[0]=='ERROR') {
				alertFailureMessage(messages[1],false);
			}else{
				playAudioFile('alert.mp3');
				alertSucessMessage(data,true);
				closeScreenOnSubmit('element_to_pop_up1');
			}
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
}

function getEventDetails(eventId) {
	var user=$.trim($('#person').val());
	if(eventId==undefined) {
		eventId=null;
	}
	$.ajax({
		type : "GET",
		url : "getAllEventDetails",
		cache : false,
		async : false,
		data : {
			eventId : eventId,
			user : user
		},
		success : function(data) {
			events=data;
		},
		complete : function() {
		},
		error : function(error) {
			sweetAlert("It's Not You, It's Us...",errorMessage, "error");
		}
	});
	return events;
}