--
-- PostgreSQL database dump
--

-- Dumped from database version 9.3.13
-- Dumped by pg_dump version 9.3.1
-- Started on 2017-04-03 16:27:41

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 7 (class 2615 OID 6022100)
-- Name: data; Type: SCHEMA; Schema: -; Owner: erp_dbo
--

CREATE SCHEMA data;


ALTER SCHEMA data OWNER TO erp_dbo;

SET search_path = data, pg_catalog;

--
-- TOC entry 198 (class 1255 OID 10863624)
-- Name: fn_update_version_number(); Type: FUNCTION; Schema: data; Owner: postgres
--

CREATE FUNCTION fn_update_version_number() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
	NEW.version_number=nextval('data.version_number_seq');
	RETURN new;
END;
$$;


ALTER FUNCTION data.fn_update_version_number() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 182 (class 1259 OID 10095718)
-- Name: configurations; Type: TABLE; Schema: data; Owner: postgres; Tablespace: 
--

CREATE TABLE configurations (
    config_id bigint DEFAULT nextval('public.configurations_config_id_seq'::regclass) NOT NULL,
    config_key text NOT NULL,
    config_value text
);


ALTER TABLE data.configurations OWNER TO postgres;

--
-- TOC entry 181 (class 1259 OID 10095716)
-- Name: configurations_config_id_seq; Type: SEQUENCE; Schema: data; Owner: postgres
--

CREATE SEQUENCE configurations_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE data.configurations_config_id_seq OWNER TO postgres;

--
-- TOC entry 2868 (class 0 OID 0)
-- Dependencies: 181
-- Name: configurations_config_id_seq; Type: SEQUENCE OWNED BY; Schema: data; Owner: postgres
--

ALTER SEQUENCE configurations_config_id_seq OWNED BY configurations.config_id;


--
-- TOC entry 184 (class 1259 OID 10862453)
-- Name: version_number_seq; Type: SEQUENCE; Schema: data; Owner: postgres
--

CREATE SEQUENCE version_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE data.version_number_seq OWNER TO postgres;

--
-- TOC entry 171 (class 1259 OID 6022101)
-- Name: defect_details; Type: TABLE; Schema: data; Owner: erp_dbo; Tablespace: 
--

CREATE TABLE defect_details (
    defect_id bigint NOT NULL,
    module_name text,
    defect_desc text,
    priority text,
    reported_by text,
    assigned_to text,
    reported_time text,
    comment text,
    status text,
    screen_location text,
    last_updated_by text,
    deleted text,
    severity text,
    is_deliverable_now text,
    reopen_count text,
    is_deliverable_in_future text,
    aded text,
    ated text,
    pded text,
    pted text,
    is_client_defect text,
    root_cause_analysis text,
    rca_screen_location text,
    is_deliverable_for_first text,
    is_deliverable_for_second text,
    reviewer text,
    version_number bigint DEFAULT nextval('version_number_seq'::regclass) NOT NULL
);


ALTER TABLE data.defect_details OWNER TO erp_dbo;

--
-- TOC entry 172 (class 1259 OID 6022107)
-- Name: defect_details_archived; Type: TABLE; Schema: data; Owner: erp_dbo; Tablespace: 
--

CREATE TABLE defect_details_archived (
    defect_id bigint NOT NULL,
    module_name text NOT NULL,
    defect_desc text,
    priority text,
    reported_by text,
    assigned_to text,
    reported_time text,
    comment text,
    status text,
    screen_location text,
    last_updated_by text,
    deleted text,
    severity text,
    is_deliverable_now text,
    reopen_count text,
    is_deliverable_in_future text,
    pted text,
    pded text,
    ated text,
    aded text,
    is_client_defect text,
    root_cause_analysis text,
    rca_screen_location text,
    is_deliverable_for_first text,
    is_deliverable_for_second text,
    reviewer text,
    version_number bigint
);


ALTER TABLE data.defect_details_archived OWNER TO erp_dbo;

--
-- TOC entry 173 (class 1259 OID 6022113)
-- Name: defect_details_archived_defect_id_seq; Type: SEQUENCE; Schema: data; Owner: erp_dbo
--

CREATE SEQUENCE defect_details_archived_defect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE data.defect_details_archived_defect_id_seq OWNER TO erp_dbo;

--
-- TOC entry 2871 (class 0 OID 0)
-- Dependencies: 173
-- Name: defect_details_archived_defect_id_seq; Type: SEQUENCE OWNED BY; Schema: data; Owner: erp_dbo
--

ALTER SEQUENCE defect_details_archived_defect_id_seq OWNED BY defect_details_archived.defect_id;


--
-- TOC entry 174 (class 1259 OID 6022115)
-- Name: defect_details_defect_id_seq; Type: SEQUENCE; Schema: data; Owner: erp_dbo
--

CREATE SEQUENCE defect_details_defect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE data.defect_details_defect_id_seq OWNER TO erp_dbo;

--
-- TOC entry 2872 (class 0 OID 0)
-- Dependencies: 174
-- Name: defect_details_defect_id_seq; Type: SEQUENCE OWNED BY; Schema: data; Owner: erp_dbo
--

ALTER SEQUENCE defect_details_defect_id_seq OWNED BY defect_details.defect_id;


--
-- TOC entry 175 (class 1259 OID 6022117)
-- Name: deployment_details; Type: TABLE; Schema: data; Owner: postgres; Tablespace: 
--

CREATE TABLE deployment_details (
    id bigint NOT NULL,
    server_name text,
    url text,
    broker text,
    scheduler text,
    database text,
    deployment_time text,
    updated_by text
);


ALTER TABLE data.deployment_details OWNER TO postgres;

--
-- TOC entry 176 (class 1259 OID 6022123)
-- Name: deployment_details_id_seq; Type: SEQUENCE; Schema: data; Owner: postgres
--

CREATE SEQUENCE deployment_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE data.deployment_details_id_seq OWNER TO postgres;

--
-- TOC entry 2874 (class 0 OID 0)
-- Dependencies: 176
-- Name: deployment_details_id_seq; Type: SEQUENCE OWNED BY; Schema: data; Owner: postgres
--

ALTER SEQUENCE deployment_details_id_seq OWNED BY deployment_details.id;


--
-- TOC entry 177 (class 1259 OID 6022125)
-- Name: messages; Type: TABLE; Schema: data; Owner: postgres; Tablespace: 
--

CREATE TABLE messages (
    id bigint NOT NULL,
    user_name text,
    message text,
    "time" text
);


ALTER TABLE data.messages OWNER TO postgres;

--
-- TOC entry 178 (class 1259 OID 6022131)
-- Name: message_id_seq; Type: SEQUENCE; Schema: data; Owner: postgres
--

CREATE SEQUENCE message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE data.message_id_seq OWNER TO postgres;

--
-- TOC entry 2876 (class 0 OID 0)
-- Dependencies: 178
-- Name: message_id_seq; Type: SEQUENCE OWNED BY; Schema: data; Owner: postgres
--

ALTER SEQUENCE message_id_seq OWNED BY messages.id;


--
-- TOC entry 179 (class 1259 OID 6022133)
-- Name: module_details; Type: TABLE; Schema: data; Owner: erp_dbo; Tablespace: 
--

CREATE TABLE module_details (
    module_id bigint NOT NULL,
    module_name text NOT NULL,
    module_owner text
);


ALTER TABLE data.module_details OWNER TO erp_dbo;

--
-- TOC entry 180 (class 1259 OID 6022139)
-- Name: user_details; Type: TABLE; Schema: data; Owner: postgres; Tablespace: 
--

CREATE TABLE user_details (
    id bigint NOT NULL,
    host_name text,
    user_name text,
    role text,
    ip_address text,
    option_access text
);


ALTER TABLE data.user_details OWNER TO postgres;

--
-- TOC entry 2734 (class 2604 OID 6022145)
-- Name: defect_id; Type: DEFAULT; Schema: data; Owner: erp_dbo
--

ALTER TABLE ONLY defect_details ALTER COLUMN defect_id SET DEFAULT nextval('defect_details_defect_id_seq'::regclass);


--
-- TOC entry 2736 (class 2604 OID 6022146)
-- Name: defect_id; Type: DEFAULT; Schema: data; Owner: erp_dbo
--

ALTER TABLE ONLY defect_details_archived ALTER COLUMN defect_id SET DEFAULT nextval('defect_details_archived_defect_id_seq'::regclass);


--
-- TOC entry 2737 (class 2604 OID 6022147)
-- Name: id; Type: DEFAULT; Schema: data; Owner: postgres
--

ALTER TABLE ONLY deployment_details ALTER COLUMN id SET DEFAULT nextval('deployment_details_id_seq'::regclass);


--
-- TOC entry 2738 (class 2604 OID 6022148)
-- Name: id; Type: DEFAULT; Schema: data; Owner: postgres
--

ALTER TABLE ONLY messages ALTER COLUMN id SET DEFAULT nextval('message_id_seq'::regclass);


--
-- TOC entry 2753 (class 2606 OID 10095726)
-- Name: configurations_pkey; Type: CONSTRAINT; Schema: data; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY configurations
    ADD CONSTRAINT configurations_pkey PRIMARY KEY (config_id);


--
-- TOC entry 2743 (class 2606 OID 6022378)
-- Name: defect_details_archived_pkey; Type: CONSTRAINT; Schema: data; Owner: erp_dbo; Tablespace: 
--

ALTER TABLE ONLY defect_details_archived
    ADD CONSTRAINT defect_details_archived_pkey PRIMARY KEY (defect_id, module_name);


--
-- TOC entry 2741 (class 2606 OID 6022380)
-- Name: defect_details_pkey; Type: CONSTRAINT; Schema: data; Owner: erp_dbo; Tablespace: 
--

ALTER TABLE ONLY defect_details
    ADD CONSTRAINT defect_details_pkey PRIMARY KEY (defect_id);


--
-- TOC entry 2745 (class 2606 OID 6022382)
-- Name: deployment_details_pkey; Type: CONSTRAINT; Schema: data; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY deployment_details
    ADD CONSTRAINT deployment_details_pkey PRIMARY KEY (id);


--
-- TOC entry 2747 (class 2606 OID 6022384)
-- Name: messages_pkey; Type: CONSTRAINT; Schema: data; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- TOC entry 2749 (class 2606 OID 6022386)
-- Name: module_details_pkey; Type: CONSTRAINT; Schema: data; Owner: erp_dbo; Tablespace: 
--

ALTER TABLE ONLY module_details
    ADD CONSTRAINT module_details_pkey PRIMARY KEY (module_id);


--
-- TOC entry 2751 (class 2606 OID 6022388)
-- Name: user_details_pkey; Type: CONSTRAINT; Schema: data; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_details
    ADD CONSTRAINT user_details_pkey PRIMARY KEY (id);


--
-- TOC entry 2754 (class 2620 OID 10863625)
-- Name: update_version_number; Type: TRIGGER; Schema: data; Owner: erp_dbo
--

CREATE TRIGGER update_version_number BEFORE UPDATE ON defect_details FOR EACH ROW EXECUTE PROCEDURE fn_update_version_number();


--
-- TOC entry 2866 (class 0 OID 0)
-- Dependencies: 7
-- Name: data; Type: ACL; Schema: -; Owner: erp_dbo
--

REVOKE ALL ON SCHEMA data FROM PUBLIC;
REVOKE ALL ON SCHEMA data FROM erp_dbo;
GRANT ALL ON SCHEMA data TO erp_dbo;
GRANT ALL ON SCHEMA data TO erp_app;


--
-- TOC entry 2867 (class 0 OID 0)
-- Dependencies: 182
-- Name: configurations; Type: ACL; Schema: data; Owner: postgres
--

REVOKE ALL ON TABLE configurations FROM PUBLIC;
REVOKE ALL ON TABLE configurations FROM postgres;
GRANT ALL ON TABLE configurations TO postgres;
GRANT ALL ON TABLE configurations TO PUBLIC;


--
-- TOC entry 2869 (class 0 OID 0)
-- Dependencies: 171
-- Name: defect_details; Type: ACL; Schema: data; Owner: erp_dbo
--

REVOKE ALL ON TABLE defect_details FROM PUBLIC;
REVOKE ALL ON TABLE defect_details FROM erp_dbo;
GRANT ALL ON TABLE defect_details TO PUBLIC;


--
-- TOC entry 2870 (class 0 OID 0)
-- Dependencies: 172
-- Name: defect_details_archived; Type: ACL; Schema: data; Owner: erp_dbo
--

REVOKE ALL ON TABLE defect_details_archived FROM PUBLIC;
REVOKE ALL ON TABLE defect_details_archived FROM erp_dbo;
GRANT ALL ON TABLE defect_details_archived TO erp_dbo;
GRANT ALL ON TABLE defect_details_archived TO PUBLIC;


--
-- TOC entry 2873 (class 0 OID 0)
-- Dependencies: 175
-- Name: deployment_details; Type: ACL; Schema: data; Owner: postgres
--

REVOKE ALL ON TABLE deployment_details FROM PUBLIC;
REVOKE ALL ON TABLE deployment_details FROM postgres;
GRANT ALL ON TABLE deployment_details TO postgres;
GRANT ALL ON TABLE deployment_details TO PUBLIC;


--
-- TOC entry 2875 (class 0 OID 0)
-- Dependencies: 177
-- Name: messages; Type: ACL; Schema: data; Owner: postgres
--

REVOKE ALL ON TABLE messages FROM PUBLIC;
REVOKE ALL ON TABLE messages FROM postgres;
GRANT ALL ON TABLE messages TO postgres;
GRANT ALL ON TABLE messages TO PUBLIC;


--
-- TOC entry 2877 (class 0 OID 0)
-- Dependencies: 179
-- Name: module_details; Type: ACL; Schema: data; Owner: erp_dbo
--

REVOKE ALL ON TABLE module_details FROM PUBLIC;
REVOKE ALL ON TABLE module_details FROM erp_dbo;
GRANT ALL ON TABLE module_details TO erp_dbo;
GRANT ALL ON TABLE module_details TO PUBLIC;


--
-- TOC entry 2878 (class 0 OID 0)
-- Dependencies: 180
-- Name: user_details; Type: ACL; Schema: data; Owner: postgres
--

REVOKE ALL ON TABLE user_details FROM PUBLIC;
REVOKE ALL ON TABLE user_details FROM postgres;
GRANT ALL ON TABLE user_details TO postgres;
GRANT ALL ON TABLE user_details TO PUBLIC;


-- Completed on 2017-04-03 16:27:47

--
-- PostgreSQL database dump complete
--


-- Sequence: data.change_log_id_seq

-- DROP SEQUENCE data.change_log_id_seq;

CREATE SEQUENCE data.change_log_id_seq
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
ALTER TABLE data.change_log_id_seq
  OWNER TO postgres;

  
  -- Table: data.change_log

-- DROP TABLE data.change_log;

CREATE TABLE data.change_log
(
  change_log_id bigint NOT NULL DEFAULT nextval('data.change_log_id_seq'::regclass),
  defect_id text NOT NULL,
  acting_user text NOT NULL,
  activity text NOT NULL,
  creation_date date NOT NULL,
  event_type text,
  CONSTRAINT change_log_pkey PRIMARY KEY (change_log_id )
)
WITH (
  OIDS=FALSE
);
ALTER TABLE data.change_log
  OWNER TO postgres;
GRANT ALL ON TABLE data.change_log TO postgres;
GRANT ALL ON TABLE data.change_log TO public;
