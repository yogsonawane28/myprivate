--STEP 1: Run StopRDT.bat
--STEP 2: Close all related Command propmts
--STEP 3: Delete content from \jboss-eap-6.2\standalone\deployments, jboss-eap-6.2\standalone\tmp, \jboss-eap-6.2\standalone\data, \jboss-eap-6.2\standalone\log
--STEP 4: Copy RDT.war to \jboss-eap-6.2\standalone\deployments
--STEP 5: Update following properties in standalone.xml
--		name="delivery.conf" -- value must be current delivery configuration e.g. 001.541.000
--		name="delivery.date" -- value must be current delivery date, must be in format 'date_month' e.g. 10_Oct, 1_Jan
--		name="next.delivery.date" -- value must be next delivery date, must be in format 'date_month' e.g. 15_Oct, 9_Jan
		
--STEP 6:
--a. Execute following sql 'one by one'
UPDATE data.defect_details SET deleted='ARCHIVED' WHERE status='REJECTED' OR status='CLOSED' or status='DEFERRED'

SELECT COUNT(*) AS total_archived_records FROM data.defect_details_archived -- please note number of total_archived_records

SELECT COUNT(*) AS new_archived_records FROM data.defect_details a WHERE a.deleted IS NOT NULL  -- please note number of new_archived_records

--b. Execute following sql in one shot
WITH moved_rows AS (
    SELECT * FROM data.defect_details a
    WHERE a.deleted is not null
)
INSERT INTO data.defect_details_archived
SELECT * FROM moved_rows;

-- only If primary constaint exception occures in above sql, Please update the module_name in data.defect_details_archived for that records in order to 
-- execute above sql without exception. once module_name change is done, run the above sql again.

--c. Execute following sql one by one
SELECT COUNT(*) AS updated_total_archived_records FROM data.defect_details_archived -- please note number of updated_total_archived_records

-- only if updated_total_archived_records=total_archived_records+new_archived_records run the following sql otherwise 'DON'T'

DELETE FROM data.defect_details a WHERE a.deleted IS NOT NULL

--STEP 7: Run StartRDT.bat 


--Note: Kindly take the backup of database(/rdt_defect_tool) on regular interval  