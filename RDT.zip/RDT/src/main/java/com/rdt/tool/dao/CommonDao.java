package com.rdt.tool.dao;

import java.util.List;
import java.util.Map;

import com.rdt.tool.domains.ChangeLog;
import com.rdt.tool.domains.Configurations;
import com.rdt.tool.domains.DefectDetails;
import com.rdt.tool.domains.Deployment;
import com.rdt.tool.domains.EventDetails;
import com.rdt.tool.domains.Messages;
import com.rdt.tool.domains.ModuleDetails;
import com.rdt.tool.domains.UserDetails;
import com.rdt.tool.webbeans.ChangeLogFilter;
import com.rdt.tool.webbeans.GenericSearchFilter;

public interface CommonDao {
	boolean submitDefect(DefectDetails defectDetails);
	boolean updateDefect(DefectDetails defectDetails);
	List<Deployment> getAllDeploymentDetails();
	boolean updateDeployment(Deployment deployment);
	UserDetails getUserDetails(String hostName);
	List<Messages> getAllMessages();
	boolean submitChat(Messages messages);
	List<String> getUsers(String userTypes);
	boolean deleteDefect(DefectDetails defectDetails);
	List<DefectDetails> getMultipleDefectDetails(List<Long> defectIds);
	List<ModuleDetails> getModuleDetails();
	List<String> findMostFreeDeveloper(List<String> developers);
	DefectDetails getDefectDetails(String defectId, String module);
	UserDetails getUserDetailsByName(String userName);
	boolean updateUserDetails(UserDetails userDetails);
	List<Configurations> getConfigurations();
	boolean submitChangeLog(ChangeLog changeLog);
	List<ChangeLog> getChangeLogs(ChangeLogFilter changeLogFilter);
	List<Object[]> getGenericSearch(GenericSearchFilter genericSearchFilter);
	List<DefectDetails> getAllDefectDetails(String requestType);
	Map<String, String> getAllDefectCounts();
	List<Configurations> getConfigurationDetails();
	boolean updateConfigurationDetails(Configurations configurations);
	boolean moveDefectsToArchive();
	boolean updateEvent(EventDetails eventDetails, String action);
	EventDetails getEventDetails(String eventId);
	List<EventDetails> getAllEventDetails(String user);	
}
