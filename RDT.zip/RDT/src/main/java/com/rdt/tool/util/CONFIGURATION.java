package com.rdt.tool.util;

import java.util.LinkedHashMap;

import org.apache.log4j.Logger;

public class CONFIGURATION {

	 private final static Logger LOGGER = Logger.getLogger(CONFIGURATION.class);
	
	 public static LinkedHashMap<String, String> CONFIG=null;
	 
	 public static enum CONFIGURATION_KEYS {
		  NEXT_DELIVERY_CONF("next.delivery.conf"),
		  NEXT_DELIVERY_DATE("next.delivery.date"),
		  TAB_NAME_1("tab.name1"),
		  TAB_NAME_2("tab.name2"),
		  TAB_NAME_3("tab.name3"),
		  TAB_NAME_4("tab.name4"),
		  FILE_UPLOAD_ROOTPATH("file.upload.rootpath"),
		  BROADCAST_MANAGER_FLAG("broadcast.manager.flag"),
		  AUTOASSIGNER_MANAGER_FLAG("autoassigner.manager.flag"),
		  BROADCAST_INTERVAL("broadcast.interval"),
		  EXT_URL1_NAME("ext.url1.name"),
		  EXT_URL2_NAME("ext.url2.name"),
		  EXT_URL3_NAME("ext.url3.name"),
		  EXT_URL1_VALUE("ext.url1.value"),
		  EXT_URL2_VALUE("ext.url2.value"),
		  EXT_URL3_VALUE("ext.url3.value"),
		  RTT_THRESHOLD("rtt.threshold"),
		  FIXED_THRESHOLD("fixed.threshold"),
		  UNASSIGNED_THRESHOLD("unassigned.threshold"),
		  NOTIFICATION_INTERVAL("notification.interval"),
		  PROJECT_NAME("project.name"),
		  POLL_INTERVAL("poll.interval"),
		  RDT_RESTART_SCRIPT_NAME("rdt.restart.script.name")
		 
		  ;
		  
		  private String key;
		  CONFIGURATION_KEYS(String key) {
		      this.key = key ;
		  }
		  public String getValue() {
		      return this.key;
		  }
     } 
	 
	 public static synchronized boolean isConfigInitialize() {
		return (CONFIG!=null); 
	 }
	 
	 public static synchronized void resetConfig() {
			CONFIG=null; 
		 }
	 
	 public static synchronized void InitializeConfig() {
		CONFIG=new LinkedHashMap<String, String>();
		LOGGER.info("CONFIG initialize!");
	 }
	 
	 public static void putKeyValue(String key, String value) {
		if(isConfigInitialize()) {
			CONFIG.put(key, value);
			LOGGER.info("Loading key: "+key+", Value: "+value);
		}
	 }
	 
	 public static String getValue(String key) {
		 String value=null;
		if(isConfigInitialize() && CONFIG.containsKey(key)) {
			value=CONFIG.get(key);
		}else {
			LOGGER.error(key+" is not present in the configurations");
		}
		return value;
	}
}
