package com.rdt.tool.dao.impl;

import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.rdt.tool.dao.CommonDao;
import com.rdt.tool.domains.ChangeLog;
import com.rdt.tool.domains.Configurations;
import com.rdt.tool.domains.DefectDetails;
import com.rdt.tool.domains.Deployment;
import com.rdt.tool.domains.EventDetails;
import com.rdt.tool.domains.Messages;
import com.rdt.tool.domains.ModuleDetails;
import com.rdt.tool.domains.UserDetails;
import com.rdt.tool.service.impl.CommonServicesImpl.VIEW_NAME;
import com.rdt.tool.util.Constants;
import com.rdt.tool.util.HibernateUtil;
import com.rdt.tool.webbeans.ChangeLogFilter;
import com.rdt.tool.webbeans.GenericSearchFilter;

@Repository
public class CommonDaoImpl implements CommonDao {
	
	private static SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	private final static Logger LOGGER = Logger.getLogger(CommonDaoImpl.class);


	@SuppressWarnings("unchecked")
	@Override
	public List<String> getUsers(String userTypes) {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<String> users = null;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			if(null!=userTypes){
				query = session.createQuery("select userName from UserDetails where role in ("+userTypes+")");
			}else{
				query = session.createQuery("select userName from UserDetails");
			}
			users = query.list();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getUsers");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return users;
	}
			
	@Override
	public Map<String,String> getAllDefectCounts() {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<String> status=new ArrayList<String>();
		status.add(VIEW_NAME.DEFERRED.getViewName());
		status.add(VIEW_NAME.REJECTED.getViewName());
		status.add(VIEW_NAME.CLOSED.getViewName());
		status.add(VIEW_NAME.RTT.getViewName());
		status.add(VIEW_NAME.FIXED.getViewName());
		status.add(VIEW_NAME.REOPENED.getViewName());
		status.add(VIEW_NAME.UNASSIGNED.getViewName());
		Map<String,String> counMap=new HashMap<String, String>();
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			VIEW_NAME[] allStatus=VIEW_NAME.values();
			for(int index=0;index<allStatus.length;index++) {
				Long count=0L;
				String requestType=allStatus[index].getViewName();
				if(requestType.equals(VIEW_NAME.ALL.getViewName())) {
					continue;
				}
				String whereClause=getWhereClause(requestType,status);
				query = session.createQuery("select count(*) from DefectDetails "+whereClause);
				if(VIEW_NAME.DELIVERY_NOW.getViewName().equals(requestType) || VIEW_NAME.DELIVERY_NEXT.getViewName().equals(requestType) ||
				 			VIEW_NAME.DELIVERY_FIRST.getViewName().equals(requestType) || VIEW_NAME.DELIVERY_SECOND.getViewName().equals(requestType) || VIEW_NAME.OPEN.getViewName().equals(requestType)) {
				 	query.setParameterList("status", status);
				}	
				count = (Long) query.uniqueResult();
				counMap.put(requestType, String.valueOf(count));
			}
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getAllDefectCounts");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return counMap;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<DefectDetails> getAllDefectDetails(String requestType) {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<String> status=new ArrayList<String>();
		status.add(VIEW_NAME.DEFERRED.getViewName());
		status.add(VIEW_NAME.REJECTED.getViewName());
		status.add(VIEW_NAME.CLOSED.getViewName());
		status.add(VIEW_NAME.RTT.getViewName());
		status.add(VIEW_NAME.FIXED.getViewName());
		status.add(VIEW_NAME.REOPENED.getViewName());
		status.add(VIEW_NAME.UNASSIGNED.getViewName());
		List<DefectDetails> defectList = null;
		try {
				session = sessionFactory.openSession();
				tx = session.beginTransaction();
				String whereClause=getWhereClause(requestType,status);
			 	query = session.createQuery("from DefectDetails "+whereClause+" order by defectId desc");
			 	if(VIEW_NAME.DELIVERY_NOW.getViewName().equals(requestType) || VIEW_NAME.DELIVERY_NEXT.getViewName().equals(requestType) ||
			 			VIEW_NAME.DELIVERY_FIRST.getViewName().equals(requestType) || VIEW_NAME.DELIVERY_SECOND.getViewName().equals(requestType) || VIEW_NAME.OPEN.getViewName().equals(requestType)) {
			 		query.setParameterList("status", status);
			 	}	
				defectList = query.list();
				tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getAllDefectDetails");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return defectList;
	}
	
	private String getWhereClause(String requestType,List<String> status) {
		String whereClause=" where deleted is null";		
		if(!StringUtils.isEmpty(requestType)) {			
			if(VIEW_NAME.ALL.getViewName().equals(requestType)) {
				whereClause=" where deleted is null";
			}else if(status.contains(requestType)) {
				whereClause=" where status='"+requestType+"' and deleted is null";
			}else if(VIEW_NAME.DELIVERY_NOW.getViewName().equals(requestType)) {
				whereClause=" where status not in (:status) and isDeliverableNow is not null and deleted is null";
			}else if(VIEW_NAME.DELIVERY_NEXT.getViewName().equals(requestType)) {
				whereClause="where status not in (:status) and isDeliverableInFuture is not null and deleted is null";
			}else if(VIEW_NAME.DELIVERY_FIRST.getViewName().equals(requestType)) {
				whereClause="where status not in (:status) and isDeliverableForFirst is not null and deleted is null";
			}else if(VIEW_NAME.DELIVERY_SECOND.getViewName().equals(requestType)) {
				whereClause="where status not in (:status) and isDeliverableForSecond is not null and deleted is null";
			}else if(VIEW_NAME.OPEN.getViewName().equals(requestType)) {
				whereClause="where status not in (:status) and isDeliverableNow is null and isDeliverableInFuture is null and " +
						"isDeliverableForFirst is null and isDeliverableForSecond is null and deleted is null";
			}else if(null!=requestType && !requestType.equals("")) {
				whereClause=" where defectId in ("+requestType+")";
			}
		}
		return whereClause; 
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Deployment> getAllDeploymentDetails() {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<Deployment> deploymentList=null;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			query = session.createQuery("from Deployment order by id");
			deploymentList = query.list();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getAllDeploymentDetails");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return deploymentList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<EventDetails> getAllEventDetails(String user) {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<EventDetails> eventDetails=null;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			query = session.createQuery("from EventDetails where eventType=:publicEventType or (eventType=:privateEventType and eventCreator=:eventCreator)");
			query.setParameter("publicEventType", "Public");
			query.setParameter("privateEventType", "Private");
			query.setParameter("eventCreator", user);
			eventDetails = query.list();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getAllEventDetails");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return eventDetails;
	}
	
	@Override
	public EventDetails getEventDetails(String eventId) {
		Session session = null;
		Transaction tx=null;
		Query query = null;
		EventDetails eventDetails=null;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			 String hql="from EventDetails where eventId =:eventId";
			 query = session.createQuery(hql);
			 query.setBigInteger("eventId", new BigInteger(eventId));
			 query.setMaxResults(1);
			 eventDetails=(EventDetails) query.uniqueResult();
			 tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getEventDetails");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return eventDetails;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Configurations> getConfigurationDetails() {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<Configurations> configurations=null;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			query = session.createQuery("from Configurations order by id");
			configurations = query.list();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getConfigurationDetails");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return configurations;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Messages> getAllMessages() {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<Messages> messages=null;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			query = session.createQuery("from Messages order by id");
			messages = query.list();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getAllMessages");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return messages;
	}

	@Override
	public DefectDetails getDefectDetails(String defectId,String module) {
		Session session = null;
		Transaction tx=null;
		Query query = null;
		DefectDetails defectDetails=null;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			 String hql="from DefectDetails where defectId =:defectId";
			 if(!StringUtils.isEmpty(module)){
				 hql+=" and moduleName=:module";
			 }
			 query = session.createQuery(hql);
			 query.setBigInteger("defectId", new BigInteger(defectId));
			 if(!StringUtils.isEmpty(module)){
				 module=module.trim();
				 query.setString("module", module);
			 }
			 query.setMaxResults(1);
			 defectDetails=(DefectDetails) query.uniqueResult();
			 tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getDefectDetails");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return defectDetails;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<DefectDetails> getMultipleDefectDetails(List<Long> defectIds) {
		Session session = null;
		Query query = null;
		Transaction tx=null;
		List<DefectDetails> defectDetails = null;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			query = session.createQuery("from DefectDetails where defectId in (:defectIds)");
			query.setParameterList("defectIds", defectIds);
			defectDetails = query.list();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getMultipleDefectDetails");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return defectDetails;
	}
	
	
	@Override
	public boolean submitDefect(DefectDetails defectDetails) {
		Session session = null;
		Transaction tx=null;
		boolean flag=false;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			session.save(defectDetails);
			tx.commit();
			flag=true;
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in submitDefect");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return flag;
	}
	
	@Override
	public boolean submitChat(Messages messages) {
		Session session = null;
		Transaction tx=null;
		boolean flag=false;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(messages);
			tx.commit();
			flag=true;
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in submitChat");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return flag;
	}
	
	@Override
	public boolean updateDefect(DefectDetails defectDetails) {
		Session session = null;
		Transaction tx=null;
		boolean flag=false;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			session.update(defectDetails);
			tx.commit();
			flag=true;
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in updateDefect");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return flag;
	}
	
	@Override
	public boolean updateUserDetails(UserDetails userDetails) {
		Session session = null;
		Transaction tx=null;
		boolean flag=false;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			session.update(userDetails);
			tx.commit();
			flag=true;
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in updateUserDetails");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return flag;
	}
	
	@Override
	public boolean deleteDefect(DefectDetails defectDetails) {
		Session session = null;
		Transaction tx=null;
		boolean flag=false;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			session.delete(defectDetails);
			tx.commit();
			flag=true;
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in deleteDefect");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return flag;
	}
	
	@Override
	public boolean updateDeployment(Deployment deployment) {
		Session session = null;
		Transaction tx=null;
		boolean flag=false;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			session.update(deployment);
			tx.commit();
			flag=true;
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in updateDeployment");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return flag;
	}
	
	@Override
	public boolean updateEvent(EventDetails eventDetails, String action) {
		Session session = null;
		Transaction tx=null;
		boolean flag=false;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			if(action.equals("ADD")) {
				session.save(eventDetails);
			}else if(action.equals("UPDATE")) {
				session.update(eventDetails);
			}else if(action.equals("DELETE")){
				session.delete(eventDetails);
			}
			tx.commit();
			flag=true;
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in updateEvent");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return flag;
	}
	
	@Override
	public boolean updateConfigurationDetails(Configurations configurations) {
		Session session = null;
		Transaction tx=null;
		boolean flag=false;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			session.update(configurations);
			tx.commit();
			flag=true;
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in updateConfigurationDetails");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return flag;
	}
	
	@Override
	public UserDetails getUserDetails(String hostName) {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		UserDetails userDetails = null;
		hostName=null!=hostName?hostName.toLowerCase():"";
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			query = session.createQuery("from UserDetails where lower(hostName)='"+hostName+"' or lower(ip)='"+hostName+"'");
			query.setMaxResults(1);
			userDetails = (UserDetails) query.uniqueResult();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getUserDetails");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return userDetails;
	}
	
	@Override
	public UserDetails getUserDetailsByName(String userName) {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		UserDetails userDetails = null;
		userName=null!=userName?userName.toLowerCase():"";
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			query = session.createQuery("from UserDetails where lower(userName)='"+userName+"'");
			query.setMaxResults(1);
			userDetails = (UserDetails) query.uniqueResult();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getUserDetailsByName");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return userDetails;
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<ModuleDetails> getModuleDetails() {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<ModuleDetails> moduleDetails = null;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			query = session.createQuery("from ModuleDetails order by moduleName");
			moduleDetails = query.list();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getModuleDetails");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return moduleDetails;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> findMostFreeDeveloper(List<String> developers) {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<String> freeDevelopers = null;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			 String hql="select assignedTo from DefectDetails where assignedTo in (:developers) and status in('ASSIGNED','WIP','REOPENED') and deleted is null and (isDeliverableNow is not null or isDeliverableInFuture is not null) GROUP BY assignedTo ORDER BY COUNT(assignedTo) ";
			 query = session.createQuery(hql);
			 query.setParameterList("developers", developers);
			freeDevelopers = query.list();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in findMostFreeDeveloper");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return freeDevelopers;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getGenericSearch(GenericSearchFilter genericSearchFilter) {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<Object[]> defectData = null;
		try {
			session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			 String sql="select defect_id,module_name,defect_desc,reported_by,assigned_to,priority,severity,status,last_updated_by,is_client_defect from data.defect_details where ";
			 if(!StringUtils.isEmpty(genericSearchFilter.getWildInput())) {
				 if(!StringUtils.isEmpty(genericSearchFilter.getIsClientDefect()) && genericSearchFilter.getIsClientDefect().equals("YES")){
					 sql+="is_client_defect='YES' and ";
				 }else if(!StringUtils.isEmpty(genericSearchFilter.getIsClientDefect()) && genericSearchFilter.getIsClientDefect().equals("NO")){
					 sql+="is_client_defect='NO' and ";
				 }
				 sql+="(lower(module_name) like '%"+genericSearchFilter.getWildInput().toLowerCase()+"%' or lower(defect_desc) like '%"+genericSearchFilter.getWildInput().toLowerCase()+"%' or " +
				 		"lower(reported_by) like '%"+genericSearchFilter.getWildInput().toLowerCase()+"%' or lower(assigned_to) like '%"+genericSearchFilter.getWildInput().toLowerCase()+"%' or lower(priority) like '%"+genericSearchFilter.getWildInput().toLowerCase()+"%' or " +
				 				"lower(status) like '%"+genericSearchFilter.getWildInput().toLowerCase()+"%' or lower(severity) like '%"+genericSearchFilter.getWildInput().toLowerCase()+"%')";	 
			 }else {
				 if(!StringUtils.isEmpty(genericSearchFilter.getDefectId())){
					 sql+="defect_id ="+genericSearchFilter.getDefectId()+" and ";
				 }
				 if(!StringUtils.isEmpty(genericSearchFilter.getModuleName())){
					 sql+="lower(module_name) like '%"+genericSearchFilter.getModuleName().toLowerCase()+"%' and ";
				 }
				 if(!StringUtils.isEmpty(genericSearchFilter.getDefectDesc())){
					 sql+="lower(defect_desc) like '%"+genericSearchFilter.getDefectDesc().toLowerCase()+"%' and ";
				 }
				 if(!StringUtils.isEmpty(genericSearchFilter.getReportedBy())){
					 sql+="lower(reported_by) like '%"+genericSearchFilter.getReportedBy().toLowerCase()+"%' and ";
				 }
				 if(!StringUtils.isEmpty(genericSearchFilter.getAssignedTo())){
					 sql+="lower(assigned_to) like '%"+genericSearchFilter.getAssignedTo().toLowerCase()+"%' and ";
				 }
				 if(!StringUtils.isEmpty(genericSearchFilter.getPriority())){
					 sql+="lower(priority) like '%"+genericSearchFilter.getPriority().toLowerCase()+"%' and ";
				 }
				 if(!StringUtils.isEmpty(genericSearchFilter.getStatus())){
					 sql+="lower(status) like '%"+genericSearchFilter.getStatus().toLowerCase()+"%' and ";
				 }
				 if(!StringUtils.isEmpty(genericSearchFilter.getSeverity())){
					 sql+="lower(severity) like '%"+genericSearchFilter.getSeverity().toLowerCase()+"%' and ";
				 }
				 if(!StringUtils.isEmpty(genericSearchFilter.getIsClientDefect()) && genericSearchFilter.getIsClientDefect().equals("YES")){
					 sql+="is_client_defect='YES' and ";
				 }else if(!StringUtils.isEmpty(genericSearchFilter.getIsClientDefect()) && genericSearchFilter.getIsClientDefect().equals("NO")){
					 sql+="is_client_defect='NO' and ";
				 }
				 sql+=" 1=1 ";	
			 }
			query = session.createSQLQuery(sql);
			query.setMaxResults(2000);
			defectData =  query.list();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getGenericSearch");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return defectData;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Configurations> getConfigurations() {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<Configurations> configurations=null;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			query = session.createQuery("from Configurations");
			configurations = query.list();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getConfigurations");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return configurations;
	}
	
	@Override
	public boolean moveDefectsToArchive() {
		boolean flag= false;
		Query query = null;
		Session session = null;
		Transaction tx=null;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			query = session.createQuery("Update DefectDetails set deleted=:archived where status in ('CLOSED','REJECTED')");
			query.setString("archived", "ARCHIVED");
			query.executeUpdate();
			tx.commit();
			flag=true;
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in moveDefectsToArchive");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return flag;
	}
	
	@Override
	public boolean submitChangeLog(ChangeLog changeLog) {
		Session session = null;
		Transaction tx=null;
		boolean flag=false;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(changeLog);
			tx.commit();
			flag=true;
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in submitChangeLog");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return flag;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ChangeLog> getChangeLogs(ChangeLogFilter changeLogFilter) {
		Query query = null;
		Session session = null;
		Transaction tx=null;
		List<ChangeLog> changeLogs=null;
		StringBuilder builder=new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.simpleDateformatter);
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			builder.append("from ChangeLog");
			if(!StringUtils.isEmpty(changeLogFilter.getDefectId())){
				builder.append(" where defectId like :defectId");
			}else {
				builder.append(" where 1=1");
			}
			if(!StringUtils.isEmpty(changeLogFilter.getActingUser())) {
				builder.append(" and lower(actingUser) like :actingUser");
			}else {
				builder.append(" and 1=1");
			}
			if(!StringUtils.isEmpty(changeLogFilter.getEventType())) {
				builder.append(" and lower(eventType) like :eventType");
			}else {
				builder.append(" and 1=1");
			}
			if(!StringUtils.isEmpty(changeLogFilter.getFromDate())) {
				builder.append(" and creationDate >=:fromDate");
			}else {
				builder.append(" and 1=1");
			}
			if(!StringUtils.isEmpty(changeLogFilter.getToDate())) {
				builder.append(" and creationDate <=:toDate");
			}else {
				builder.append(" and 1=1");
			}
			builder.append(" order by changeLogId desc");
			query = session.createQuery(builder.toString());
			if(!StringUtils.isEmpty(changeLogFilter.getDefectId())){
				query.setString("defectId", "%"+changeLogFilter.getDefectId()+"%");
			}
			if(!StringUtils.isEmpty(changeLogFilter.getActingUser())) {
				query.setString("actingUser", "%"+(changeLogFilter.getActingUser().toLowerCase())+"%");
			}
			if(!StringUtils.isEmpty(changeLogFilter.getEventType())) {
				query.setString("eventType", "%"+(changeLogFilter.getEventType().toLowerCase())+"%");
			}
			if(!StringUtils.isEmpty(changeLogFilter.getFromDate())) {
				Date fromDate=null;
				try{
					fromDate = sdf.parse(changeLogFilter.getFromDate());	
	        	}catch(ParseException exception){
	        		exception.printStackTrace();
	        	}
				query.setDate("fromDate", fromDate);
			}
			if(!StringUtils.isEmpty(changeLogFilter.getToDate())) {
				Date toDate=null;
				try{
					toDate = sdf.parse(changeLogFilter.getToDate());	
	        	}catch(ParseException exception){
	        		exception.printStackTrace();
	        	}
				query.setDate("toDate", toDate);
			}
			changeLogs = query.list();
			tx.commit();
		} catch (Exception e) {
			if(null!=tx){
				tx.rollback();
			}
			LOGGER.error("Exception in getChangeLogs");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return changeLogs;
	}
}