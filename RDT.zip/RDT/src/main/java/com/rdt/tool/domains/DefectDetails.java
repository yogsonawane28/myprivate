package com.rdt.tool.domains;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "data.defect_details")
public class DefectDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "defect_id")
	private long defectId;

	@Column(name = "module_name")
	private String moduleName;

	@Column(name = "defect_desc")
	private String defectDesc;

	@Column(name = "priority")
	private String priority;

	@Column(name = "reported_by")
	private String reportedBy;

	@Column(name = "assigned_to")
	private String assignedTo;
	
	@Column(name = "reported_time")
	private String reportedTime;

	@Column(name = "comment")
	private String comment;
	
	@Column(name = "status")
	private String status;
	
	@Column(name="root_cause_analysis")
	private String analysis;

	@Column(name = "screen_location")
	private String screenLocation;
	
	@Column(name = "rca_screen_location")
	private String rcaLocation;
	
	@Column(name = "is_deliverable_for_first")
	private String isDeliverableForFirst;
	
	@Column(name = "is_deliverable_for_second")
	private String isDeliverableForSecond;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "deleted")
	private String deleted;
	
	@Column(name = "severity")
	private String severity;
	
	@Column(name = "is_deliverable_now")
	private String isDeliverableNow;
	
	@Column(name = "reopen_count")
	private String reopenCount;
	
	@Column(name = "is_deliverable_in_future")
	private String isDeliverableInFuture;
	
	@Column(name = "pded")
	private String pded;
	
	@Column(name = "pted")
	private String pted;
	
	@Column(name = "aded")
	private String aded;
	
	@Column(name = "ated")
	private String ated;
	
	@Column(name = "is_client_defect")
	private String isClientDefect;
	
	@Transient
	private String isPdedPassed;
	
	@Transient
	private String isPtedPassed;
	
	@Column(name = "reviewer")
	private String reviewer;
	
	@Column(name = "version_number")
	private long versionNumber;
	
	@Column(name = "linked_defect_id")
	private String linkedDefectId;
	
	@Column(name = "linked_defect_count")
	private String linkedDefectCount;
	
	@Column(name = "is_on_hold")
	private String isOnHold;
	
	public long getDefectId() {
		return defectId;
	}

	public void setDefectId(long defectId) {
		this.defectId = defectId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getDefectDesc() {
		return defectDesc;
	}

	public void setDefectDesc(String defectDesc) {
		this.defectDesc = defectDesc;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getReportedBy() {
		return reportedBy;
	}

	public void setReportedBy(String reportedBy) {
		this.reportedBy = reportedBy;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getReportedTime() {
		return reportedTime;
	}

	public void setReportedTime(String reportedTime) {
		this.reportedTime = reportedTime;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAnalysis() {
		return analysis;
	}

	public void setAnalysis(String analysis) {
		this.analysis = analysis;
	}
	public String getScreenLocation() {
		return screenLocation;
	}

	public void setScreenLocation(String screenLocation) {
		this.screenLocation = screenLocation;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getDeleted() {
		return deleted;
	}

	public void setDeleted(String deleted) {
		this.deleted = deleted;
	}
	
	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getIsDeliverableNow() {
		return isDeliverableNow;
	}

	public void setIsDeliverableNow(String isDeliverableNow) {
		this.isDeliverableNow = isDeliverableNow;
	}

	public String getReopenCount() {
		return reopenCount;
	}

	public void setReopenCount(String reopenCount) {
		this.reopenCount = reopenCount;
	}

	public String getIsDeliverableInFuture() {
		return isDeliverableInFuture;
	}

	public void setIsDeliverableInFuture(String isDeliverableInFuture) {
		this.isDeliverableInFuture = isDeliverableInFuture;
	}

	public String getPded() {
		return pded;
	}

	public void setPded(String pded) {
		this.pded = pded;
	}

	public String getPted() {
		return pted;
	}

	public void setPted(String pted) {
		this.pted = pted;
	}

	public String getAded() {
		return aded;
	}

	public void setAded(String aded) {
		this.aded = aded;
	}

	public String getAted() {
		return ated;
	}

	public void setAted(String ated) {
		this.ated = ated;
	}

	public String getIsPdedPassed() {
		return isPdedPassed;
	}

	public void setIsPdedPassed(String isPdedPassed) {
		this.isPdedPassed = isPdedPassed;
	}

	public String getIsPtedPassed() {
		return isPtedPassed;
	}

	public void setIsPtedPassed(String isPtedPassed) {
		this.isPtedPassed = isPtedPassed;
	}

	public String getIsClientDefect() {
		return isClientDefect;
	}

	public void setIsClientDefect(String isClientDefect) {
		this.isClientDefect = isClientDefect;
	}

	public String getRcaLocation() {
		return rcaLocation;
	}

	public void setRcaLocation(String rcaLocation) {
		this.rcaLocation = rcaLocation;
	}
	
	public String getIsDeliverableForFirst() {
		return isDeliverableForFirst;
	}

	public void setIsDeliverableForFirst(String isDeliverableForFirst) {
		this.isDeliverableForFirst = isDeliverableForFirst;
	}
	public String getIsDeliverableForSecond() {
		return isDeliverableForSecond;
	}

	public void setIsDeliverableForSecond(String isDeliverableForSecond) {
		this.isDeliverableForSecond = isDeliverableForSecond;
	}

	public String getReviewer() {
		return reviewer;
	}

	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}

	public long getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(long versionNumber) {
		this.versionNumber = versionNumber;
	}

	public String getLinkedDefectId() {
		return linkedDefectId;
	}

	public void setLinkedDefectId(String linkedDefectId) {
		this.linkedDefectId = linkedDefectId;
	}

	public String getLinkedDefectCount() {
		return linkedDefectCount;
	}

	public void setLinkedDefectCount(String linkedDefectCount) {
		this.linkedDefectCount = linkedDefectCount;
	}

	public String getIsOnHold() {
		return isOnHold;
	}

	public void setIsOnHold(String isOnHold) {
		this.isOnHold = isOnHold;
	}
	
}
