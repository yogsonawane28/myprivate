package com.rdt.tool.webbeans;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Defect implements Serializable{
	
	private String defectId;
	private String moduleName;
	private String desc;
	private String priority;
	private String reportedby;
	private String assignedto;
	private String reporttime;
	private String comment;
	private String status;
	private String analysis;
	private String location;
	private String rcaLocation;
	private String requesttype;
	private String lastupdatedby;
	private String isDeliverableNow;
	private String severity;
	private String reopenCount;
	private String isDeliverableInFuture;
	private String isDeliverableForFirst;
	private String isDeliverableForSecond;
	private String pded;
	private String pted;
	private String aded;
	private String ated;
	private String isClientDefect;
	private String reviewer;
	private String versionNumber;
	private String linkedDefectId;
	private String oldLinkedDefectId;
	private String linkedDefectCount;
	private String isOnHold;
	
	public String getDefectId() {
		return defectId;
	}
	public void setDefectId(String defectId) {
		this.defectId = defectId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getReportedby() {
		return reportedby;
	}
	public void setReportedby(String reportedby) {
		this.reportedby = reportedby;
	}
	public String getAssignedto() {
		return assignedto;
	}
	public void setAssignedto(String assignedto) {
		this.assignedto = assignedto;
	}
	
	public String getReporttime() {
		return reporttime;
	}
	public void setReporttime(String reporttime) {
		this.reporttime = reporttime;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAnalysis() {
		return analysis;
	}
	public void setAnalysis(String analysis) {
		this.analysis = analysis;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public String getRequesttype() {
		return requesttype;
	}
	public void setRequesttype(String requesttype) {
		this.requesttype = requesttype;
	}
	public String getLastupdatedby() {
		return lastupdatedby;
	}
	public void setLastupdatedby(String lastupdatedby) {
		this.lastupdatedby = lastupdatedby;
	}
	public String getIsDeliverableNow() {
		return isDeliverableNow;
	}
	public void setIsDeliverableNow(String isDeliverableNow) {
		this.isDeliverableNow = isDeliverableNow;
	}
	public String getSeverity() {
		return severity;
	}
	public void setSeverity(String severity) {
		this.severity = severity;
	}
	public String getReopenCount() {
		return reopenCount;
	}
	public void setReopenCount(String reopenCount) {
		this.reopenCount = reopenCount;
	}
	public String getIsDeliverableInFuture() {
		return isDeliverableInFuture;
	}
	public void setIsDeliverableInFuture(String isDeliverableInFuture) {
		this.isDeliverableInFuture = isDeliverableInFuture;
	}	
	
	public String getPded() {
		return pded;
	}

	public void setPded(String pded) {
		this.pded = pded;
	}

	public String getPted() {
		return pted;
	}

	public void setPted(String pted) {
		this.pted = pted;
	}

	public String getAded() {
		return aded;
	}

	public void setAded(String aded) {
		this.aded = aded;
	}

	public String getAted() {
		return ated;
	}

	public void setAted(String ated) {
		this.ated = ated;
	}
	public String getIsClientDefect() {
		return isClientDefect;
	}
	public void setIsClientDefect(String isClientDefect) {
		this.isClientDefect = isClientDefect;
	}
	public String getRcaLocation() {
		return rcaLocation;
	}
	public void setRcaLocation(String rcaLocation) {
		this.rcaLocation = rcaLocation;
	}
	public String getIsDeliverableForFirst() {
		return isDeliverableForFirst;
	}
	public void setIsDeliverableForFirst(String isDeliverableForFirst) {
		this.isDeliverableForFirst = isDeliverableForFirst;
	}
	public String getIsDeliverableForSecond() {
		return isDeliverableForSecond;
	}
	public void setIsDeliverableForSecond(String isDeliverableForSecond) {
		this.isDeliverableForSecond = isDeliverableForSecond;
	}
	public String getReviewer() {
		return reviewer;
	}
	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}
	public String getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getLinkedDefectId() {
		return linkedDefectId;
	}
	public void setLinkedDefectId(String linkedDefectId) {
		this.linkedDefectId = linkedDefectId;
	}
	public String getOldLinkedDefectId() {
		return oldLinkedDefectId;
	}
	public void setOldLinkedDefectId(String oldLinkedDefectId) {
		this.oldLinkedDefectId = oldLinkedDefectId;
	}
	public String getLinkedDefectCount() {
		return linkedDefectCount;
	}
	public void setLinkedDefectCount(String linkedDefectCount) {
		this.linkedDefectCount = linkedDefectCount;
	}
	public String getIsOnHold() {
		return isOnHold;
	}
	public void setIsOnHold(String isOnHold) {
		this.isOnHold = isOnHold;
	}
	
}
