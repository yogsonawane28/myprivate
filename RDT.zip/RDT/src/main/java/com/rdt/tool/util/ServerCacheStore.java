package com.rdt.tool.util;

import java.util.HashMap;

public class ServerCacheStore {
	
	public static HashMap<String, Object> mapStore = new HashMap<String, Object>();

	public static Object getStoreValue(String key) {
		if (null != mapStore && mapStore.containsKey(key)) {
			return mapStore.get(key);
		} else {
			return null;
		}
	}

	public static void putStoreValue(String key, Object value) {
		if (null != key && null != value) {
			mapStore.put(key, value);
		}
	}
}