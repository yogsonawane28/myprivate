package com.rdt.tool.domains;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "data.change_log")
public class ChangeLog implements Comparable<ChangeLog>{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "change_log_id")
	private long changeLogId;
	
	@Column(name = "defect_id")
	private String defectId;

	@Column(name = "acting_user")
	private String actingUser;

	@Column(name = "activity")
	private String activity;

	@Column(name = "creation_date")
	private Date creationDate;
	
	@Column(name = "event_type")
	private String eventType;
	
	@Transient
	private String dataUpdateType;
	
	@Transient
	private String oldDefectStatus;
	
	@Transient
	private DefectDetails defectDetails;
	
	@Transient
	private Messages messages;
	
	@Transient
	private List<Deployment> deploymentDetails;
	
	@Transient
	private EventDetails eventDetails;

	public long getChangeLogId() {
		return changeLogId;
	}

	public void setChangeLogId(long changeLogId) {
		this.changeLogId = changeLogId;
	}

	public String getDefectId() {
		return defectId;
	}

	public void setDefectId(String defectId) {
		this.defectId = defectId;
	}

	public String getActingUser() {
		return actingUser;
	}

	public void setActingUser(String actingUser) {
		this.actingUser = actingUser;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	
	public String getDataUpdateType() {
		return dataUpdateType;
	}

	public void setDataUpdateType(String dataUpdateType) {
		this.dataUpdateType = dataUpdateType;
	}
	
	public String getOldDefectStatus() {
		return oldDefectStatus;
	}

	public void setOldDefectStatus(String oldDefectStatus) {
		this.oldDefectStatus = oldDefectStatus;
	}

	public DefectDetails getDefectDetails() {
		return defectDetails;
	}

	public void setDefectDetails(DefectDetails defectDetails) {
		this.defectDetails = defectDetails;
	}

	public Messages getMessages() {
		return messages;
	}

	public void setMessages(Messages messages) {
		this.messages = messages;
	}

	public List<Deployment> getDeploymentDetails() {
		return deploymentDetails;
	}

	public void setDeploymentDetails(List<Deployment> deploymentDetails) {
		this.deploymentDetails = deploymentDetails;
	}

	
	public EventDetails getEventDetails() {
		return eventDetails;
	}

	public void setEventDetails(EventDetails eventDetails) {
		this.eventDetails = eventDetails;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((actingUser == null) ? 0 : actingUser.hashCode());
		result = prime * result
				+ ((activity == null) ? 0 : activity.hashCode());
		result = prime * result + (int) (changeLogId ^ (changeLogId >>> 32));
		result = prime * result
				+ ((creationDate == null) ? 0 : creationDate.hashCode());
		result = prime * result
				+ ((defectId == null) ? 0 : defectId.hashCode());
		result = prime * result
				+ ((eventType == null) ? 0 : eventType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChangeLog other = (ChangeLog) obj;
		if (actingUser == null) {
			if (other.actingUser != null)
				return false;
		} else if (!actingUser.equals(other.actingUser))
			return false;
		if (activity == null) {
			if (other.activity != null)
				return false;
		} else if (!activity.equals(other.activity))
			return false;
		if (changeLogId != other.changeLogId)
			return false;
		if (creationDate == null) {
			if (other.creationDate != null)
				return false;
		} else if (!creationDate.equals(other.creationDate))
			return false;
		if (defectId == null) {
			if (other.defectId != null)
				return false;
		} else if (!defectId.equals(other.defectId))
			return false;
		if (eventType == null) {
			if (other.eventType != null)
				return false;
		} else if (!eventType.equals(other.eventType))
			return false;
		return true;
	}

	@Override
	public int compareTo(ChangeLog o) {
		return (int) (changeLogId - o.changeLogId);
	}

		
}
