package com.rdt.tool.util;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.rdt.tool.domains.ChangeLog;
import com.rdt.tool.domains.Configurations;
import com.rdt.tool.domains.DefectDetails;
import com.rdt.tool.domains.Deployment;
import com.rdt.tool.domains.EventDetails;
import com.rdt.tool.domains.Messages;
import com.rdt.tool.domains.ModuleDetails;
import com.rdt.tool.domains.UserDetails;

@SuppressWarnings("deprecation")
public final class HibernateUtil {
	
	public static final Logger LOGGER = Logger.getLogger(HibernateUtil.class);

	private static SessionFactory sessionFactory;
	
	static {
		try {
			String dburl = System.getProperty("db.url");
			String dbusername = System.getProperty("db.username");
			String dbpassword = System.getProperty("db.password");
			LOGGER.info("<------ Connecting to -------> "+dburl);
			Configuration configuration = new Configuration();
			configuration.setProperty("hibernate.connection.driver_class", "org.postgresql.Driver");
			configuration.setProperty("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
			configuration.setProperty("hibernate.connection.url", dburl);
			configuration.setProperty("hibernate.connection.username", dbusername);
			configuration.setProperty("hibernate.connection.password", dbpassword);
			configuration.setProperty("cache.use_second_level_cache", "true");
			configuration.setProperty("hibernate.cache.use_query_cache", "true");
			configuration.setProperty("cache.provider_class", "org.hibernate.cache.EhCacheProvider");
			configuration.setProperty("hibernate.cache.region.factory_class", "org.hibernate.cache.ehcache.EhCacheRegionFactory");
			configuration.setProperty("hibernate.show_sql", "false");
			configuration.setProperty("hibernate.format_sql", "false");
			configuration.setProperty("hibernate.use_sql_comments", "false");
			configuration.setProperty("hibernate.cache.region_prefix", "");
			configuration.addAnnotatedClass(DefectDetails.class);
			configuration.addAnnotatedClass(Deployment.class);
			configuration.addAnnotatedClass(UserDetails.class);
			configuration.addAnnotatedClass(Messages.class);
			configuration.addAnnotatedClass(ModuleDetails.class);
			configuration.addAnnotatedClass(Configurations.class);
			configuration.addAnnotatedClass(ChangeLog.class);
			configuration.addAnnotatedClass(EventDetails.class);
			sessionFactory = configuration.buildSessionFactory();
		} catch (Exception e) {
			LOGGER.fatal("Exception occured: " + e.getMessage());
			e.printStackTrace();
		}
		LOGGER.info("<----------- All Database Connections Ready ------------------------>");
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public static void closeSessionFactory() {
		sessionFactory.close();
	}
}
