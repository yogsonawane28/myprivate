package com.rdt.tool.backoffice;

import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

import com.rdt.tool.domains.ChangeLog;

public final class EventsStorage {
	
	public static HashMap<String,PriorityQueue<ChangeLog>> eventMap= new HashMap<String,PriorityQueue<ChangeLog>>();
	
	public static void  subscribeToStorage(String sessionId){
			if(eventMap.containsKey(sessionId)){
				return;
			}else{
				eventMap.put(sessionId, new PriorityQueue<ChangeLog>());
			}
 	}
	
	public static void  subscribeToStorageOnRefresh(String sessionId){
			eventMap.put(sessionId, new PriorityQueue<ChangeLog>());
	}
	
	public static boolean isEventHappend(String sessionId) {
			if(eventMap.containsKey(sessionId)){
				PriorityQueue<ChangeLog> eventList=eventMap.get(sessionId);
				return (null!=eventList && eventList.size()>0);
			}
		return false;
	}
	
	public static ChangeLog getEvent(String sessionId){
	       PriorityQueue<ChangeLog> eventList=eventMap.get(sessionId);
	       return (null!=eventList && eventList.size()>0)?eventList.poll():null;
	}
	
	public static void auditEvent(ChangeLog changeLog){
		synchronized (eventMap) {
			for (Map.Entry<String, PriorityQueue<ChangeLog>> entry : eventMap.entrySet()) {
				 entry.getValue().offer(changeLog);	
			}
		}	
	}
	
	public static ChangeLog pollToServer(String sessionId){
		subscribeToStorage(sessionId);
		if(isEventHappend(sessionId)){
			return getEvent(sessionId);
		}	
		return null;
	}
	
}
