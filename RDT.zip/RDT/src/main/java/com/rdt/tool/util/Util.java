package com.rdt.tool.util;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public final class Util {

	private final static Logger LOGGER = Logger.getLogger(Util.class);
	
	public static <T> Object convertJsonToObject(String json, Class<T> classInstance) {
		Object object=null;
		try {
			object = new ObjectMapper().readValue(json, classInstance);
		} catch (JsonParseException e) {
			LOGGER.error("Exception occured in convertJsonToObject for : "+json);
			e.printStackTrace();
		} catch (JsonMappingException e) {
			LOGGER.error("Exception occured in convertJsonToObject for : "+json);
			e.printStackTrace();
		} catch (IOException e) {
			LOGGER.error("Exception occured in convertJsonToObject for : "+json);
			e.printStackTrace();
		}
		return object;
	}
}
