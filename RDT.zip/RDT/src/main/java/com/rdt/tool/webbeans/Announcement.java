package com.rdt.tool.webbeans;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Announcement implements Serializable{
	
	private String loggedInUser;
	private String message;
	
	public String getLoggedInUser() {
		return loggedInUser;
	}
	public void setLoggedInUser(String loggedInUser) {
		this.loggedInUser = loggedInUser;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
