package com.rdt.tool.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.rdt.tool.service.CommonServices;
import com.rdt.tool.util.CONFIGURATION;
import com.rdt.tool.util.CONFIGURATION.CONFIGURATION_KEYS;
import com.rdt.tool.util.Constants;

@Controller
public class FileUploadController {
	
	private final static Logger LOGGER =Logger.getLogger(FileUploadController.class);
	
	@Autowired
	private CommonServices commonServices;
	
	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
	public @ResponseBody String uploadFileHandler(@RequestParam("file") MultipartFile file, HttpSession session) {
		String fileName="";
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				fileName=file.getOriginalFilename();
				String rootPath = CONFIGURATION.getValue(CONFIGURATION_KEYS.FILE_UPLOAD_ROOTPATH.getValue());
				File dir = new File(rootPath + File.separator);
				if (!dir.exists()){
					dir.mkdirs();
				}
				if(null!=fileName && fileName.contains(Constants.dot)) {
					String[] fileNameArr=fileName.split(Constants.dotSeperator);
					fileName=fileNameArr[0]+String.valueOf(System.currentTimeMillis())+Constants.dot+fileNameArr[1];
				}else {
					fileName=fileName+String.valueOf(System.currentTimeMillis());
				}
				File serverFile = new File(dir.getAbsolutePath()+ File.separator+fileName);
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				LOGGER.info("File uploaded!! Location="+ serverFile.getAbsolutePath());
			} catch (Exception e) {
				LOGGER.info("File upload Exception: "+ e.getMessage());
			}
		} else {
			LOGGER.info("File upload problem!! Empty file received");
		}
		return fileName;
	}
	
	@RequestMapping(value = "/downloadattachement", method = RequestMethod.GET)
	public void downloadattachement(HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		try
		{
			String fileName = request.getParameter("fileName");
			if (fileName == null || fileName.equals("")) {
				showAlert("File Name can't be null or empty", response);
				LOGGER.warn("File Name can't be null or empty");
				return;
			}
			String rootPath = CONFIGURATION.getValue(CONFIGURATION_KEYS.FILE_UPLOAD_ROOTPATH.getValue());
			File dir = new File(rootPath + File.separator);
			if (!dir.exists()){
				dir.mkdirs();
			}
			File serverFile = new File(dir.getAbsolutePath()+ File.separator + fileName);
			if (!serverFile.exists()) {
				showAlert("File doesn't exists on server", response);
				LOGGER.warn("File doesn't exists on server "+serverFile.getPath());
				return;
			}
			InputStream fis = new FileInputStream(serverFile);
			response.setContentType("application/octet-stream");
			response.setContentLength((int) serverFile.length());
			response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
			ServletOutputStream os = response.getOutputStream();
			byte[] bufferData = new byte[1024];
			int read = 0;
			while ((read = fis.read(bufferData)) != -1) {
				os.write(bufferData, 0, read);
			}
			os.flush();
			os.close();
			fis.close();
			LOGGER.debug("File downloaded- "+fileName);
		} catch (Exception e) {
			showAlert("Error occured durring file download", response);
			return;
		}
	}
	
	@RequestMapping(value = "/export", method = RequestMethod.GET)
	public void export(HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		try
        {
			String requestType=request.getParameter("requestType");
			response.setContentType("application/vnd.ms-excel");
			long currentdate=Calendar.getInstance().getTimeInMillis();
		    String fileName="DEFECTS_TIMESTAMP_"+currentdate+".xls";
            response.setHeader("Content-Disposition", "attachment; filename="+fileName+" ");
	        HSSFWorkbook hwb = new HSSFWorkbook();
	        HSSFSheet sheet=commonServices.getEXCELData(hwb,requestType);
            if(null==sheet){
            	showAlert("No records found for Export", response);
                return;
            }
            ServletOutputStream outputStream = response.getOutputStream();
            sheet.getWorkbook().write(outputStream);
            outputStream.flush();
        }catch(Exception e) {
        	showAlert("Error occured durring Export", response);
        	return;
       }
		
	}
	
	public void showAlert(String message,HttpServletResponse response){
		response.reset();
    	response.setContentType("text/html");
        PrintWriter out = null;
		try {
			out = response.getWriter();
			 out.println("<html><body><script type=\"text/javascript\">");
		        out.println("alert('"+message+"');");
		        out.println("</script></body></html>");
		} catch (IOException e) {
			
		}
	}
}