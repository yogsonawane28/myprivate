package com.rdt.tool.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rdt.tool.backoffice.EventsStorage;
import com.rdt.tool.domains.ChangeLog;
import com.rdt.tool.domains.Configurations;
import com.rdt.tool.domains.DefectDetails;
import com.rdt.tool.domains.Deployment;
import com.rdt.tool.domains.EventDetails;
import com.rdt.tool.domains.Messages;
import com.rdt.tool.domains.UserDetails;
import com.rdt.tool.service.CommonServices;
import com.rdt.tool.util.AdminStorage;
import com.rdt.tool.util.CONFIGURATION;
import com.rdt.tool.util.CONFIGURATION.CONFIGURATION_KEYS;
import com.rdt.tool.util.Constants;
import com.rdt.tool.util.Util;
import com.rdt.tool.webbeans.Announcement;
import com.rdt.tool.webbeans.ChangeLogFilter;
import com.rdt.tool.webbeans.Defect;
import com.rdt.tool.webbeans.DeploymentDetails;
import com.rdt.tool.webbeans.Event;
import com.rdt.tool.webbeans.GenericSearchFilter;

@Controller
public class CommonController {
	
	private final static Logger LOGGER = Logger.getLogger(CommonController.class);
	
	@Autowired
	private CommonServices commonServices;
	
	@RequestMapping(value = "/getEditDefectDetails", method = RequestMethod.GET)
	public @ResponseBody
	Defect getEditDefectDetails(@RequestParam String defectId, HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		return commonServices.getDefectDetails(defectId);
	}

	@RequestMapping(value = "/getDeploymentDetails", method = RequestMethod.GET)
	public @ResponseBody
	List<Deployment> getDeploymentDetails(HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		return commonServices.getAllDeploymentDetails();
	}
	
	@RequestMapping(value = "/getAllEventDetails", method = RequestMethod.GET)
	public @ResponseBody
	List<EventDetails> getAllEventDetails(@RequestParam String eventId,@RequestParam String user,HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		return commonServices.getAllEventDetails(eventId,user);
	}
	
	@RequestMapping(value = "/getMessages", method = RequestMethod.GET)
	public @ResponseBody
	List<Messages> getMessages(HttpServletResponse response, HttpSession session,HttpServletRequest request) {
		return commonServices.getAllMessages();
	}
	
	@RequestMapping(value = "/getDefectDetails", method = RequestMethod.GET)
	public @ResponseBody
	List<DefectDetails> getDefectDetails(@RequestParam String viewName,HttpServletResponse response, HttpSession session,HttpServletRequest request) {
		return commonServices.getDefectData(viewName);
	}
	
	@RequestMapping(value = "/getAllDefectCounts", method = RequestMethod.GET)
	public @ResponseBody
	Map<String,String> getAllDefectCounts(HttpServletResponse response, HttpSession session,HttpServletRequest request) {
		return commonServices.getAllDefectCounts();
	}

	@RequestMapping(value = "/submitDeployment", method = RequestMethod.GET)
	public @ResponseBody
	String submitDeployment(@RequestParam String json, HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		List<DeploymentDetails> deploymentDetails=null;
		try {
			deploymentDetails = new ObjectMapper().readValue(json, new TypeReference<List<DeploymentDetails>>(){});
		} catch (JsonParseException e) {
			LOGGER.error("JsonParseException in submitDeployment");
			e.printStackTrace();
		} catch (JsonMappingException e) {
			LOGGER.error("JsonMappingException in submitDeployment");
			e.printStackTrace();
		} catch (IOException e) {
			LOGGER.error("IOException in submitDeployment");
			e.printStackTrace();
		}
		return commonServices.submitDeployment(deploymentDetails);
	}

	@RequestMapping(value = "/submitDefect", method = RequestMethod.GET)
	public @ResponseBody
	String submitDefect(@RequestParam String jsonString, HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		Defect defect = (Defect) Util.convertJsonToObject(jsonString, Defect.class);
		return commonServices.submitDefect(defect);
	}
	
	@RequestMapping(value = "/submitEvent", method = RequestMethod.GET)
	public @ResponseBody
	String submitEvent(@RequestParam String jsonString, HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		Event event = (Event) Util.convertJsonToObject(jsonString, Event.class);
		return commonServices.submitEvent(event);
	}
	
	@RequestMapping(value = "/submitUserDetails", method = RequestMethod.GET)
	public @ResponseBody
	String submitUserDetails(@RequestParam String jsonString, HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		return commonServices.submitUserDetails(jsonString);
	}
	
	@RequestMapping(value = "/contextMenuAction", method = RequestMethod.GET)
	public @ResponseBody
	String contextMenuAction(@RequestParam String jsonString, HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		String message="";
		if(null!=jsonString){
			String [] idAction=jsonString.split(Constants.separator);
			message=commonServices.updateContextMenuAction(idAction[0], idAction[1], idAction[2]);
		}
		return message;
	}
	
	@RequestMapping(value = "/submitChat", method = RequestMethod.GET)
	public @ResponseBody
	void submitChat(@RequestParam String json, HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		Announcement announcement = (Announcement) Util.convertJsonToObject(json, Announcement.class);
		commonServices.submitChat(announcement);
	}
	
	@RequestMapping(value = "/getUpdateStatus", method = RequestMethod.GET)
	public @ResponseBody
	String getUpdateStatus(HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		return (commonServices.getUpdateStatus(session)).toString();
	}
	

	@RequestMapping(value = "/poll", method = RequestMethod.GET)
	public @ResponseBody
	ChangeLog poll(HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		return EventsStorage.pollToServer(session.getId());
	}
	
	@RequestMapping(value = "/getGenericSearch", method = RequestMethod.GET)
	public @ResponseBody
	String getGenericSearch(@RequestParam String json ,
			HttpServletResponse response, HttpSession session, HttpServletRequest request) {
		GenericSearchFilter genericSearchFilter = (GenericSearchFilter) Util.convertJsonToObject(json, GenericSearchFilter.class);
		return commonServices.getGenericSearch(genericSearchFilter);
	}
	
	@RequestMapping(value = "/getChangeLogs", method = RequestMethod.GET)
	public @ResponseBody
	List<ChangeLog> getChangeLogs(@RequestParam String json,HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		ChangeLogFilter changeLogFilter = (ChangeLogFilter) Util.convertJsonToObject(json, ChangeLogFilter.class);	
		return commonServices.getChangeLogs(changeLogFilter);
	}
	@RequestMapping(value = "/getConfigurationDetails", method = RequestMethod.GET)
	public @ResponseBody
	List<Configurations> getConfigurationDetails(HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		return commonServices.getConfigurationDetails();
	}
	
	@RequestMapping(value = "/updateConfigurationDetails", method = RequestMethod.GET)
	public @ResponseBody
	String updateConfigurationDetails(@RequestParam String json, HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		List<Configurations> configurations=null;
		try {
			configurations = new ObjectMapper().readValue(json, new TypeReference<List<Configurations>>(){});
		} catch (JsonParseException e) {
			LOGGER.error("JsonParseException in updateConfigurationDetails");
			e.printStackTrace();
		} catch (JsonMappingException e) {
			LOGGER.error("JsonMappingException in updateConfigurationDetails");
			e.printStackTrace();
		} catch (IOException e) {
			LOGGER.error("IOException in updateConfigurationDetails");
			e.printStackTrace();
		}
		return commonServices.updateConfigurationDetails(configurations);
	}
	
	@RequestMapping(value = "/restartRDT", method = RequestMethod.GET)
	public @ResponseBody
	String restartRDT(@RequestParam String userName, HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		String message= "";
		LOGGER.info("Server restart command is received from user: "+userName);
		UserDetails userDetails = commonServices.getUserByName(userName);
		if(!userDetails.getOptionAccess().contains(AdminStorage.ADMINISTRATION)) {
			LOGGER.warn("****** "+userName+ " trying to access unauthorized functionality (Restart RDT) ******");
			message=Constants.ERROR+Constants.hashseparator+Constants.noAccess;
		}else {
			String scriptName=CONFIGURATION.getValue(CONFIGURATION_KEYS.RDT_RESTART_SCRIPT_NAME.getValue());
			LOGGER.info("Running script: "+scriptName);
			ProcessBuilder pb = new ProcessBuilder(System.getProperty("user.dir")+"/"+scriptName, "myArg1", "myArg2");
			try {
				pb.start();
				message = Constants.serverRestartSuccess;
			} catch (IOException e) {
				message=Constants.ERROR+Constants.hashseparator+Constants.error;
				LOGGER.error("IOException in restartRDT");
				e.printStackTrace();
			}
		}
		return message;
	}
	
	@RequestMapping(value = "/moveDefectsToArchive", method = RequestMethod.GET)
	public @ResponseBody
	String moveDefectsToArchive(@RequestParam String userName, HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		return commonServices.moveDefectsToArchive(userName);
	}
	
	
}
