package com.rdt.tool.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rdt.tool.dao.CommonDao;
import com.rdt.tool.domains.UserDetails;
import com.rdt.tool.service.CommonServices;
import com.rdt.tool.util.Constants;

@Controller
public class BaseController {
	
	private final static Logger LOGGER =Logger.getLogger(BaseController.class);
	
	@Autowired
	private CommonServices commonServices;
	@Autowired
	private CommonDao commonDao;

	@RequestMapping(value = "/login")
	public String login(HashMap<String, Object> map, HttpSession session,HttpServletRequest request,
			HttpServletResponse response) {
		
		String computerName = this.getClientIdentification(request);
		UserDetails userDetails=commonDao.getUserDetails(computerName);
		if(null!=userDetails) {
			map.put(Constants.username,userDetails.getUserName());
			map.put(Constants.role,userDetails.getRole());
		}
		return "login";
	}
	
	@RequestMapping(value = "/")
	public String welcome(HashMap<String, Object> map, HttpSession session,HttpServletRequest request,
			HttpServletResponse response) throws UnknownHostException {
		
		String sessionId = session.getId();
		commonServices.loadConfigurations();
		commonServices.setSystemProperties(map);
		
		String computerName = this.getClientIdentification(request);
		
		commonServices.buildServerCache(map, sessionId,computerName);
		if(null!=map.get(Constants.username)){
			LOGGER.debug("Ping--> User:"+map.get(Constants.username)+" | Computer:"+computerName+"---");
		}else{
			LOGGER.warn("System unable to find the details for Computer:"+computerName+"---");
		}
		return Constants.indexpage;
	}
	
	@RequestMapping(value = "/calendar")
	public String calendar(HashMap<String, Object> map, HttpSession session,HttpServletRequest request,
			HttpServletResponse response) {
		commonServices.loadConfigurations();
		commonServices.setSystemProperties(map);
		String computerName = this.getClientIdentification(request);
		commonServices.buildServerCache(map, session.getId(),computerName);
		if(null!=map.get(Constants.username)){
			LOGGER.debug("Ping--> User:"+map.get(Constants.username)+" | Computer:"+computerName+"---");
		}else{
			LOGGER.warn("System unable to find the details for Computer:"+computerName+"---");
		}
		return Constants.calendar;
	}
	
	@RequestMapping(value = "/getUserDetails", method = RequestMethod.GET)
	public @ResponseBody
	String getUserDetails(@RequestParam String userName,
			HttpServletResponse response, HttpSession session,
			HttpServletRequest request) {
		UserDetails userDetails = commonServices.getUserByName(userName);
		String jsonString="";
		if(null!=userDetails) {
			String computerName=getClientIdentification(request);
			jsonString=userDetails.getUserName()+Constants.separator+computerName;
			LOGGER.info("Auto login executor started for User: "+userDetails.getUserName()+"| Computer: "+computerName);
		} 
		return jsonString;
	}


	 private String getClientIdentification(HttpServletRequest request) {
		 	String computerName = "";
			String remoteAddress = request.getRemoteHost();
			InetAddress inetAddress = null;
			try {
				inetAddress = InetAddress.getByName(remoteAddress);
			} catch (UnknownHostException e) {
				LOGGER.error("Exception in get inetAddress: " + e.getMessage());
			}
			computerName = inetAddress.getHostName();
			if (null!=computerName && computerName.equalsIgnoreCase("localhost")) {
				try {
					computerName = java.net.InetAddress.getLocalHost().getCanonicalHostName();
				} catch (UnknownHostException e) {
					LOGGER.error("Exception in get CanonicalHostName: "+ e.getMessage());
				}
			}
			if(null!=computerName && computerName.toLowerCase().contains("india")) {
				computerName=computerName.split(".India")[0];
			}
			return computerName;
	}

}