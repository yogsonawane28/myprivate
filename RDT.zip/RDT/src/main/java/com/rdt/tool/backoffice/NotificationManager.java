package com.rdt.tool.backoffice;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.rdt.tool.dao.impl.CommonDaoImpl;
import com.rdt.tool.domains.ChangeLog;
import com.rdt.tool.domains.DefectDetails;
import com.rdt.tool.domains.Deployment;
import com.rdt.tool.domains.EventDetails;
import com.rdt.tool.domains.Messages;
import com.rdt.tool.util.CONFIGURATION;
import com.rdt.tool.util.CONFIGURATION.CONFIGURATION_KEYS;
import com.rdt.tool.util.Constants;

@Service
public class NotificationManager extends Thread{
	
	private static final Logger LOGGER = Logger.getLogger(NotificationManager.class);
	private CommonDaoImpl  daoImpl=new CommonDaoImpl();
	
	private DefectDetails defectDetails;
	private DefectDetails prevDefectDetails;
	private List<Deployment> deployments;
	private Messages messages;
	private EventDetails eventDetails;
	private String ANNOUNCEMENT="Announcement";
	private String DEFECT_ENTER="Defect Enter";
	private String DEFECT_UPDATE="Defect Update";
	private String SYSTEM_UPDATE="System Update";
	private String DEPLOYMENT_UPDATE="Deployment Update";
	private String REFRESH="Refresh";
	private String CALENDAR="Calendar";
	
	public enum DATA_UPDATE_TYPES {
		DEPLOYMENT_UPDATE("DEPLOYMENT_UPDATE"),
		ANNOUNCEMENT_ADD("ANNOUNCEMENT_ADD"),
		DEFECT_UPDATE("DEFECT_UPDATE"),
		DEFECT_ENTER("DEFECT_ENTER"),
		CALENDAR("CALENDAR"),
		REFRESH("REFRESH");
		
		private String type;
		
		DATA_UPDATE_TYPES(String type) {
			this.type=type;
		}
		public String getType() {
			return type;
		}
		
	}
	
	public NotificationManager(DefectDetails defectDetails,
			DefectDetails prevDefectDetails,List<Deployment> deployments,Messages messages,EventDetails eventDetails) {
		super();
		this.defectDetails = defectDetails;
		this.prevDefectDetails = prevDefectDetails;
		this.deployments = deployments;
		this.messages = messages;
		this.eventDetails = eventDetails;
	}
	
	public NotificationManager() {
		super();
	}

	public void sendToBroadcast(DefectDetails defectDetails, DefectDetails prevDefectDetails, 
			List<Deployment> deployments,Messages messages,EventDetails eventDetails){
			final String auditManagerFlag=CONFIGURATION.getValue(CONFIGURATION_KEYS.BROADCAST_MANAGER_FLAG.getValue());
			if(null!=auditManagerFlag && auditManagerFlag.equalsIgnoreCase("true")){
				NotificationManager broadcastManager=new  NotificationManager(defectDetails,prevDefectDetails,deployments,messages,eventDetails);
				broadcastManager.setName("Broadcast Manager");
				broadcastManager.setPriority(MAX_PRIORITY);
				broadcastManager.start();
			}else{
				LOGGER.info("Broadcast Event Logging is Off");
			}
	}

	@Override
	public void run() {
			ChangeLog changeLog=this.generateEventMessage();
			EventsStorage.auditEvent(changeLog);
	}
	
	private ChangeLog generateEventMessage(){
			ChangeLog changeLog=null;
			if(null!=this.defectDetails && null!=this.defectDetails.getLastUpdatedBy()
					&& this.defectDetails.getLastUpdatedBy().equalsIgnoreCase("System Auto Assigner")){
				changeLog=this.getSyatemDefectUpdateEventMessage();
				changeLog.setDataUpdateType(DATA_UPDATE_TYPES.DEFECT_UPDATE.getType());
				changeLog.setDefectDetails(defectDetails);
			}else if(null!=this.prevDefectDetails && null!=this.defectDetails){
				changeLog=this.getDefectUpdateEventMessage();
				changeLog.setOldDefectStatus(this.prevDefectDetails.getStatus());
				changeLog.setDataUpdateType(DATA_UPDATE_TYPES.DEFECT_UPDATE.getType());
				changeLog.setDefectDetails(defectDetails);
			}else if(null!=this.defectDetails){
				changeLog=this.getDefectEnterEventMessage();
				changeLog.setDataUpdateType(DATA_UPDATE_TYPES.DEFECT_ENTER.getType());
				changeLog.setDefectDetails(defectDetails);
			}else if(null!=this.deployments){
				changeLog=this.getDeploymentUpdateEventMessage();
				changeLog.setDataUpdateType(DATA_UPDATE_TYPES.DEPLOYMENT_UPDATE.getType());
				changeLog.setDeploymentDetails(deployments);
			}else if(null!=this.messages){
				changeLog=this.getAnnouncementEventMessage();
				changeLog.setDataUpdateType(DATA_UPDATE_TYPES.ANNOUNCEMENT_ADD.getType());
				changeLog.setMessages(messages);
			}else if(null!=this.eventDetails) {
				changeLog=this.getCalendarEventMessage();
				changeLog.setDataUpdateType(DATA_UPDATE_TYPES.CALENDAR.getType());
				changeLog.setEventDetails(eventDetails);
			}else {
				changeLog=this.getRefreshEventMessage();
				changeLog.setDataUpdateType(DATA_UPDATE_TYPES.REFRESH.getType());
				changeLog.setMessages(messages);
			}
			if(null!=changeLog) {
				daoImpl.submitChangeLog(changeLog);
			}
			
		return changeLog;
	}
	
	private synchronized ChangeLog getSyatemDefectUpdateEventMessage(){
		StringBuffer eventBuffer =new StringBuffer();
		ChangeLog changeLog=new ChangeLog();
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.dateformatter);
		String time = dateFormat.format(new Date());
		eventBuffer.append(time).append(" : ");	
		eventBuffer.append(this.defectDetails.getLastUpdatedBy()).append(" assigned the Defect ");
		eventBuffer.append("(Defect Id: ");
		eventBuffer.append(this.defectDetails.getDefectId()).append(" Module Name: ").append(this.defectDetails.getModuleName()).append(")");
		eventBuffer.append(" to ").append(this.defectDetails.getAssignedTo());
		
		changeLog.setEventType(SYSTEM_UPDATE);
		changeLog.setCreationDate(new Date());
		changeLog.setActingUser(this.defectDetails.getLastUpdatedBy());
		changeLog.setDefectId(String.valueOf(this.defectDetails.getDefectId()));
		changeLog.setActivity(eventBuffer.toString());
		return changeLog;
	}
	
	private synchronized ChangeLog getDeploymentUpdateEventMessage(){
			StringBuffer eventBuffer =new StringBuffer();
			ChangeLog changeLog=new ChangeLog();
			SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.dateformatter);
			String time = dateFormat.format(new Date());
			eventBuffer.append(time).append(" : ");	
			Deployment deployment=this.deployments.get(0);
			eventBuffer.append(deployment.getUserName()).append(" updated the Deployment Details at ");
			eventBuffer.append(deployment.getDeploymentTime());
			
			changeLog.setEventType(DEPLOYMENT_UPDATE);
			changeLog.setCreationDate(new Date());
			changeLog.setActingUser(deployment.getUserName());
			changeLog.setDefectId("");
			changeLog.setActivity(eventBuffer.toString());
			return changeLog;
	}
	
	private synchronized ChangeLog getDefectEnterEventMessage(){
		StringBuffer eventBuffer =new StringBuffer();
		ChangeLog changeLog=new ChangeLog();
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.dateformatter);
		String time = dateFormat.format(new Date());
		eventBuffer.append(time).append(" : ");	
		String submitter=this.defectDetails.getLastUpdatedBy().split("\\(")[0];
		eventBuffer.append(submitter);
		eventBuffer.append(" entered the Defect");
		if(!this.defectDetails.getReportedBy().equals(submitter)) {
			eventBuffer.append(", set the reported by to ").append(this.defectDetails.getReportedBy());
		}
		eventBuffer.append(" (Defect Id: ");
		eventBuffer.append(this.defectDetails.getDefectId()).append(" Module Name: ").append(this.defectDetails.getModuleName()).append(")");
		
		changeLog.setEventType(DEFECT_ENTER);
		changeLog.setCreationDate(new Date());
		changeLog.setActingUser(submitter);
		changeLog.setDefectId(String.valueOf(this.defectDetails.getDefectId()));
		changeLog.setActivity(eventBuffer.toString());
		return changeLog;
	}
	
	private synchronized ChangeLog getAnnouncementEventMessage(){
		StringBuffer eventBuffer =new StringBuffer();
		ChangeLog changeLog=new ChangeLog();
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.dateformatter);
		String time = dateFormat.format(new Date());
		eventBuffer.append(time).append(" : ");	
		eventBuffer.append(this.messages.getUserName()).append(" sent an announcement. Please check the Announcements section.");
	
		changeLog.setEventType(ANNOUNCEMENT);
		changeLog.setCreationDate(new Date());
		changeLog.setActingUser(this.messages.getUserName());
		changeLog.setDefectId("");
		changeLog.setActivity(eventBuffer.toString());
		return changeLog;
	}
	
	private synchronized ChangeLog getCalendarEventMessage(){
		StringBuffer eventBuffer =new StringBuffer();
		ChangeLog changeLog=new ChangeLog();
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.dateformatter);
		String time = dateFormat.format(new Date());
		eventBuffer.append(time).append(" : ");	
		eventBuffer.append(this.eventDetails.getEventCreator()).append(" updated the Calendar ");
		eventBuffer.append("(Event: ").append(eventDetails.getEvent()).append(" - ").append(eventDetails.getEventName())
		.append(" - ").append(eventDetails.getEventStartDate());
		if(!StringUtils.isEmpty(eventDetails.getEventEndDate())){
			eventBuffer.append(" to ").append(eventDetails.getEventEndDate());
		}
		eventBuffer.append(")");
		changeLog.setEventType(CALENDAR);
		changeLog.setCreationDate(new Date());
		changeLog.setActingUser(this.eventDetails.getEventCreator());
		changeLog.setDefectId("");
		changeLog.setActivity(eventBuffer.toString());
		return changeLog;
	}
	
	private synchronized ChangeLog getRefreshEventMessage(){
		StringBuffer eventBuffer =new StringBuffer();
		ChangeLog changeLog=new ChangeLog();
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.dateformatter);
		String time = dateFormat.format(new Date());
		eventBuffer.append(time).append(" : ");
		eventBuffer.append("Administrator updated the configuration parameters.");
	
		changeLog.setEventType(REFRESH);
		changeLog.setCreationDate(new Date());
		changeLog.setActingUser("Administrator");
		changeLog.setDefectId("");
		changeLog.setActivity(eventBuffer.toString());
		return changeLog;
	}
	
	
	private synchronized ChangeLog getDefectUpdateEventMessage(){
		StringBuffer eventBuffer =new StringBuffer();
		ChangeLog changeLog=new ChangeLog();
		String defaultMessage="";
		final String currentDelivery=CONFIGURATION.getValue(CONFIGURATION_KEYS.TAB_NAME_1.getValue());
		final String futureDelivery=CONFIGURATION.getValue(CONFIGURATION_KEYS.TAB_NAME_2.getValue());
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.dateformatter);
		String time = dateFormat.format(new Date());
		eventBuffer.append(time).append(" : ");	
		eventBuffer.append(this.defectDetails.getLastUpdatedBy().split("\\(")[0]);
		if(null==this.prevDefectDetails.getDeleted() && !StringUtils.isEmpty(this.defectDetails.getDeleted()) &&
				!this.defectDetails.getDeleted().equals("YES")){
			eventBuffer.append(" archived the defect ");
		}else if(null==this.prevDefectDetails.getIsDeliverableNow() && null!=this.defectDetails.getIsDeliverableNow()){
			eventBuffer.append(" moved the defect to ");
			eventBuffer.append(currentDelivery+" ");
		} else if(null!=this.prevDefectDetails.getIsDeliverableNow() && null==this.defectDetails.getIsDeliverableNow()){
			eventBuffer.append(" removed the defect from ");
			eventBuffer.append(currentDelivery+" ");
		}  else if(null==this.prevDefectDetails.getIsDeliverableInFuture() && null!=this.defectDetails.getIsDeliverableInFuture()){
			eventBuffer.append(" moved the defect to ");
			eventBuffer.append(futureDelivery+" ");
		} else if(null!=this.prevDefectDetails.getIsDeliverableInFuture() && null==this.defectDetails.getIsDeliverableInFuture()){
			eventBuffer.append(" removed the defect from ");
			eventBuffer.append(futureDelivery+" ");
		} else if((null!=this.prevDefectDetails.getIsDeliverableNow() || null!=this.prevDefectDetails.getIsDeliverableInFuture() ||
				null!=this.prevDefectDetails.getIsDeliverableForFirst() || null!=this.prevDefectDetails.getIsDeliverableForSecond()) &&
				(null==this.defectDetails.getIsDeliverableNow() && null==this.defectDetails.getIsDeliverableInFuture() &&
				null==this.defectDetails.getIsDeliverableForFirst() && null==this.defectDetails.getIsDeliverableForSecond())){
			eventBuffer.append(" moved the defect to ");
			eventBuffer.append("OPEN ");
		} else if(StringUtils.isEmpty(this.prevDefectDetails.getDeleted()) && !StringUtils.isEmpty(this.defectDetails.getDeleted())){
			eventBuffer.append(" completely deleted the defect from the System ");
		} else if(StringUtils.isEmpty(this.prevDefectDetails.getIsOnHold()) && !StringUtils.isEmpty(this.defectDetails.getIsOnHold())) {
			eventBuffer.append(" kept the defect on Hold ");
		} else if(!StringUtils.isEmpty(this.prevDefectDetails.getIsOnHold()) && StringUtils.isEmpty(this.defectDetails.getIsOnHold())) {
					eventBuffer.append(" unhold the defect ");
		} else{
			defaultMessage=eventBuffer.toString();
			if(!this.prevDefectDetails.getModuleName().equals(this.defectDetails.getModuleName())){
				eventBuffer.append(" updated the module name to ").append(this.defectDetails.getModuleName()).append(" from ").append(this.prevDefectDetails.getModuleName()).append(", ");
			}
			if(!this.prevDefectDetails.getDefectDesc().equals(this.defectDetails.getDefectDesc())){
				eventBuffer.append(" updated the defect description ").append(", ");
			}
			if(!this.prevDefectDetails.getPriority().equals(this.defectDetails.getPriority())){
				eventBuffer.append(" set the priority to ").append(this.defectDetails.getPriority()).append(" from ").append(this.prevDefectDetails.getPriority()).append(", ");
			}
			if(!this.prevDefectDetails.getSeverity().equals(this.defectDetails.getSeverity())){
				eventBuffer.append(" set the severity to ").append(this.defectDetails.getSeverity()).append(" from ").append(this.prevDefectDetails.getSeverity()).append(", ");
			}
			if((StringUtils.isEmpty(this.prevDefectDetails.getAssignedTo()) && !StringUtils.isEmpty(this.defectDetails.getAssignedTo())) ||
					(!StringUtils.isEmpty(this.defectDetails.getAssignedTo()) && !this.prevDefectDetails.getAssignedTo().equals(this.defectDetails.getAssignedTo()))){
				eventBuffer.append(" assigned the defect to ").append(this.defectDetails.getAssignedTo());
				if(!StringUtils.isEmpty(this.prevDefectDetails.getAssignedTo())){
					eventBuffer.append(" from ").append(this.prevDefectDetails.getAssignedTo());
				}
				eventBuffer.append(",");
			}
			if(!this.prevDefectDetails.getReportedBy().equals(this.defectDetails.getReportedBy())){
				eventBuffer.append(" changed the reported by to ").append(this.defectDetails.getReportedBy()).append(" from ").append(this.prevDefectDetails.getReportedBy()).append(", ");
			}
			if(StringUtils.isEmpty(this.prevDefectDetails.getReviewer()) && !StringUtils.isEmpty(this.defectDetails.getReviewer())){
				eventBuffer.append(" set the reviewer to ").append(this.defectDetails.getReviewer()).append(", ");
			}
			if(!StringUtils.isEmpty(this.prevDefectDetails.getReviewer()) && !StringUtils.isEmpty(this.defectDetails.getReviewer()) &&
					!this.prevDefectDetails.getReviewer().equals(this.defectDetails.getReviewer())){
				eventBuffer.append(" changed the reviewer to ").append(this.defectDetails.getReviewer()).append(", ");
			}
			if(!this.prevDefectDetails.getStatus().equals(this.defectDetails.getStatus())){
				eventBuffer.append(" set the status to ").append(this.defectDetails.getStatus()).append(" from ").append(this.prevDefectDetails.getStatus()).append(", ");
			}
			if((StringUtils.isEmpty(this.prevDefectDetails.getPded()) && !StringUtils.isEmpty(this.defectDetails.getPded())) ||
					(!StringUtils.isEmpty(this.defectDetails.getPded()) && !this.prevDefectDetails.getPded().equals(this.defectDetails.getPded()))){
				eventBuffer.append(" set the development end date to ").append(this.defectDetails.getPded());
				if(!StringUtils.isEmpty(this.prevDefectDetails.getPted())){
					eventBuffer.append(" from ").append(this.prevDefectDetails.getPded()).append(", ");
				}
			}
			if((StringUtils.isEmpty(this.prevDefectDetails.getPted()) && !StringUtils.isEmpty(this.defectDetails.getPted())) ||
					(!StringUtils.isEmpty(this.defectDetails.getPted()) && !this.prevDefectDetails.getPted().equals(this.defectDetails.getPted()))){
				eventBuffer.append(" set the testing end date to ").append(this.defectDetails.getPted());
				if(!StringUtils.isEmpty(this.prevDefectDetails.getPted())){
					eventBuffer.append(" from ").append(this.prevDefectDetails.getPted()).append(", ");
				}
			}
			if(!this.prevDefectDetails.getIsClientDefect().equals(this.defectDetails.getIsClientDefect()) && this.defectDetails.getIsClientDefect().equals("YES")){
				eventBuffer.append(" marked the defect as client's defect ").append(", ");
			}else if(!this.prevDefectDetails.getIsClientDefect().equals(this.defectDetails.getIsClientDefect()) && this.defectDetails.getIsClientDefect().equals("NO")){
				eventBuffer.append(" removed the mark of client's defect").append(",");
			}
			if((StringUtils.isEmpty(this.prevDefectDetails.getComment()) && !StringUtils.isEmpty(this.defectDetails.getComment())) ||
					(!StringUtils.isEmpty(this.defectDetails.getComment()) && !this.prevDefectDetails.getComment().equals(this.defectDetails.getComment()))){
				eventBuffer.append(" updated the comment").append(",");
			}
			if((StringUtils.isEmpty(this.prevDefectDetails.getAnalysis()) && !StringUtils.isEmpty(this.defectDetails.getAnalysis())) ||
					(!StringUtils.isEmpty(this.defectDetails.getAnalysis()) && !this.prevDefectDetails.getAnalysis().equals(this.defectDetails.getAnalysis()))){
				eventBuffer.append(" updated the Root cause analysis").append(",");
			}
			if((StringUtils.isEmpty(this.prevDefectDetails.getRcaLocation()) && !StringUtils.isEmpty(this.defectDetails.getRcaLocation())) ||
					(!StringUtils.isEmpty(this.defectDetails.getRcaLocation()) && !this.prevDefectDetails.getRcaLocation().equals(this.defectDetails.getRcaLocation()))){
				eventBuffer.append(" updated the Test logs").append(",");
			}
			if((StringUtils.isEmpty(this.prevDefectDetails.getLinkedDefectId()) && !StringUtils.isEmpty(this.defectDetails.getLinkedDefectId())) ||
					(!StringUtils.isEmpty(this.defectDetails.getLinkedDefectId()) && !this.prevDefectDetails.getLinkedDefectId().equals(this.defectDetails.getLinkedDefectId()))){
				eventBuffer.append(" updated the Linked defect id ");
			}
		}
		if(eventBuffer.toString().equals(defaultMessage)) {
			eventBuffer.append(" updated the defect information ");
		}
		eventBuffer.append("(Defect Id: ");
		eventBuffer.append(this.defectDetails.getDefectId()).append(" Module Name: ").append(this.defectDetails.getModuleName()).append(")");
		
		changeLog.setEventType(DEFECT_UPDATE);
		changeLog.setCreationDate(new Date());
		changeLog.setActingUser(this.defectDetails.getLastUpdatedBy().split("\\(")[0]);
		changeLog.setDefectId(String.valueOf(this.defectDetails.getDefectId()));
		changeLog.setActivity(eventBuffer.toString());
		return changeLog;
	}
}
