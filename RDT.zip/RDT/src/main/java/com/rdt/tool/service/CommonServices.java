package com.rdt.tool.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.rdt.tool.domains.ChangeLog;
import com.rdt.tool.domains.Configurations;
import com.rdt.tool.domains.DefectDetails;
import com.rdt.tool.domains.Deployment;
import com.rdt.tool.domains.EventDetails;
import com.rdt.tool.domains.Messages;
import com.rdt.tool.domains.UserDetails;
import com.rdt.tool.webbeans.Announcement;
import com.rdt.tool.webbeans.ChangeLogFilter;
import com.rdt.tool.webbeans.Defect;
import com.rdt.tool.webbeans.DeploymentDetails;
import com.rdt.tool.webbeans.Event;
import com.rdt.tool.webbeans.GenericSearchFilter;

public interface CommonServices {
	Defect getDefectDetails(String defectId);
	String submitDefect(Defect defect);
	List<Deployment> getAllDeploymentDetails();
	HSSFSheet getEXCELData(HSSFWorkbook hwb, String requestType);
	List<DefectDetails> getDefectData(String requestType);
	List<Messages> getAllMessages();
	String updateContextMenuAction(String id, String action, String user);
	Boolean getUpdateStatus(HttpSession session);

	UserDetails getUserByName(String userName);
	String submitUserDetails(String json);
	void loadConfigurations();
	void setSystemProperties(HashMap<String, Object> map);
	List<ChangeLog> getChangeLogs(ChangeLogFilter changeLogFilter);
	String getGenericSearch(GenericSearchFilter genericSearchFilter);
	void submitChat(Announcement announcement);
	String submitDeployment(List<DeploymentDetails> deploymentDetails);
	Map<String, String> getAllDefectCounts();
	void buildServerCache(HashMap<String, Object> map, String sessionId,
			String hostName);
	List<Configurations> getConfigurationDetails();
	String updateConfigurationDetails(List<Configurations> configurations);
	String moveDefectsToArchive(String userName);
	String submitEvent(Event event);
	List<EventDetails> getAllEventDetails(String eventId, String userId);
}
