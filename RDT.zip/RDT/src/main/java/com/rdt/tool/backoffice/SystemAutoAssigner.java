package com.rdt.tool.backoffice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.rdt.tool.dao.impl.CommonDaoImpl;
import com.rdt.tool.domains.DefectDetails;
import com.rdt.tool.util.CONFIGURATION;
import com.rdt.tool.util.Constants;
import com.rdt.tool.util.CONFIGURATION.CONFIGURATION_KEYS;

@Service
public class SystemAutoAssigner extends Thread{
	
	private static final Logger LOGGER = Logger.getLogger(SystemAutoAssigner.class);
	
	private CommonDaoImpl  daoImpl=new CommonDaoImpl();
	private NotificationManager broadcastManager=new NotificationManager();
	
	private DefectDetails defectDetails;
	
	public static final LinkedHashMap<String, String> modulesMap= new LinkedHashMap<String, String>();
	
	public SystemAutoAssigner() {
		super();
	}
	
	public SystemAutoAssigner(DefectDetails defectDetails) {
		super();
		this.defectDetails = defectDetails;
	}
	
	

	public void findAssignerMatch(DefectDetails defectDetails){

		final String autoassignerManagerFlag=CONFIGURATION.getValue(CONFIGURATION_KEYS.AUTOASSIGNER_MANAGER_FLAG.getValue());
		if(null!=autoassignerManagerFlag && autoassignerManagerFlag.equalsIgnoreCase("true")){
			SystemAutoAssigner systemAutoAssigner=new  SystemAutoAssigner(defectDetails);
			systemAutoAssigner.setName("Auto Assignment Manager");
			systemAutoAssigner.setPriority(MIN_PRIORITY);
			systemAutoAssigner.start();
		}else{
			LOGGER.info("Defect Auto Assignment is Off");
		}
	}


	@Override
	public void run() {
			String developerName=this.getBestMatchDevloper();
			if(!StringUtils.isEmpty(developerName)){
				this.defectDetails.setAssignedTo(developerName);
				this.defectDetails.setLastUpdatedBy("System Auto Assigner");
				this.defectDetails.setStatus(Constants.ASSIGNED);
				daoImpl.updateDefect(defectDetails);
				broadcastManager.sendToBroadcast(defectDetails, null, null, null,null);
			}
	}
	
	private String getBestMatchDevloper(){
			String freeDeveloper=null;
			List<String> devList=new ArrayList<String>();
			String moduleName=this.defectDetails.getModuleName();
			String DeveloperArr=modulesMap.get(moduleName);
			if(null!=DeveloperArr && !DeveloperArr.equals("")){
				String[] devArr=DeveloperArr.split(",");
				devList=Arrays.asList(devArr);
			}
			if(devList.size()>0){
				List<String> freeDevelopers=daoImpl.findMostFreeDeveloper(devList);
				if(null!=freeDevelopers && freeDevelopers.size()>0){
					for(String dev:devList){
						if(!freeDevelopers.contains(dev)){
							freeDeveloper=dev;
							break;
						}
					}
					if(null==freeDeveloper){
						freeDeveloper=freeDevelopers.get(0);
					}					
				}else{
					freeDeveloper=devList.get(0);
				}
			}
		return freeDeveloper;
	}

}
