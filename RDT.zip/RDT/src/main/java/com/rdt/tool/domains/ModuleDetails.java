package com.rdt.tool.domains;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "data.module_details")
public class ModuleDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "module_id")
	private long moduleId;

	@Column(name = "module_name")
	private String moduleName;

	@Column(name = "module_owner")
	private String moduleOwners;

	public long getModuleId() {
		return moduleId;
	}

	public void setModuleId(long moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getModuleOwners() {
		return moduleOwners;
	}

	public void setModuleOwners(String moduleOwners) {
		this.moduleOwners = moduleOwners;
	}
	
}
