package com.rdt.tool.domains;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "data.configurations")
public class Configurations {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "config_id")
	private long configId;
	
	@Column(name = "config_key")
	private String configKey;

	@Column(name = "config_value")
	private String configValue;
	
	@Transient
	private Object $$hashKey;
	
	public long getConfigId() {
		return configId;
	}

	public void setConfigId(long configId) {
		this.configId = configId;
	}

	public String getConfigKey() {
		return configKey;
	}

	public void setConfigKey(String configKey) {
		this.configKey = configKey;
	}

	public String getConfigValue() {
		return configValue;
	}

	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}

	public Object get$$hashKey() {
		return $$hashKey;
	}

	public void set$$hashKey(Object $$hashKey) {
		this.$$hashKey = $$hashKey;
	}
}
