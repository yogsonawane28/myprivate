package com.rdt.tool.webbeans;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ChangeLogFilter implements Serializable{
	
	private String defectId;
	private String actingUser;
	private String eventType;
	private String fromDate;
	private String toDate;
	public String getDefectId() {
		return defectId;
	}
	public void setDefectId(String defectId) {
		this.defectId = defectId;
	}
	public String getActingUser() {
		return actingUser;
	}
	public void setActingUser(String actingUser) {
		this.actingUser = actingUser;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

}
