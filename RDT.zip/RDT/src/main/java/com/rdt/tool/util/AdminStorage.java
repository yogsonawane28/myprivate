package com.rdt.tool.util;

import java.util.LinkedHashMap;

public class AdminStorage {

	 public static final LinkedHashMap<String, Long> scoreDetails;
	 public static String CAN_ENTER="CAN_ENTER";
	 public static String CAN_ASSIGN="CAN_ASSIGN";
	 public static String CAN_FIX="CAN_FIX";
	 public static String CAN_REOPEN="CAN_REOPEN";
	 public static String CAN_RTT="CAN_RTT";
	 public static String CAN_CLOSE="CAN_CLOSE";
	 public static String CAN_MOVE_TO_DELIVERY="CAN_MOVE_TO_DELIVERY";
	 public static String CAN_REMOVE_FROM_DELIVERY="CAN_REMOVE_FROM_DELIVERY";
	 public static String CAN_DELETE="CAN_DELETE";
	 public static String CAN_REJECT="CAN_REJECT";
	 public static String CAN_DEFERRED="CAN_DEFERRED";
	 public static String CAN_CHANGE_STATUS="CAN_CHANGE_STATUS";
	 public static String CAN_CHANGE_PRIORITY="CAN_CHANGE_PRIORITY";
	 public static String CAN_CHANGE_SEVERITY="CAN_CHANGE_SEVERITY";
	 public static String CAN_CHANGE_DED_TED="CAN_CHANGE_DED_TED";
	 public static String CAN_CHANGE_REPORTED_BY="CAN_CHANGE_REPORTED_BY";
	 public static String ADMINISTRATION="ADMINISTRATION";
	 static
	    {
			scoreDetails = new LinkedHashMap<String, Long>();
			scoreDetails.put(Constants.CRITICAL, 50L);
			scoreDetails.put(Constants.MAJOR, 40L);
			scoreDetails.put(Constants.MINOR, 10L);
			scoreDetails.put(Constants.ENHANCEMENT, 30L);
			
			scoreDetails.put(Constants.BLOCKER, 70L);
			scoreDetails.put(Constants.HIGH, 40L);
			scoreDetails.put(Constants.MEDIUM, 30L);
			scoreDetails.put(Constants.LOW, 30L);
			
			scoreDetails.put(Constants.CLIENT_DEFECT+Constants.CRITICAL, 75L);
			scoreDetails.put(Constants.CLIENT_DEFECT+Constants.MAJOR, 75L);
			scoreDetails.put(Constants.CLIENT_DEFECT+Constants.MINOR, 55L);
			scoreDetails.put(Constants.CLIENT_DEFECT+Constants.ENHANCEMENT, 65L);
			
			scoreDetails.put(Constants.CLIENT_DEFECT+Constants.BLOCKER, 75L);
			scoreDetails.put(Constants.CLIENT_DEFECT+Constants.HIGH, 75L);
			scoreDetails.put(Constants.CLIENT_DEFECT+Constants.MEDIUM, 65L);
			scoreDetails.put(Constants.CLIENT_DEFECT+Constants.LOW, 65L);
	    }
	 
}
