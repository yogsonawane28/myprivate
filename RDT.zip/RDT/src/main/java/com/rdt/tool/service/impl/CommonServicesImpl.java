package com.rdt.tool.service.impl;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.rdt.tool.backoffice.NotificationManager;
import com.rdt.tool.backoffice.SystemAutoAssigner;
import com.rdt.tool.dao.CommonDao;
import com.rdt.tool.domains.ChangeLog;
import com.rdt.tool.domains.Configurations;
import com.rdt.tool.domains.DefectDetails;
import com.rdt.tool.domains.Deployment;
import com.rdt.tool.domains.EventDetails;
import com.rdt.tool.domains.Messages;
import com.rdt.tool.domains.ModuleDetails;
import com.rdt.tool.domains.UserDetails;
import com.rdt.tool.service.CommonServices;
import com.rdt.tool.util.AdminStorage;
import com.rdt.tool.util.CONFIGURATION;
import com.rdt.tool.util.CONFIGURATION.CONFIGURATION_KEYS;
import com.rdt.tool.util.Constants;
import com.rdt.tool.util.ServerCacheStore;
import com.rdt.tool.webbeans.Announcement;
import com.rdt.tool.webbeans.ChangeLogFilter;
import com.rdt.tool.webbeans.Defect;
import com.rdt.tool.webbeans.DeploymentDetails;
import com.rdt.tool.webbeans.Event;
import com.rdt.tool.webbeans.GenericSearchFilter;

@Service
public class CommonServicesImpl implements CommonServices {
	
	private final static Logger LOGGER = Logger.getLogger(CommonServicesImpl.class);
	
	@Autowired
	private CommonDao commonDao;
	
	private NotificationManager broadcastManager=new NotificationManager();
	private SystemAutoAssigner systemAutoAssigner=new SystemAutoAssigner();

	public enum VIEW_NAME {
		ALL("ALL"),DELIVERY_NOW("DELIVERY_NOW"),DELIVERY_NEXT("DELIVERY_NEXT"),DELIVERY_FIRST("DELIVERY_FIRST"),DELIVERY_SECOND("DELIVERY_SECOND"),OPEN("OPEN"),
		REOPENED("REOPENED"),FIXED("FIXED"),RTT("RTT"),CLOSED("CLOSED"),REJECTED("REJECTED"),DEFERRED("DEFERRED"),UNASSIGNED("UNASSIGNED");
		
		private String viewName;
		
		private VIEW_NAME(String viewName) {
			this.viewName=viewName;
		}
		
		public String getViewName() {
			return viewName;
		}
	};
	@Override
	public List<Deployment> getAllDeploymentDetails() {
		List<Deployment> deploymentList = null;
		try {
			deploymentList = commonDao.getAllDeploymentDetails();
		} catch (Exception e) {
			LOGGER.error("Exception in getAllDeploymentDetails");
			e.printStackTrace();
		}
		return deploymentList;
	}
	
	@Override
	public List<EventDetails> getAllEventDetails(String eventId, String userId) {
		List<EventDetails> eventDetails = new ArrayList<EventDetails>();
		try {
			if(!StringUtils.isEmpty(eventId)) {
				EventDetails event = commonDao.getEventDetails(eventId);
				eventDetails.add(event);
			}else {
				eventDetails = commonDao.getAllEventDetails(userId);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in getAllEventDetails");
			e.printStackTrace();
		}
		return eventDetails;
	}
	
	@Override
	public List<Configurations> getConfigurationDetails() {
		List<Configurations> configurations = null;
		try {
			configurations = commonDao.getConfigurationDetails();
		} catch (Exception e) {
			LOGGER.error("Exception in getConfigurationDetails");
			e.printStackTrace();
		}
		return configurations;
	}
	
	@Override
	public List<Messages> getAllMessages() {
		List<Messages> messages = null;
		try {
			messages = commonDao.getAllMessages();
		} catch (Exception e) {
			LOGGER.error("Exception in getAllMessages");
			e.printStackTrace();
		}
		return messages;
	}

	@Override
	public Defect getDefectDetails(String defectId) {
		Defect defect=null;
		try {
			String module=null;
			if(null!=defectId && defectId.contains(Constants.separator)){
				String[] idModule=defectId.split(Constants.separator);
				defectId=idModule[0];
				module=idModule[1];
			}else if(null!=defectId && defectId.contains(Constants.idversionseparator)) {
				String[] idVersion=defectId.split(Constants.idversionseparator);
				defectId=idVersion[0];
			}
			
			DefectDetails defectDetails=commonDao.getDefectDetails(defectId,module);
			defect=new Defect();
			this.populateDefectDetails(defectDetails,defect);
		} catch (Exception e) {
			LOGGER.error("Exception in getDefectDetails");
			e.printStackTrace();
		}
		return defect;
	}

	private void populateDefectDetails(DefectDetails defectDetails,Defect defect) {
		defect.setDefectId(String.valueOf(defectDetails.getDefectId()));
		defect.setModuleName(defectDetails.getModuleName());
		defect.setDesc(defectDetails.getDefectDesc());
		defect.setAssignedto(defectDetails.getAssignedTo());
		defect.setReportedby(defectDetails.getReportedBy());
		defect.setReopenCount(defectDetails.getReopenCount());
		defect.setSeverity(defectDetails.getSeverity());
		defect.setPriority(defectDetails.getPriority());
		defect.setComment(defectDetails.getComment());
		defect.setAded(defectDetails.getAded());
		defect.setAted(defectDetails.getAted());
		defect.setStatus(defectDetails.getStatus());
		defect.setLastupdatedby(defectDetails.getLastUpdatedBy());
		defect.setLocation(defectDetails.getScreenLocation());
		defect.setReporttime(defectDetails.getReportedTime());
		defect.setRcaLocation(defectDetails.getRcaLocation());
		defect.setPded(defectDetails.getPded());
		defect.setPted(defectDetails.getPted());
		defect.setIsDeliverableNow(defectDetails.getIsDeliverableNow());
		defect.setIsDeliverableInFuture(defectDetails.getIsDeliverableInFuture());
		defect.setIsDeliverableForFirst(defectDetails.getIsDeliverableForFirst());
		defect.setIsDeliverableForSecond(defectDetails.getIsDeliverableForSecond());
		defect.setIsClientDefect(defectDetails.getIsClientDefect());
		defect.setAnalysis(defectDetails.getAnalysis());
		defect.setReviewer(defectDetails.getReviewer());
		defect.setVersionNumber(String.valueOf(defectDetails.getVersionNumber()));
		defect.setLinkedDefectId(defectDetails.getLinkedDefectId());
		defect.setLinkedDefectCount(defectDetails.getLinkedDefectCount());
		defect.setIsOnHold(defectDetails.getIsOnHold());
	}
	
	@Override
	public String updateConfigurationDetails(List<Configurations> configurations) {
		boolean flag = false;
		String message = "";
		try {
			for (Configurations configuration : configurations) {
					flag = commonDao.updateConfigurationDetails(configuration);
			}
			CONFIGURATION.resetConfig();
			this.loadConfigurations();
			message = flag ? Constants.configurationUpdateSuccess : Constants.error;
			broadcastManager.sendToBroadcast(null, null, null,null,null);
		} catch (Exception e) {
			message=Constants.ERROR+Constants.hashseparator+Constants.error;
			LOGGER.error("Exception in updateConfigurationDetails");
			e.printStackTrace();
		}
		return message;
	}
	
	@Override
	public String submitDeployment(List<DeploymentDetails> deploymentDetails) {
		List<Deployment> deployments = new ArrayList<Deployment>();
		boolean flag = false;
		String message = "";
		try {
			this.populateDeploymentDetails(deploymentDetails, deployments);
			for (Deployment deployment : deployments) {
					flag = commonDao.updateDeployment(deployment);
			}
			message = flag ? Constants.deploymentUpdateSuccess : Constants.error;
			broadcastManager.sendToBroadcast(null, null, deployments,null,null);
		} catch (Exception e) {
			message=Constants.ERROR+Constants.hashseparator+Constants.error;
			LOGGER.error("Exception in submitDeployment");
			e.printStackTrace();
		}
		return message;
	}
	
	private void populateEventDetails(Event event, EventDetails eventDetails){
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.dateformatter);
		String time=sdf.format( new Date());
		if((event.getAction().equals("UPDATE") || event.getAction().equals("DELETE")) &&
				!StringUtils.isEmpty(event.getEventId())) {
			eventDetails.setEventId(new BigInteger(event.getEventId()));
			eventDetails.setLastUpdatedBy(event.getEventCreator()+" ("+time+")");
		}
		eventDetails.setEvent(event.getEvent());
		eventDetails.setEventName(event.getEventName());
		eventDetails.setEventType(event.getEventType());
		eventDetails.setEventStartDate(event.getEventStartDate());
		eventDetails.setEventEndDate(event.getEventEndDate());
		eventDetails.setEventCreator(event.getEventCreator());
		eventDetails.setCreationDateTime(time);
		eventDetails.setEventComment(event.getEventComment());
	}
	@Override
	public String submitEvent(Event event) {
		EventDetails eventDetails = new EventDetails();
		boolean flag = false;
		String message = "";
		try {
			String action=event.getAction();
			this.populateEventDetails(event, eventDetails);
			flag = commonDao.updateEvent(eventDetails, action);
			if(!flag) {
				message=Constants.error;
			}else {
				if(action.equals("ADD")) {
					message=Constants.eventEnteredSuccess;
				}else if(action.equals("UPDATE")) {
					message=Constants.eventUpdatedSuccess;
				}else if(action.equals("DELETE")){
					message=Constants.eventDeletedSuccess;
				}
			}
			if(eventDetails.getEventType().equals("Public")) {
				broadcastManager.sendToBroadcast(null,null,null,null,eventDetails);
			}
			
		} catch (Exception e) {
			message=Constants.ERROR+Constants.hashseparator+Constants.error;
			LOGGER.error("Exception in submitEvent");
			e.printStackTrace();
		}
		return message;
	}

	private void populateDeploymentDetails(List<DeploymentDetails> deploymentDetails, List<Deployment> deployments) {
		if (null != deploymentDetails) {
			for (DeploymentDetails data : deploymentDetails) {
				Deployment deployment = new Deployment();
				deployment.setId(Long.parseLong(data.getId()));
				deployment.setServerName(data.getServerName());
				deployment.setUrl(data.getUrl());
				deployment.setDatabase(data.getDb());
				deployment.setUserName(data.getLoggedInUser());
				SimpleDateFormat sdf = new SimpleDateFormat(Constants.deploymentdateformatter);
				deployment.setDeploymentTime(sdf.format( new Date()));
				deployments.add(deployment);
			}
		}
	}
	private String validateDefectUpdateRequest(HashMap<Long, String> idVersionMap, DefectDetails prevDefectDetails){
		String message="";
		String oldVersionNumber=idVersionMap.get(prevDefectDetails.getDefectId());
		if(StringUtils.isEmpty(oldVersionNumber) || !(oldVersionNumber.equals(String.valueOf(prevDefectDetails.getVersionNumber())))) {
			message=Constants.obsolete;
		}
		return message;
	}
	
	@Override
	public String submitDefect(Defect defect) {
		DefectDetails defectDetails = new DefectDetails();
		boolean flag = false;
		String message = "";
		try {
			if (null != defect.getRequesttype() && defect.getRequesttype().equalsIgnoreCase("add")) {
				this.populateDefectDetails(defect, defectDetails);
				message=this.validateAndUpdateLinkedDefectId(defect);
				if(!StringUtils.isEmpty(message)) {
					return message;
				}
				flag = commonDao.submitDefect(defectDetails);
				broadcastManager.sendToBroadcast(defectDetails, null, null, null,null);
				systemAutoAssigner.findAssignerMatch(defectDetails);
			} else {
				String oldVersionNumber=null;
				DefectDetails prevDefectDetails=null;
				if(null!=defect.getDefectId() && defect.getDefectId().contains(Constants.idversionseparator)) {
					String[] idVersion=defect.getDefectId().split(Constants.idversionseparator);
					defect.setDefectId(idVersion[0]);
					oldVersionNumber=idVersion[1];
				}
				if(null!=defect.getDefectId() && !defect.getDefectId().equalsIgnoreCase("")){
					 prevDefectDetails=commonDao.getDefectDetails(String.valueOf(defect.getDefectId()),null);
				}
				HashMap<Long, String> idVersionMap=new HashMap<Long, String>();
				idVersionMap.put(prevDefectDetails.getDefectId(), oldVersionNumber);
				message=this.validateDefectUpdateRequest(idVersionMap, prevDefectDetails);
				if(!StringUtils.isEmpty(message)) {
					return message;
				}
				this.populateDefectUpdateDetails(defect, defectDetails, prevDefectDetails);
				if(StringUtils.isEmpty(defect.getOldLinkedDefectId()) || 
						!defect.getOldLinkedDefectId().equals(defect.getLinkedDefectId())) {
					message=this.validateAndUpdateLinkedDefectId(defect);
					if(!StringUtils.isEmpty(message)) {
						return message;
					}
					if(!StringUtils.isEmpty(defect.getOldLinkedDefectId())) {
						DefectDetails linkedDefectDetails=commonDao.getDefectDetails(defect.getOldLinkedDefectId(), "");
						if(null!=linkedDefectDetails) {
							int previousLinkedDefectCount=0;
							if(!StringUtils.isEmpty(linkedDefectDetails.getLinkedDefectCount())) {
								previousLinkedDefectCount=Integer.parseInt(linkedDefectDetails.getLinkedDefectCount());
							}
							int updatedLinkedDefectCount=previousLinkedDefectCount-1;
							if(updatedLinkedDefectCount==0) {
								linkedDefectDetails.setLinkedDefectCount(null);
							}else{
								linkedDefectDetails.setLinkedDefectCount(String.valueOf(updatedLinkedDefectCount));
							}
							commonDao.updateDefect(linkedDefectDetails);
						}
					}
				}
				flag = commonDao.updateDefect(defectDetails);
				broadcastManager.sendToBroadcast(defectDetails,prevDefectDetails, null, null,null);
			}
			message = flag ? (defect.getRequesttype().equalsIgnoreCase("add")) ? Constants.SUCCESS+Constants.hashseparator+Constants.submitSuccess+defectDetails.getDefectId() 
					: Constants.SUCCESS+Constants.hashseparator+Constants.updateSuccess+defectDetails.getDefectId() : Constants.ERROR+Constants.hashseparator+Constants.error;
		} catch (Exception e) {
			message=Constants.ERROR+Constants.hashseparator+Constants.error;
			LOGGER.error("Exception in submitDefect");
			e.printStackTrace();
		}
		return message;
	}
	
	private String validateAndUpdateLinkedDefectId(Defect defect) {
		String message="";
		if(!StringUtils.isEmpty(defect.getLinkedDefectId())) {
			DefectDetails linkedDefectDetails=commonDao.getDefectDetails(defect.getLinkedDefectId(), "");
			if(null==linkedDefectDetails) {
				message=Constants.ERROR+Constants.hashseparator+Constants.linkedIdError;
				return message;
			}
			int previousLinkedDefectCount=0;
			if(null!=linkedDefectDetails) {
				if(!StringUtils.isEmpty(linkedDefectDetails.getLinkedDefectCount())) {
					previousLinkedDefectCount=Integer.parseInt(linkedDefectDetails.getLinkedDefectCount());
				}
			}
			linkedDefectDetails.setLinkedDefectCount(String.valueOf(previousLinkedDefectCount+1));
			commonDao.updateDefect(linkedDefectDetails);
		}
		return message;
	}
	@Override
	public String submitUserDetails(String json) {
		boolean flag = false;
		String message = Constants.error;
		try {
			String[] userDetailsArr=json.split(Constants.separator);
			if (null != userDetailsArr && userDetailsArr.length>2) {
				UserDetails userDetails=getUserByName(userDetailsArr[0]);
				if(null!=userDetails){
					if(!StringUtils.isEmpty(userDetailsArr[1])){
						userDetails.setHostName(userDetailsArr[1]);
					}
					if(!StringUtils.isEmpty(userDetailsArr[2])){
						userDetails.setIp(userDetailsArr[2]);
					}
					flag=commonDao.updateUserDetails(userDetails);
					if(flag){
						LOGGER.info("Auto login executor updated details for User: "+userDetails.getUserName()+"| Computer: "+userDetails.getIp());
						message = flag?Constants.updateUserSuccess: Constants.error;
					}
				}else {
					message = Constants.userMissing;
				}
			}
		} catch (Exception e) {
			message=Constants.ERROR+Constants.hashseparator+Constants.error;
			LOGGER.error("Exception in submitUserDetails");
			e.printStackTrace();
		}
		return message;
	}
	
	private void cloneDefectDetails(DefectDetails prevDefect,DefectDetails defectDetails){
		prevDefect.setAssignedTo(defectDetails.getAssignedTo());
		prevDefect.setReviewer(defectDetails.getReviewer());
		prevDefect.setDefectDesc(defectDetails.getDefectDesc());
		prevDefect.setDefectId(defectDetails.getDefectId());
		prevDefect.setComment(defectDetails.getComment());
		prevDefect.setIsDeliverableInFuture(defectDetails.getIsDeliverableInFuture());
		prevDefect.setIsDeliverableNow(defectDetails.getIsDeliverableNow());
		prevDefect.setIsDeliverableForFirst(defectDetails.getIsDeliverableForFirst());
		prevDefect.setIsDeliverableForSecond(defectDetails.getIsDeliverableForSecond());
		prevDefect.setLastUpdatedBy(defectDetails.getLastUpdatedBy());
		prevDefect.setModuleName(defectDetails.getModuleName());
		prevDefect.setPriority(defectDetails.getPriority());
		prevDefect.setReportedBy(defectDetails.getReportedBy());
		prevDefect.setSeverity(defectDetails.getSeverity());
		prevDefect.setStatus(defectDetails.getStatus());
		prevDefect.setPded(defectDetails.getPded());
		prevDefect.setPted(defectDetails.getPted());
		prevDefect.setAded(defectDetails.getAded());
		prevDefect.setAted(defectDetails.getAted());
		prevDefect.setIsClientDefect(defectDetails.getIsClientDefect());
		prevDefect.setRcaLocation(defectDetails.getRcaLocation());
		prevDefect.setAnalysis(defectDetails.getAnalysis());
		prevDefect.setLinkedDefectId(defectDetails.getLinkedDefectId());
		prevDefect.setLinkedDefectCount(defectDetails.getLinkedDefectCount());
		prevDefect.setIsOnHold(defectDetails.getIsOnHold());
	}
	
	@Override
	public String updateContextMenuAction(String ids,String action,String user) {
		String message="";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(Constants.dateformatter);
			String time = sdf.format(new Date());
			List<Long> idList=new ArrayList<Long>();
			HashMap<Long, String> idVersionMap=new HashMap<Long, String>();
			idList=this.convertStringToList(ids,idList,idVersionMap);
			List<DefectDetails> defectDetailsList=commonDao.getMultipleDefectDetails(idList);
			for(DefectDetails defectDetails:defectDetailsList){
				message=this.validateDefectUpdateRequest(idVersionMap, defectDetails);
				if(!StringUtils.isEmpty(message)) {
					return message;
				}
			}
			for(DefectDetails defectDetails:defectDetailsList){
				DefectDetails prevDefectDetails=new DefectDetails();
				this.cloneDefectDetails(prevDefectDetails, defectDetails);
				defectDetails.setLastUpdatedBy(user+" ("+time+")");
				if(null!=action && action.equalsIgnoreCase("DELETE")){
					defectDetails.setDeleted("YES");
					commonDao.deleteDefect(defectDetails);
				}else {
					if(null!=action && action.equalsIgnoreCase("MOVETODELIVERY")){
						defectDetails.setIsDeliverableInFuture(null);
						defectDetails.setIsDeliverableForFirst(null);
						defectDetails.setIsDeliverableForSecond(null);
						defectDetails.setIsDeliverableNow("YES");				
					}else if(null!=action && action.equalsIgnoreCase("MOVETOFUTUREDELIVERY")){
						defectDetails.setIsDeliverableNow(null);
						defectDetails.setIsDeliverableForFirst(null);
						defectDetails.setIsDeliverableForSecond(null);
						defectDetails.setIsDeliverableInFuture("YES");
					}else if(null!=action && action.equalsIgnoreCase("MOVETOFIRSTDELIVERY")){
						defectDetails.setIsDeliverableNow(null);
						defectDetails.setIsDeliverableInFuture(null);
						defectDetails.setIsDeliverableForSecond(null);
						defectDetails.setIsDeliverableForFirst("YES");
					}else if(null!=action && action.equalsIgnoreCase("MOVETOSECONDDELIVERY")){
						defectDetails.setIsDeliverableNow(null);
						defectDetails.setIsDeliverableInFuture(null);
						defectDetails.setIsDeliverableForFirst(null);
						defectDetails.setIsDeliverableForSecond("YES");
					}else if(null!=action && action.equalsIgnoreCase("MOVETOOPEN")){
						defectDetails.setIsDeliverableNow(null);
						defectDetails.setIsDeliverableInFuture(null);
						defectDetails.setIsDeliverableForFirst(null);
						defectDetails.setIsDeliverableForSecond(null);
					}else if(null!=action && action.equalsIgnoreCase("HOLD")) {
						defectDetails.setIsOnHold("YES");
					}else if(null!=action && action.equalsIgnoreCase("UNHOLD")) {
						defectDetails.setIsOnHold(null);
					}else if(null!=action && action.equalsIgnoreCase("ARCHIVE")) {
						defectDetails.setDeleted("ARCHIVED");
					}else{
						if(!prevDefectDetails.getStatus().equalsIgnoreCase(Constants.FIXED) && action.equalsIgnoreCase(Constants.FIXED)){
							defectDetails.setAded(time);
						}else if(!prevDefectDetails.getStatus().equalsIgnoreCase(Constants.RTT) && !prevDefectDetails.getStatus().equalsIgnoreCase(Constants.FIXED)
								&& action.equalsIgnoreCase(Constants.RTT)){
							defectDetails.setAded(time);
						}
						
						if(!prevDefectDetails.getStatus().equalsIgnoreCase(Constants.CLOSED) && action.equalsIgnoreCase(Constants.CLOSED)){
							defectDetails.setAted(time);
						}
						defectDetails.setStatus(action);
					}
					commonDao.updateDefect(defectDetails);
				}
				broadcastManager.sendToBroadcast(defectDetails, prevDefectDetails, null, null,null);
			}
		} catch (Exception e) {
			message=Constants.ERROR+Constants.hashseparator+Constants.error;
			LOGGER.error("Exception in updateContextMenuAction");
			e.printStackTrace();
		}
		return message;
	}
	
	
	private List<Long> convertStringToList(String ids,List<Long> idList,HashMap<Long, String> idVersionMap){
		String[] idArr=ids.split(",");
		for(String id:idArr){
			String[] idVersion=id.split(Constants.idversionseparator);
			Long defectId=Long.parseLong(idVersion[0]);
			idVersionMap.put(defectId, idVersion[1]);
			idList.add(defectId);
		}
		return idList;
	}
	
	@Override
	public Boolean getUpdateStatus(HttpSession session) {
		Boolean isValidRefresh=false;
		try {
			String sessionId = session.getId();
			String lastUpdateKey = sessionId + Constants.LastServerUpdate;
			Object lastServerHitTime=ServerCacheStore.getStoreValue(Constants.LastServerUpdate);
			Object lastUserHitTime=ServerCacheStore.getStoreValue(lastUpdateKey);
			if(null==lastUserHitTime){
				isValidRefresh=true;
			}
			if(null!=lastServerHitTime && null!=lastUserHitTime){
				if(((Long)lastServerHitTime-(Long)lastUserHitTime)>0){
					isValidRefresh=true;
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in getUpdateStatus");
			e.printStackTrace();
		}
		return isValidRefresh;
	}
	//This method will be used in case auto refresh is activated
	@SuppressWarnings("unused")
	private void setServerHitTime(){
			ServerCacheStore.putStoreValue(Constants.LastServerUpdate, System.currentTimeMillis());
	}
	
	@Override
	public void submitChat(Announcement announcement) {
		Messages message = new Messages();
		try {
			if(!StringUtils.isEmpty(announcement.getLoggedInUser()) && !StringUtils.isEmpty(announcement.getMessage())) {
				message.setMessage(announcement.getMessage());
				message.setUserName(announcement.getLoggedInUser());
				SimpleDateFormat sdf = new SimpleDateFormat(Constants.chatdateformatter);
				message.setTime(sdf.format(new Date()));
				commonDao.submitChat(message);
				broadcastManager.sendToBroadcast(null,null, null, message,null);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in submitChat");
			e.printStackTrace();
		}
	}
	
	@Override
	public String moveDefectsToArchive(String userName) {
		boolean flag=false;
		String message = "";
		try {
			LOGGER.info("Defect archive request is received from user: "+userName);
			UserDetails userDetails = this.getUserByName(userName);
			if(!userDetails.getOptionAccess().contains(AdminStorage.ADMINISTRATION)) {
				LOGGER.warn("****** "+userName+ " trying to access unauthorized functionality (Archive defects) ******");
				message=Constants.ERROR+Constants.hashseparator+Constants.noAccess;
			}else {
				flag = commonDao.moveDefectsToArchive();
				broadcastManager.sendToBroadcast(null, null, null, null,null);
				message = flag?Constants.archivedSuccess:Constants.error;
			}
		} catch (Exception e) {
			message=Constants.ERROR+Constants.hashseparator+Constants.error;
			LOGGER.error("Exception in moveDefectsToArchive");
			e.printStackTrace();
		}
		return message;
	}

	private void populateDefectDetails(Defect defect, DefectDetails defectDetails) {
		defectDetails.setModuleName(defect.getModuleName());
		defectDetails.setAnalysis(defect.getAnalysis());
		if(null!=defect.getDesc()){
			defect.setDesc(defect.getDesc().replace("\"","'"));
			defect.setDesc(defect.getDesc().replace("<","-"));
			defect.setDesc(defect.getDesc().replace(">","-"));
		}
		defectDetails.setDefectDesc(defect.getDesc());
		defectDetails.setPriority(defect.getPriority());
		defectDetails.setSeverity(defect.getSeverity());
		if(null!=defect.getReportedby() && defect.getReportedby().length()>1){
			char first = Character.toUpperCase(defect.getReportedby().charAt(0));
			defect.setReportedby(first + defect.getReportedby().substring(1));
		}
		if(null!=defect.getAssignedto() && defect.getAssignedto().length()>1){
			char first = Character.toUpperCase(defect.getAssignedto().charAt(0));
			defect.setAssignedto(first + defect.getAssignedto().substring(1));
		}
		defectDetails.setReportedBy(defect.getReportedby());
		defectDetails.setAssignedTo(defect.getAssignedto());
		
		if(null!=defect.getComment()){
			defect.setComment(defect.getComment().replace("\"","'"));
			defect.setComment(defect.getComment().replace("<","-"));
			defect.setComment(defect.getComment().replace(">","-"));
		}
		defectDetails.setComment(defect.getComment());
		defectDetails.setScreenLocation(defect.getLocation());
		if(!StringUtils.isEmpty(defectDetails.getAssignedTo()) && (StringUtils.isEmpty(defect.getStatus()) || 
				defect.getStatus().equalsIgnoreCase(Constants.UNASSIGNED))){
			defectDetails.setStatus(Constants.ASSIGNED);
		}else{
			defectDetails.setStatus(defect.getStatus());
		}
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.dateformatter);
		Date date = new Date();
		String time = sdf.format(date);
		defectDetails.setReportedTime(time);
		defectDetails.setReopenCount("0");
		defectDetails.setLastUpdatedBy(defect.getLastupdatedby()+" ("+time+")");
		if(null!=defect.getIsDeliverableNow() && defect.getIsDeliverableNow().equalsIgnoreCase("YES")){
			defectDetails.setIsDeliverableNow("YES");
		}else if(null!=defect.getIsDeliverableInFuture() && defect.getIsDeliverableInFuture().equalsIgnoreCase("YES")){
			defectDetails.setIsDeliverableInFuture("YES");
		}
		else if(null!=defect.getIsDeliverableForFirst() && defect.getIsDeliverableForFirst().equalsIgnoreCase("YES")){
			defectDetails.setIsDeliverableForFirst("YES");
		}
		else if(null!=defect.getIsDeliverableForSecond() && defect.getIsDeliverableForSecond().equalsIgnoreCase("YES")){
			defectDetails.setIsDeliverableForSecond("YES");
		}
		if(null!=defect.getIsClientDefect() && defect.getIsClientDefect().equalsIgnoreCase("YES")){
			defectDetails.setIsClientDefect("YES");
		}else{
			defectDetails.setIsClientDefect("NO");
		}
		if(!StringUtils.isEmpty(defect.getLinkedDefectId())) {
			defectDetails.setLinkedDefectId(defect.getLinkedDefectId());
		}
	}
	
	private void populateDefectUpdateDetails(Defect defect, DefectDetails defectDetails,DefectDetails prevDefectDetails) {
		defectDetails.setModuleName(defect.getModuleName());
		if(null!=defect.getDesc()){
			defect.setDesc(defect.getDesc().replace("\"","'"));
			defect.setDesc(defect.getDesc().replace("<","-"));
			defect.setDesc(defect.getDesc().replace(">","-"));
		}
		defectDetails.setDefectDesc(defect.getDesc());
		defectDetails.setPriority(defect.getPriority());
		defectDetails.setSeverity(defect.getSeverity());
		defectDetails.setAnalysis(defect.getAnalysis());
		defectDetails.setRcaLocation(defect.getRcaLocation());
		if(null!=defect.getReportedby() && defect.getReportedby().length()>1){
			char first = Character.toUpperCase(defect.getReportedby().charAt(0));
			defect.setReportedby(first + defect.getReportedby().substring(1));
		}
		if(null!=defect.getAssignedto() && defect.getAssignedto().length()>1){
			char first = Character.toUpperCase(defect.getAssignedto().charAt(0));
			defect.setAssignedto(first + defect.getAssignedto().substring(1));
		}
		defectDetails.setReportedBy(defect.getReportedby());
		defectDetails.setAssignedTo(defect.getAssignedto());
		defectDetails.setReviewer(defect.getReviewer());
		if(null!=defect.getComment()){
			defect.setComment(defect.getComment().replace("\"","'"));
			defect.setComment(defect.getComment().replace("<","-"));
			defect.setComment(defect.getComment().replace(">","-"));
		}
		defectDetails.setComment(defect.getComment());
		defectDetails.setScreenLocation(defect.getLocation());
		if(!StringUtils.isEmpty(defectDetails.getAssignedTo()) && (StringUtils.isEmpty(defect.getStatus()) || 
				defect.getStatus().equalsIgnoreCase(Constants.UNASSIGNED))){
			defectDetails.setStatus(Constants.ASSIGNED);
		}else{
			defectDetails.setStatus(defect.getStatus());
		}
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.dateformatter);
		Date date = new Date();
		String time = sdf.format(date);
		if (null!=prevDefectDetails) {
			defectDetails.setDefectId(Long.valueOf(defect.getDefectId()));
			defectDetails.setReportedTime(prevDefectDetails.getReportedTime());
			int rCount=0;
			if(!StringUtils.isEmpty(prevDefectDetails.getReopenCount())){
				rCount=Integer.parseInt(prevDefectDetails.getReopenCount());
			}
			if(!prevDefectDetails.getStatus().equalsIgnoreCase(Constants.REOPENED) && defect.getStatus().equalsIgnoreCase(Constants.REOPENED)){
				rCount++;
			}
			defectDetails.setReopenCount(String.valueOf(rCount));
			if(!prevDefectDetails.getStatus().equalsIgnoreCase(Constants.FIXED) && defect.getStatus().equalsIgnoreCase(Constants.FIXED)){
				defectDetails.setAded(time);
			}else if(!prevDefectDetails.getStatus().equalsIgnoreCase(Constants.RTT) && !prevDefectDetails.getStatus().equalsIgnoreCase(Constants.FIXED)
					&& defect.getStatus().equalsIgnoreCase(Constants.RTT)){
				defectDetails.setAded(time);
			}else{
				defectDetails.setAded(prevDefectDetails.getAded());
			}
			
			if(!prevDefectDetails.getStatus().equalsIgnoreCase(Constants.CLOSED) && defect.getStatus().equalsIgnoreCase(Constants.CLOSED)){
				defectDetails.setAted(time);
			}else{
				defectDetails.setAted(prevDefectDetails.getAted());
			}
			defectDetails.setPded(defect.getPded());
			defectDetails.setPted(defect.getPted());
			
			if(null!=defect.getIsClientDefect() && defect.getIsClientDefect().equalsIgnoreCase("YES")){
				defectDetails.setIsClientDefect("YES");
			}else {
				defectDetails.setIsClientDefect("NO");
			}
		}
		defectDetails.setLastUpdatedBy(defect.getLastupdatedby()+" ("+time+")");
		if(null!=defect.getIsDeliverableNow() && defect.getIsDeliverableNow().equalsIgnoreCase("YES")){
			defectDetails.setIsDeliverableNow("YES");
		}else if(null!=defect.getIsDeliverableInFuture() && defect.getIsDeliverableInFuture().equalsIgnoreCase("YES")){
			defectDetails.setIsDeliverableInFuture("YES");
		}else if(null!=defect.getIsDeliverableForFirst() && defect.getIsDeliverableForFirst().equalsIgnoreCase("YES")){
			defectDetails.setIsDeliverableForFirst("YES");
		}else if(null!=defect.getIsDeliverableForSecond() && defect.getIsDeliverableForSecond().equalsIgnoreCase("YES")){
			defectDetails.setIsDeliverableForSecond("YES");
		}
		if(!StringUtils.isEmpty(defect.getLinkedDefectId())) {
			defectDetails.setLinkedDefectId(defect.getLinkedDefectId());
		}
	}

	private void populateOptionAccess(UserDetails userDetails,HashMap<String, Object> map,List<String> defectStateList ){
		List<String> optionAccessList=new ArrayList<String>();
		if(null!=userDetails && null!=userDetails.getOptionAccess()){
			optionAccessList=Arrays.asList(userDetails.getOptionAccess().split("\\s*,\\s*"));
			if(optionAccessList.contains(AdminStorage.CAN_FIX)){
				defectStateList.add(Constants.WIP);
				defectStateList.add(Constants.FIXED);
			}
			if(optionAccessList.contains(AdminStorage.CAN_RTT)){
				defectStateList.add(Constants.RTT);
			}
			if(optionAccessList.contains(AdminStorage.CAN_REOPEN)){
				defectStateList.add(Constants.REOPENED);
			}
			if(optionAccessList.contains(AdminStorage.CAN_REJECT)){
				defectStateList.add(Constants.REJECTED);
			}
			if(optionAccessList.contains(AdminStorage.CAN_CLOSE)){
				defectStateList.add(Constants.CLOSED);
			}
			if(optionAccessList.contains(AdminStorage.CAN_ASSIGN)){
				defectStateList.add(Constants.UNASSIGNED);
				defectStateList.add(Constants.ASSIGNED);
			}
			if(optionAccessList.contains(AdminStorage.CAN_DEFERRED)){
				defectStateList.add(Constants.DEFERRED);
			}
		}
		map.put(Constants.defectStates, defectStateList);
		map.put(Constants.OPTION_ACCESS, optionAccessList);
	}
	
	@Override
	public void loadConfigurations() {
		if(!CONFIGURATION.isConfigInitialize()) {
			CONFIGURATION.InitializeConfig();
			List<Configurations> configurations = commonDao.getConfigurations();
			if(null!=configurations && !configurations.isEmpty()) {
				for(Configurations configuration:configurations) {
					CONFIGURATION.putKeyValue(configuration.getConfigKey(), configuration.getConfigValue());
				}
				LOGGER.info("Configurations loading completed. Total configurations: "+configurations.size());
			}
		}
	}
	
	@Override
	public void setSystemProperties(HashMap<String, Object> map) {
		map.put(CONFIGURATION.CONFIGURATION_KEYS.NEXT_DELIVERY_CONF.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.NEXT_DELIVERY_CONF.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.NEXT_DELIVERY_DATE.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.NEXT_DELIVERY_DATE.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.TAB_NAME_1.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.TAB_NAME_1.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.TAB_NAME_2.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.TAB_NAME_2.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.TAB_NAME_3.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.TAB_NAME_3.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.TAB_NAME_4.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.TAB_NAME_4.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.RTT_THRESHOLD.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.RTT_THRESHOLD.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.FIXED_THRESHOLD.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.FIXED_THRESHOLD.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.UNASSIGNED_THRESHOLD.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.UNASSIGNED_THRESHOLD.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.NOTIFICATION_INTERVAL.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.NOTIFICATION_INTERVAL.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.PROJECT_NAME.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.PROJECT_NAME.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.BROADCAST_MANAGER_FLAG.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.BROADCAST_MANAGER_FLAG.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.POLL_INTERVAL.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.POLL_INTERVAL.getValue()));
		map.put(CONFIGURATION.CONFIGURATION_KEYS.BROADCAST_INTERVAL.toString(), CONFIGURATION.getValue(CONFIGURATION_KEYS.BROADCAST_INTERVAL.getValue()));
		map.put("extUrl1Name", CONFIGURATION.getValue(CONFIGURATION_KEYS.EXT_URL1_NAME.getValue()));
		map.put("extUrl2Name", CONFIGURATION.getValue(CONFIGURATION_KEYS.EXT_URL2_NAME.getValue()));
		map.put("extUrl3Name", CONFIGURATION.getValue(CONFIGURATION_KEYS.EXT_URL3_NAME.getValue()));
		
		map.put("extUrl1Value", CONFIGURATION.getValue(CONFIGURATION_KEYS.EXT_URL1_VALUE.getValue()));
		map.put("extUrl2Value", CONFIGURATION.getValue(CONFIGURATION_KEYS.EXT_URL2_VALUE.getValue()));
		map.put("extUrl3Value", CONFIGURATION.getValue(CONFIGURATION_KEYS.EXT_URL3_VALUE.getValue()));

	}
	
	@SuppressWarnings({ "unchecked" })
	@Override
	public void buildServerCache(HashMap<String, Object> map,String sessionId,String hostName) {
	
		List<String> defectStateList = new ArrayList<String>();
		String lastUpdateKey = sessionId + Constants.LastServerUpdate;
		ServerCacheStore.putStoreValue(lastUpdateKey, System.currentTimeMillis());	
		UserDetails userDetails=commonDao.getUserDetails(hostName);
		this.populateOptionAccess(userDetails, map, defectStateList);
		map.put(Constants.username, null!=userDetails?userDetails.getUserName():null);
		map.put(Constants.role, null!=userDetails?userDetails.getRole():null);

		List<String> users=new ArrayList<String>();
		Object storedusers=ServerCacheStore.getStoreValue(Constants.userData);
		if(null == storedusers){
			users=commonDao.getUsers(null);
			ServerCacheStore.putStoreValue(Constants.userData, users);
		}else{
			users=(List<String>) storedusers;
		}
		map.put(Constants.userData, users);

		Set<String> moduleNames=new HashSet<String>();
		Object storedmodules=ServerCacheStore.getStoreValue(Constants.moduleNames);
		if(null == storedmodules){
			List<ModuleDetails> moduleDetails=commonDao.getModuleDetails();
			this.populateModulesMap(moduleDetails);
			moduleNames=SystemAutoAssigner.modulesMap.keySet();
			ServerCacheStore.putStoreValue(Constants.moduleNames,moduleNames);
		}else{
			moduleNames=(Set<String>) storedmodules;
		}
		map.put(Constants.moduleNames, moduleNames);
	}
	
	private void populateModulesMap(List<ModuleDetails> moduleDetails){
		if(null!=moduleDetails){
			for(ModuleDetails details:moduleDetails){
				SystemAutoAssigner.modulesMap.put(details.getModuleName(), details.getModuleOwners());
			}
		}
	}
		
	public HSSFCellStyle getHeaderCellStyle(HSSFWorkbook hwb){
		short border=1;
		HSSFFont headerFont = hwb.createFont();
		headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		headerFont.setColor(HSSFColor.WHITE.index);
		HSSFCellStyle  headerCellStyle=hwb.createCellStyle();
		headerCellStyle.setFont(headerFont);
		headerCellStyle.setBorderBottom(border);
		headerCellStyle.setBorderTop(border);
		headerCellStyle.setBorderLeft(border);
		headerCellStyle.setBorderRight(border);
		headerCellStyle.setBorderRight(border);
		headerCellStyle.setFillForegroundColor(HSSFColor.BLACK.index);
		headerCellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		return headerCellStyle;
	}
	
	public HSSFCellStyle getDefaultCellStyle(HSSFWorkbook hwb){
		short border=1;
		HSSFCellStyle defaultCellStyle=hwb.createCellStyle();
		defaultCellStyle.setBorderBottom(border);
		defaultCellStyle.setBorderTop(border);
		defaultCellStyle.setBorderLeft(border);
		defaultCellStyle.setBorderRight(border);
		return defaultCellStyle;
	}
	
	@Override
	public  HSSFSheet getEXCELData( HSSFWorkbook hwb,String requestType){
		List<String> headerList=new ArrayList<String>();
		headerList.add("Id");
		headerList.add("Module");
		headerList.add("Defect description");
		headerList.add("Is Client Defect?");
		headerList.add("Priority");
		headerList.add("Severity");
		headerList.add("Linked id");
		headerList.add("Reported by");
		headerList.add("Assigned to");
		headerList.add("Reopened Count");
		headerList.add("Status");
		headerList.add("Reported time");
		headerList.add("Comment");
		headerList.add("Screenshot location");
		headerList.add("Last updated by (at)");
		headerList.add("Planned DED");
		headerList.add("Actual DED");
		headerList.add("Planned TED");
		headerList.add("Actual TED");
	
		List<DefectDetails> defectDetails=this.getDefectData(requestType);
		if(null==defectDetails || defectDetails.size()<1){
			return null;
		}
		HSSFSheet sheet = hwb.createSheet("Exported Data");
		HSSFCellStyle headerCellStyle=this.getHeaderCellStyle(hwb);
		HSSFCellStyle defaultCellStyle=this.getDefaultCellStyle(hwb);
		
		HSSFRow rowhead = sheet.createRow((short) 0);
		int headerIndex=0;
		for(String header:headerList){
			HSSFCell cell=rowhead.createCell(headerIndex);
			cell.setCellValue(header);
		  	cell.setCellStyle(headerCellStyle);
			headerIndex++;
		 }
		 int rowIndex=1; 
		 for(DefectDetails details:defectDetails){
			 int cellIndex=0;	
			 HSSFRow row = sheet.createRow((short)rowIndex);
			 
		     HSSFCell cell=row.createCell(cellIndex);
			 cell.setCellValue(details.getDefectId());
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getModuleName()?details.getModuleName():"");
			 cell.setCellStyle(defaultCellStyle);
		     
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getDefectDesc()?details.getDefectDesc():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(!StringUtils.isEmpty(details.getIsClientDefect())?"YES":"NO");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getPriority()?details.getPriority():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getSeverity()?details.getSeverity():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getLinkedDefectId()?details.getLinkedDefectId():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getReportedBy()?details.getReportedBy():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getAssignedTo()?details.getAssignedTo():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(!StringUtils.isEmpty(details.getReopenCount())?details.getReopenCount():"0");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getStatus()?details.getStatus():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getReportedTime()?details.getReportedTime():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getComment()?details.getComment():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getScreenLocation()?details.getScreenLocation():"");
			 cell.setCellStyle(defaultCellStyle);
		 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getLastUpdatedBy()?details.getLastUpdatedBy():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getPded()?details.getPded():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getAded()?details.getAded():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getPted()?details.getPted():"");
			 cell.setCellStyle(defaultCellStyle);
			 
			 cell=row.createCell(++cellIndex);
			 cell.setCellValue(null!=details.getAted()?details.getAted():"");
			 cell.setCellStyle(defaultCellStyle);

		     rowIndex++;
		}
	  return sheet;
	}
	
	@Override
	public  Map<String,String> getAllDefectCounts(){
		Map<String,String> counMap=null;
		try {
			counMap = commonDao.getAllDefectCounts();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return counMap;
	}
	
	@Override
	public  List<DefectDetails> getDefectData(String requestType){
		List<DefectDetails> defectList = null;
		try {
			defectList = commonDao.getAllDefectDetails(requestType);
		} catch (Exception e) {
			LOGGER.error("Exception in getDefectData");
			e.printStackTrace();
		}
		return defectList;
	}
	
	@Override
	public UserDetails getUserByName(String userName) {
		UserDetails userDetails=null;
		try {
			userDetails = commonDao.getUserDetailsByName(userName);	
		} catch (Exception e) {
			LOGGER.error("Exception in getUserByName");
			e.printStackTrace();
		}
		return userDetails;
	}
	
	@Override
	public String getGenericSearch(GenericSearchFilter genericSearchFilter) {
		StringBuilder htmlTable=new StringBuilder();
		List<Object[]> defectData=commonDao.getGenericSearch(genericSearchFilter);
			if(null!=defectData && defectData.size()>0){
				for(Object[] objectArr:defectData){
					String isClientDefectClass="";
					if(!StringUtils.isEmpty(objectArr[9]) && objectArr[9].equals("YES")){
						isClientDefectClass="sirDescBackgrount";
					}
					htmlTable.append("<tr onclick='showSearchDefect(\""+objectArr[0]+"\");'>");
					htmlTable.append("<td>").append(null!=objectArr[0]?objectArr[0]:"").append("</td>");
					htmlTable.append("<td>").append(null!=objectArr[1]?objectArr[1]:"").append("</td>");
					htmlTable.append("<td class='"+isClientDefectClass+"'><div class='desccol'>").append(null!=objectArr[2]?objectArr[2]:"").append("</div></td>");				
					htmlTable.append("<td>").append(null!=objectArr[3]?objectArr[3]:"").append("</td>");
					htmlTable.append("<td>").append(null!=objectArr[4]?objectArr[4]:"").append("</td>");
					htmlTable.append("<td>").append(null!=objectArr[5]?objectArr[5]:"").append("</td>");
					htmlTable.append("<td>").append(null!=objectArr[6]?objectArr[6]:"").append("</td>");
					htmlTable.append("<td>").append(null!=objectArr[7]?objectArr[7]:"").append("</td>");
					htmlTable.append("<td>").append(null!=objectArr[8]?objectArr[8]:"").append("</td>");
					htmlTable.append("</tr>");
			}
		}
		return htmlTable.toString();
	}

	@Override
	public List<ChangeLog> getChangeLogs(ChangeLogFilter changeLogFilter) {
		List<ChangeLog> changeLogs  = null;
		try {
			changeLogs = commonDao.getChangeLogs(changeLogFilter);
		} catch (Exception e) {
			LOGGER.error("Exception in getChangeLogs");
			e.printStackTrace();
		}
		return changeLogs;
	}
}

