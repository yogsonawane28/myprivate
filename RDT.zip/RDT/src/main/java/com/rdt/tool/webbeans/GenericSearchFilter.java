package com.rdt.tool.webbeans;

import java.io.Serializable;

@SuppressWarnings("serial")
public class GenericSearchFilter implements Serializable{
	
	private String defectId;
	private String moduleName;
	private String defectDesc;
	private String reportedBy;
	private String assignedTo;
	private String priority;
	private String severity;
	private String status;
	private String isClientDefect;
	private String wildInput;
	
	public String getDefectId() {
		return defectId;
	}
	public void setDefectId(String defectId) {
		this.defectId = defectId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getDefectDesc() {
		return defectDesc;
	}
	public void setDefectDesc(String defectDesc) {
		this.defectDesc = defectDesc;
	}
	public String getReportedBy() {
		return reportedBy;
	}
	public void setReportedBy(String reportedBy) {
		this.reportedBy = reportedBy;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getSeverity() {
		return severity;
	}
	public void setSeverity(String severity) {
		this.severity = severity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getIsClientDefect() {
		return isClientDefect;
	}
	public void setIsClientDefect(String isClientDefect) {
		this.isClientDefect = isClientDefect;
	}
	public String getWildInput() {
		return wildInput;
	}
	public void setWildInput(String wildInput) {
		this.wildInput = wildInput;
	}
}
